"""
rag/search.py — RAG query interface for the NERMAL knowledge base.
Provides vector search, hybrid search, and context builder.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


@dataclass
class SearchResult:
    score:               float
    ner_id:              str
    title:               str
    facility:            str
    milestone:           str
    package_family:      str
    implementation_docu: str
    sharelink:           str
    filename:            str
    file_path:           str
    chunk_index:         int
    total_chunks:        int
    chunk_text:          str


def vector_search(
    query: str,
    model: SentenceTransformer,
    client: Elasticsearch,
    config: Config,
    top_k: int = 10,
    filters: Optional[dict[str, str]] = None,
) -> list[SearchResult]:
    """Pure knn (vector) search with optional keyword filters."""
    query_vector = model.encode([query], normalize_embeddings=True)[0].tolist()

    knn_clause: dict = {
        "field":          "embedding",
        "query_vector":   query_vector,
        "k":              top_k,
        "num_candidates": top_k * config.es_num_candidates,
    }
    if filters:
        knn_clause["filter"] = {
            "bool": {"must": [{"term": {k: v}} for k, v in filters.items()]}
        }

    response = client.search(
        index=config.es_index,
        body={"knn": knn_clause, "_source": {"excludes": ["embedding"]}, "size": top_k},
    )
    return _parse_hits(response)


def hybrid_search(
    query: str,
    model: SentenceTransformer,
    client: Elasticsearch,
    config: Config,
    top_k: int = 10,
    filters: Optional[dict[str, str]] = None,
) -> list[SearchResult]:
    """
    Hybrid knn + BM25 search using Elasticsearch RRF (ES 8.8+).
    Falls back to pure vector search on older versions.
    """
    query_vector  = model.encode([query], normalize_embeddings=True)[0].tolist()
    filter_clause = (
        {"bool": {"must": [{"term": {k: v}} for k, v in filters.items()]}}
        if filters else None
    )

    try:
        rrf_body: dict = {
            "retriever": {
                "rrf": {
                    "retrievers": [
                        {
                            "standard": {
                                "query": {
                                    "multi_match": {
                                        "query":  query,
                                        "fields": [
                                            "chunk_text^2",
                                            "title^3",
                                            "motivation",
                                            "current_procedure",
                                            "new_procedure",
                                        ],
                                    }
                                },
                                **({"filter": filter_clause} if filter_clause else {}),
                            }
                        },
                        {
                            "knn": {
                                "field":          "embedding",
                                "query_vector":   query_vector,
                                "k":              top_k,
                                "num_candidates": top_k * config.es_num_candidates,
                                **({"filter": filter_clause} if filter_clause else {}),
                            }
                        },
                    ],
                    "rank_window_size": top_k * 2,
                    "rank_constant":    60,
                }
            },
            "_source": {"excludes": ["embedding"]},
            "size":    top_k,
        }
        response = client.search(index=config.es_index, body=rrf_body)
        return _parse_hits(response)

    except Exception as exc:
        log.warning("RRF not supported, falling back to vector search. Error: %s", exc)
        return vector_search(query, model, client, config, top_k=top_k, filters=filters)


def build_context(results: list[SearchResult], max_chars: int = 8000) -> str:
    """Format retrieved chunks into a context string for an LLM prompt."""
    parts: list[str] = []
    total = 0
    for i, r in enumerate(results, start=1):
        header = (
            f"--- Source {i} | NER_ID: {r.ner_id} | {r.title} "
            f"| {r.facility} | {r.milestone} | {r.implementation_docu} "
            f"| File: {r.filename} ---"
        )
        block = f"{header}\n{r.chunk_text.strip()}"
        if total + len(block) > max_chars:
            break
        parts.append(block)
        total += len(block)
    return "\n\n".join(parts)


def _parse_hits(response: dict) -> list[SearchResult]:
    results: list[SearchResult] = []
    for hit in response.get("hits", {}).get("hits", []):
        src = hit["_source"]
        results.append(SearchResult(
            score=               hit.get("_score") or 0.0,
            ner_id=              src.get("ner_id", ""),
            title=               src.get("title", ""),
            facility=            src.get("facility", ""),
            milestone=           src.get("milestone", ""),
            package_family=      src.get("package_family", ""),
            implementation_docu= src.get("implementation_docu", ""),
            sharelink=           src.get("sharelink", ""),
            filename=            src.get("filename", ""),
            file_path=           src.get("file_path", ""),
            chunk_index=         src.get("chunk_index", 0),
            total_chunks=        src.get("total_chunks", 0),
            chunk_text=          src.get("chunk_text", ""),
        ))
    return results
