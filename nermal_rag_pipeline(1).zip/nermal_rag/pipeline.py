"""
pipeline.py — Main orchestrator for the NERMAL RAG ingestion pipeline.

Run:
    python pipeline.py

Flow:
  1. Extract data from Oracle (4-table JOIN).
  2. Parse each document file from the network share.
  3. Chunk the extracted text.
  4. Embed the chunks.
  5. Bulk-index to Elasticsearch.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

from config import cfg
from logger import get_logger
from db.oracle_client import build_engine, extract_data
from parsers.document_parser import parse_document
from processing.chunker import build_splitter, chunk_document
from processing.embedder import load_model, embed_chunks
from storage.elasticsearch_client import (
    build_client,
    ensure_index,
    build_es_documents,
    bulk_index,
)

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


class Stats:
    def __init__(self) -> None:
        self.total_rows:   int       = 0
        self.files_parsed: int       = 0
        self.files_empty:  int       = 0
        self.files_failed: int       = 0
        self.total_chunks: int       = 0
        self.es_success:   int       = 0
        self.es_errors:    int       = 0
        self.failed_paths: list[str] = []

    def report(self) -> str:
        return (
            "\n"
            "════════════════════════════════════════\n"
            " NERMAL RAG Pipeline — Final Statistics \n"
            "════════════════════════════════════════\n"
            f"  Oracle rows extracted : {self.total_rows:>8,}\n"
            f"  Files parsed          : {self.files_parsed:>8,}\n"
            f"  Files with no text    : {self.files_empty:>8,}\n"
            f"  Files failed (error)  : {self.files_failed:>8,}\n"
            f"  Total chunks created  : {self.total_chunks:>8,}\n"
            f"  ES documents indexed  : {self.es_success:>8,}\n"
            f"  ES index errors       : {self.es_errors:>8,}\n"
            "════════════════════════════════════════"
        )


def run() -> Stats:
    stats   = Stats()
    t_start = time.perf_counter()

    log.info("═══════════════════════════════════════")
    log.info(" NERMAL RAG Pipeline — START           ")
    log.info("═══════════════════════════════════════")

    # 1. Oracle extraction
    log.info("[1/5] Connecting to Oracle and extracting data…")
    engine = build_engine(cfg)
    df     = extract_data(engine, cfg)
    stats.total_rows = len(df)
    log.info("[1/5] Done — %d rows", stats.total_rows)

    if df.empty:
        log.warning("No rows returned from Oracle. Exiting.")
        return stats

    # 2. Elasticsearch setup
    log.info("[2/5] Setting up Elasticsearch index…")
    es_client = build_client(cfg)
    ensure_index(es_client, cfg)
    log.info("[2/5] Done")

    # 3. Embedding model
    log.info("[3/5] Loading embedding model…")
    model    = load_model(cfg)
    splitter = build_splitter(cfg)
    log.info("[3/5] Done")

    # 4 + 5. Parse → Chunk → Embed → Index
    log.info("[4/5] Processing documents and indexing…")
    bulk_buffer: list[dict] = []

    for pos, (_, row) in enumerate(df.iterrows(), start=1):
        file_path = str(row.get("FILE_PATH", ""))
        ext       = Path(file_path).suffix.lower()

        if ext not in cfg.supported_extensions:
            log.debug("Skipping unsupported extension '%s': %s", ext, file_path)
            continue

        # Parse
        try:
            raw_text = parse_document(file_path)
        except Exception as exc:
            log.error("Unexpected error parsing %s: %s", file_path, exc)
            stats.files_failed += 1
            stats.failed_paths.append(file_path)
            continue

        if not raw_text or not raw_text.strip():
            log.debug("No text extracted: %s", file_path)
            stats.files_empty += 1
            continue

        stats.files_parsed += 1

        # Chunk
        chunks = chunk_document(raw_text, row, splitter)
        if not chunks:
            continue
        stats.total_chunks += len(chunks)

        # Embed
        embeddings = embed_chunks(chunks, model, cfg.embedding_batch_size)

        # Build + buffer ES docs
        es_docs = build_es_documents(row, chunks, embeddings, cfg.es_index)
        bulk_buffer.extend(es_docs)

        # Flush
        if len(bulk_buffer) >= cfg.es_bulk_batch_size:
            ok, err = bulk_index(es_client, bulk_buffer)
            stats.es_success += ok
            stats.es_errors  += err
            log.info(
                "Flushed %d docs | ok=%d err=%d | progress=%d/%d",
                len(bulk_buffer), ok, err, pos, stats.total_rows,
            )
            bulk_buffer = []

    # Final flush
    if bulk_buffer:
        ok, err = bulk_index(es_client, bulk_buffer)
        stats.es_success += ok
        stats.es_errors  += err
        log.info("Final flush: %d docs (ok=%d err=%d)", len(bulk_buffer), ok, err)

    elapsed = time.perf_counter() - t_start
    log.info("[5/5] Pipeline complete in %.1f seconds", elapsed)
    log.info(stats.report())

    if stats.failed_paths:
        log.warning("Failed files (first 20):")
        for fp in stats.failed_paths[:20]:
            log.warning("  %s", fp)

    return stats


if __name__ == "__main__":
    result = run()
    sys.exit(0 if result.es_errors == 0 else 1)
