"""
storage/elasticsearch_client.py — Elasticsearch index management and bulk indexing.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from elasticsearch import Elasticsearch, helpers

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


def _build_mapping(dims: int) -> dict:
    return {
        "mappings": {
            "properties": {
                # Identity
                "ner_id":               {"type": "keyword"},
                "change_id":            {"type": "keyword"},
                "object_id":            {"type": "keyword"},
                "doc_hash":             {"type": "keyword"},
                # Project metadata (filterable)
                "project_type":         {"type": "keyword"},
                "package_family":       {"type": "keyword"},
                "package_name":         {"type": "keyword"},
                "facility":             {"type": "keyword"},
                "lifecyclestate":       {"type": "keyword"},
                "tc_lifecyclestate":    {"type": "keyword"},
                "milestone":            {"type": "keyword"},
                "project_phase":        {"type": "keyword"},
                "ner_change_class":     {"type": "keyword"},
                "tc_project_state":     {"type": "keyword"},
                "implementation_docu":  {"type": "keyword"},
                "triggered_by":         {"type": "keyword"},
                "actual_release_date":  {"type": "keyword"},
                # Rich text (full-text searchable)
                "title":                {"type": "text", "analyzer": "english"},
                "motivation":           {"type": "text", "analyzer": "english"},
                "current_procedure":    {"type": "text", "analyzer": "english"},
                "new_procedure":        {"type": "text", "analyzer": "english"},
                "remark":               {"type": "text", "analyzer": "english"},
                "workdesc":             {"type": "text", "analyzer": "english"},
                "wfcomments":           {"type": "text", "analyzer": "english"},
                "chunk_text":           {"type": "text", "analyzer": "english"},
                # File info
                "sharelink":            {"type": "keyword"},
                "filename":             {"type": "keyword"},
                "file_path":            {"type": "keyword"},
                "file_extension":       {"type": "keyword"},
                # Chunk position
                "chunk_index":          {"type": "integer"},
                "total_chunks":         {"type": "integer"},
                # Housekeeping
                "indexed_at":           {"type": "date"},
                # Vector
                "embedding": {
                    "type":       "dense_vector",
                    "dims":       dims,
                    "index":      True,
                    "similarity": "cosine",
                },
            }
        },
        "settings": {
            "number_of_shards":   2,
            "number_of_replicas": 1,
        },
    }


def build_client(config: Config) -> Elasticsearch:
    kwargs: dict = {
        "request_timeout": config.es_request_timeout,
        "retry_on_timeout": True,
        "max_retries": 3,
    }
    if config.es_username and config.es_password:
        kwargs["basic_auth"] = (config.es_username, config.es_password)
    if config.es_ca_certs:
        kwargs["ca_certs"] = config.es_ca_certs

    client = Elasticsearch(config.es_url, **kwargs)
    log.info("Elasticsearch client ready | url=%s", config.es_url)
    return client


def ensure_index(client: Elasticsearch, config: Config) -> None:
    if client.indices.exists(index=config.es_index):
        log.info("Index already exists: %s", config.es_index)
        return
    client.indices.create(index=config.es_index, body=_build_mapping(config.embedding_dims))
    log.info("Index created: %s (dims=%d)", config.es_index, config.embedding_dims)


def build_es_documents(
    row: pd.Series,
    chunks: list[str],
    embeddings: list[list[float]],
    index: str,
) -> list[dict]:
    """One ES action dict per chunk. _id is deterministic → re-runs upsert."""
    file_path = str(row.get("FILE_PATH", ""))
    doc_hash  = hashlib.md5(file_path.encode()).hexdigest()[:12]
    now       = datetime.now(timezone.utc).isoformat()
    total     = len(chunks)

    return [
        {
            "_index": index,
            "_id":    f"{doc_hash}_{i}",
            "_source": {
                # Identity
                "ner_id":              row.get("NER_ID", ""),
                "change_id":           row.get("CHANGE_ID", ""),
                "object_id":           str(row.get("OBJECT_ID", "")),
                "doc_hash":            doc_hash,
                # Project metadata
                "project_type":        row.get("NER_PROJECT_TYPE", ""),
                "package_family":      row.get("PACKAGE_FAMILY", ""),
                "package_name":        row.get("PACKAGE_NAME", ""),
                "facility":            row.get("FACILITY", ""),
                "lifecyclestate":      row.get("LIFECYCLESTATE", ""),
                "tc_lifecyclestate":   row.get("TC_LIFECYCLESTATE", ""),
                "milestone":           row.get("MILESTONE", ""),
                "project_phase":       row.get("PROJECT_PHASE", ""),
                "ner_change_class":    row.get("NER_CHANGE_CLASS", ""),
                "tc_project_state":    row.get("TC_PROJECT_STATE", ""),
                "implementation_docu": row.get("IMPLEMENTATION_DOCU_IN", ""),
                "triggered_by":        row.get("TRIGGERED_BY", ""),
                "actual_release_date": str(row.get("ACTUAL_RELEASE_DATE", "")),
                # Rich text
                "title":               row.get("TITLE", ""),
                "motivation":          row.get("MOTIVATION", ""),
                "current_procedure":   row.get("CURRENT_PROCEDURE", ""),
                "new_procedure":       row.get("NEW_PROCEDURE", ""),
                "remark":              row.get("REMARK", ""),
                "workdesc":            row.get("WORKDESC", ""),
                "wfcomments":          row.get("WFCOMMENTS", ""),
                # Chunk
                "chunk_text":          chunk,
                "chunk_index":         i,
                "total_chunks":        total,
                # File
                "sharelink":           row.get("SHARELINK", ""),
                "filename":            row.get("FILENAME", ""),
                "file_path":           file_path,
                "file_extension":      Path(file_path).suffix.lower(),
                # Housekeeping
                "indexed_at":          now,
                # Vector
                "embedding":           emb,
            },
        }
        for i, (chunk, emb) in enumerate(zip(chunks, embeddings))
    ]


def bulk_index(client: Elasticsearch, documents: list[dict]) -> tuple[int, int]:
    if not documents:
        return 0, 0
    success, errors = helpers.bulk(client, documents,
                                   raise_on_error=False, raise_on_exception=False)
    if errors:
        for err in errors[:5]:
            log.error("ES bulk error: %s", err)
    return success, len(errors)
