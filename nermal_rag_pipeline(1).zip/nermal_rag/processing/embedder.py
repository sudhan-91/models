"""
processing/embedder.py — Load the embedding model and encode text chunks.
"""

from __future__ import annotations

import numpy as np
from sentence_transformers import SentenceTransformer

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


def load_model(config: Config) -> SentenceTransformer:
    log.info("Loading embedding model: %s (device=%s)",
             config.embedding_model, config.embedding_device)
    model = SentenceTransformer(config.embedding_model, device=config.embedding_device)
    log.info("Embedding model loaded | dims=%d", config.embedding_dims)
    return model


def embed_chunks(
    chunks: list[str],
    model: SentenceTransformer,
    batch_size: int,
) -> list[list[float]]:
    if not chunks:
        return []
    embeddings: np.ndarray = model.encode(
        chunks,
        batch_size=batch_size,
        show_progress_bar=False,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )
    return embeddings.tolist()
