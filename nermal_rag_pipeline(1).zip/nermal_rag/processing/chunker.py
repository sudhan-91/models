"""
processing/chunker.py — Split extracted document text into overlapping chunks.
"""

from __future__ import annotations

import pandas as pd
from langchain.text_splitter import RecursiveCharacterTextSplitter

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


def build_splitter(config: Config) -> RecursiveCharacterTextSplitter:
    return RecursiveCharacterTextSplitter(
        chunk_size=config.chunk_size,
        chunk_overlap=config.chunk_overlap,
        separators=list(config.chunk_separators),
        length_function=len,
    )


def build_metadata_prefix(row: pd.Series) -> str:
    """
    Short metadata preamble prepended to every document before chunking.
    Ensures every chunk inherits project context for accurate retrieval.
    """
    fields = [
        ("NER_ID",       row.get("NER_ID", "")),
        ("Title",        row.get("TITLE", "")),
        ("Package",      f"{row.get('PACKAGE_FAMILY', '')} / {row.get('PACKAGE_NAME', '')}"),
        ("Facility",     row.get("FACILITY", "")),
        ("Milestone",    row.get("MILESTONE", "")),
        ("Doc type",     row.get("IMPLEMENTATION_DOCU_IN", "")),
        ("Phase",        row.get("PROJECT_PHASE", "")),
        ("Motivation",   row.get("MOTIVATION", "")),
    ]
    lines = [f"{k}: {v}" for k, v in fields if str(v).strip()]
    return "\n".join(lines) + "\n\n"


def chunk_document(
    raw_text: str,
    row: pd.Series,
    splitter: RecursiveCharacterTextSplitter,
) -> list[str]:
    """
    Prepend metadata prefix to raw_text and split into chunks.
    Returns empty list if input is blank.
    """
    if not raw_text or not raw_text.strip():
        return []

    full_text = build_metadata_prefix(row) + raw_text
    chunks    = splitter.split_text(full_text)

    log.debug(
        "Chunked | NER_ID=%s | file=%s | chunks=%d",
        row.get("NER_ID", "?"),
        row.get("FILE_PATH", "?"),
        len(chunks),
    )
    return chunks
