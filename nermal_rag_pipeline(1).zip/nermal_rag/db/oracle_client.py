"""
db/oracle_client.py — Oracle connection pool and data extraction.

4-table JOIN:
  DWH_NERMAL
    └─ DWH_TEAMCENTER          (PROCNR = SUBSTR(CHANGE_ID, 1, 21))
         ├─ DWH_TEAMCENTER_BU  (first segment of CHANGE_ID)
         └─ DWH_TEAMCENTER_FILES (OBJECT_ID = ORIG_OBID)
                                  → SHARELINK + FILENAME = full file path
"""

from __future__ import annotations

import cx_Oracle
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Connection
# ─────────────────────────────────────────────────────────────

def build_engine(config: Config) -> Engine:
    """Initialise Oracle instant-client and return a SQLAlchemy engine."""
    try:
        cx_Oracle.init_oracle_client(lib_dir=config.oracle_lib_dir)
        log.info("Oracle instant-client initialised: %s", config.oracle_lib_dir)
    except cx_Oracle.ProgrammingError:
        log.debug("Oracle instant-client already initialised.")

    dsn = cx_Oracle.makedsn(
        config.oracle_dsn,
        config.oracle_port,
        service_name=config.oracle_service,
    )
    engine = create_engine(
        f"oracle+cx_oracle://{config.oracle_user}:{config.oracle_password}@",
        connect_args={"dsn": dsn},
        pool_size=config.oracle_pool_max,
        pool_pre_ping=True,
        echo=False,
    )
    log.info("Oracle engine ready (dsn=%s)", config.oracle_dsn)
    return engine


# ─────────────────────────────────────────────────────────────
# Query
# ─────────────────────────────────────────────────────────────

def _build_query(config: Config) -> str:
    """
    4-table JOIN query.

    DWH_TEAMCENTER_FILES columns used:
      ORIG_OBID   → join key (matches OBJECT_ID in DWH_TEAMCENTER)
      SHARELINK   → UNC share root  e.g. \\fileserver\nermal\
      FILENAME    → document name   e.g. NER_2024_project.pptx
      CREATIONDATE / LASTUPDATE → used for latest-version selection
    """
    return f"""
        SELECT DISTINCT
            REGEXP_SUBSTR(
                n.PROCNR,
                'NER_[[:digit:]]{{4}}/[[:digit:]]{{2}}_[[:digit:]]{{5}}_[[:alpha:]]{{2,4}}'
            )                                   AS NER_ID,

            -- NERMAL fields
            n.TITLE,
            n.MOTIVATION,
            n.CURRENT_PROCEDURE,
            n.NEWPROCEDURE                      AS NEW_PROCEDURE,
            n.PROJECT_TYPE                      AS NER_PROJECT_TYPE,
            n.REMARK,
            n.PROJECT_PHASE,
            n.LIFECYCLESTATE,
            n.PACKAGE_FAMILY,
            n.PACKAGE_NAME,
            n.PK_LOCATION,
            n.FACILITY,
            n.CHANGE_CLASS                      AS NER_CHANGE_CLASS,

            -- TeamCenter fields
            t.CHANGE_ID,
            t.OBJECT_ID,
            t.IMPLEMENTATION_DOCU_IN,
            t.MILESTONE,
            t.ACTUAL_RELEASE_DATE,
            t.WF_TIMESTAMP_IN,
            t.PROJECT_STATE                     AS TC_PROJECT_STATE,
            t.TRIGGERED_BY,
            t.LIFECYCLESTATE                    AS TC_LIFECYCLESTATE,

            -- TeamCenter BU fields
            bu.WORKDESC,
            bu.WFCOMMENTS,
            bu.COSTSAVINGS,

            -- File path (from DWH_TEAMCENTER_FILES)
            f.SHARELINK,
            f.FILENAME,
            f.CREATIONDATE                      AS FILE_CREATIONDATE,
            f.LASTUPDATE                        AS FILE_LASTUPDATE,
            f.AUX_REASON

        FROM {config.table_nermal} n

        LEFT JOIN {config.table_teamcenter} t
            ON n.PROCNR = SUBSTR(t.CHANGE_ID, 1, 21)
           AND t.TC_MODULE = 'Nermal'

        LEFT JOIN {config.table_teamcenter_bu} bu
            ON SUBSTR(t.CHANGE_ID, 1, INSTR(t.CHANGE_ID, ',') - 1) =
               SUBSTR(bu.CHANGE_ID, 1, INSTR(bu.CHANGE_ID, ',') - 1)

        LEFT JOIN {config.table_files} f
            ON t.OBJECT_ID = f.ORIG_OBID

        WHERE n.LIFECYCLESTATE IN ('Released', 'Approved')
          AND f.SHARELINK    IS NOT NULL
          AND f.FILENAME     IS NOT NULL
    """


# ─────────────────────────────────────────────────────────────
# Post-query transforms
# ─────────────────────────────────────────────────────────────

def _build_file_path(df: pd.DataFrame) -> pd.DataFrame:
    """
    Concatenate SHARELINK + FILENAME into a single FILE_PATH column.
    Handles both trailing-slash and non-trailing-slash share roots.
    """
    df["SHARELINK"] = df["SHARELINK"].str.rstrip("/\\")
    df["FILE_PATH"] = df["SHARELINK"] + "\\" + df["FILENAME"]
    return df


def _keep_latest_ppt(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each NER_ID keep only the most recent PPT/PPTX file.
    Sort key: FILE_LASTUPDATE DESC → FILE_CREATIONDATE DESC.
    All other file types are kept as-is.
    """
    df["FILE_EXT"] = df["FILENAME"].str.lower().str.extract(r"(\.[a-z0-9]+)$")

    ppt_mask = df["FILE_EXT"].isin([".pptx", ".ppt"])
    df_ppt   = df[ppt_mask].copy()
    df_other = df[~ppt_mask].copy()

    if not df_ppt.empty:
        df_ppt["FILE_LASTUPDATE"]    = pd.to_datetime(df_ppt["FILE_LASTUPDATE"],    errors="coerce")
        df_ppt["FILE_CREATIONDATE"]  = pd.to_datetime(df_ppt["FILE_CREATIONDATE"],  errors="coerce")
        df_ppt = (
            df_ppt
            .sort_values(
                ["NER_ID", "FILE_LASTUPDATE", "FILE_CREATIONDATE"],
                ascending=[True, False, False],
            )
            .drop_duplicates(subset=["NER_ID"], keep="first")
        )
        log.info("PPT rows after latest-version filter: %d", len(df_ppt))

    return pd.concat([df_ppt, df_other], ignore_index=True)


# ─────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────

def extract_data(engine: Engine, config: Config) -> pd.DataFrame:
    """
    Run the 4-table JOIN, build FILE_PATH, apply latest-PPT filter,
    and return a clean DataFrame ready for document processing.

    Returns:
        One row per (NER_ID, document file).
    """
    query = _build_query(config)
    log.info("Running Oracle 4-table JOIN…")

    with engine.connect() as conn:
        df = pd.read_sql(text(query), conn)

    log.info("Raw rows from Oracle: %d", len(df))

    df = _build_file_path(df)
    df = _keep_latest_ppt(df)
    df = df.drop_duplicates(subset=["NER_ID", "FILE_PATH"]).reset_index(drop=True)

    log.info("Rows after dedup: %d", len(df))
    return df
