"""
config.py — Central configuration for the NERMAL RAG pipeline.
All values are read from environment variables (loaded from .env).
Single Config class — import the singleton `cfg` everywhere.
"""

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    # ── Oracle ────────────────────────────────────────────────
    oracle_user: str            = os.environ.get("ORACLE_USER", "")
    oracle_password: str        = os.environ.get("ORACLE_PASSWORD", "")
    oracle_dsn: str             = os.environ.get("ORACLE_DSN", "dwhrbg.rbg.infineon.com")
    oracle_port: int            = int(os.environ.get("ORACLE_PORT", "1521"))
    oracle_service: str         = os.environ.get("ORACLE_SERVICE", "dwh")
    oracle_lib_dir: str         = os.environ.get("ORACLE_LIB_DIR", r"C:\oracle\instantclient_21_9")
    oracle_pool_min: int        = 1
    oracle_pool_max: int        = 5

    # ── Oracle table names ────────────────────────────────────
    table_nermal: str           = "LOC_RBL.DWH_NERMAL"
    table_teamcenter: str       = "LOC_RBL.DWH_TEAMCENTER"
    table_teamcenter_bu: str    = "LOC_RBL.DWH_TEAMCENTER_BU"
    table_files: str            = "LOC_RBL.DWH_TEAMCENTER_FILES"

    # ── Elasticsearch ─────────────────────────────────────────
    es_url: str                 = os.environ.get("ES_URL", "http://localhost:9200")
    es_index: str               = os.environ.get("ES_INDEX", "nermal_rag")
    es_username: str            = os.environ.get("ES_USER", "")
    es_password: str            = os.environ.get("ES_PASSWORD", "")
    es_ca_certs: str            = os.environ.get("ES_CA_CERTS", "")
    es_request_timeout: int     = 30
    es_bulk_batch_size: int     = 200
    es_num_candidates: int      = 100

    # ── Embedding ─────────────────────────────────────────────
    embedding_model: str        = os.environ.get(
        "EMBEDDING_MODEL", "sentence-transformers/all-mpnet-base-v2"
    )
    embedding_dims: int         = 768
    embedding_batch_size: int   = 32
    embedding_device: str       = os.environ.get("EMBEDDING_DEVICE", "cpu")

    # ── Chunking ──────────────────────────────────────────────
    chunk_size: int             = 512
    chunk_overlap: int          = 50
    chunk_separators: tuple     = ("\n\n", "\n", ". ", " ", "")

    # ── Pipeline ──────────────────────────────────────────────
    log_dir: str                = os.environ.get("LOG_DIR", "logs")
    log_level: str              = os.environ.get("LOG_LEVEL", "INFO")
    supported_extensions: tuple = (".pptx", ".ppt", ".xlsx", ".xls",
                                   ".pdf", ".docx", ".doc")


# Singleton — import this everywhere
cfg = Config()
