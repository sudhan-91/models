import time
import traceback
from typing import Optional


class LoggerServices:
    """Service to log messages into MongoDB."""

    def __init__(self, pre_req):
        self.pre_req = pre_req

    async def log_update_func(self, payload) -> Optional[str]:
        """
        Insert or update logs for a given process/component in MongoDB.
        payload must have:
            - process_id
            - component_name
            - message
            - initial_entry (bool)
        Returns:
            error message string if any, otherwise None
        """
        error = None
        try:
            db_msg = f"{time.asctime()} : {payload.message}"
            collection = self.pre_req.mongo_database_obj["logger_details"]

            # Check if process document exists
            document = await collection.find_one({"process_id": payload.process_id})

            if document:
                # Check if component logs exist
                component_doc = await collection.find_one({f"{payload.component_name}.logs": {"$exists": True}})
                if component_doc and not payload.initial_entry:
                    await collection.update_one(
                        {"process_id": payload.process_id},
                        {"$push": {f"{payload.component_name}.logs": db_msg}}
                    )
                else:
                    await collection.update_one(
                        {"process_id": payload.process_id},
                        {"$set": {payload.component_name: {"logs": [db_msg]}}}
                    )
            else:
                # Create new document for process
                await collection.insert_one({
                    "process_id": payload.process_id,
                    payload.component_name: {"logs": [db_msg]}
                })

        except Exception:
            error = f"Error in log_update_func: {traceback.format_exc()}"

        return error
