

class textToSqlFunc(object):

    def model_initialize(self, payload):
        try:

            self.model = payload.model

        except Exception as exep:
            print(exep)

    async def convert_text_to_sql_func(self, payload):
        sql_query = ""
        try:
            imput_prompt = payload.prompt_template.format(payload.system_prompt, payload.ddl, payload.user_prompt)
            response = self.model.invoke(imput_prompt)
            sql_query = response.content.strip()

        except Exception as exep:
            print(exep)
        return sql_query