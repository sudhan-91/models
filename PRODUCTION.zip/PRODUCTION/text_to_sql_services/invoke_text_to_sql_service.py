import sys
import json
import uvicorn
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
config = json.load(open("../configs/global_config.json"))


from text_to_sql_func import textToSqlFunc

app = FastAPI()
text_to_sql_obj = textToSqlFunc()

class textSql(BaseModel):
    user_id: str
    system_prompt: str
    user_prompt: str
    ddl: str
    prompt_template: str


class modelParams(BaseModel):
    model_name: str

# Create a FastAPI class-based structure
class invokeTextToSQLService:
    def __init__(self):
        # Initialize the FastAPI app
        self.app = FastAPI()
        # Register routes
        self._register_routes()
        self.app.add_event_handler("startup", self.load_text_to_sql_model)

    def _register_routes(self):
        """Method to register the routes"""
        self.app.add_api_route("/qm_bot/text_to_sql", self.convert_text_to_sql, methods=["POST"])
        self.app.add_api_route("/qm_bot/load_text_to_sql_model", self.load_text_to_sql_model, methods=["POST"])

    async def convert_text_to_sql(self, payload: textSql):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await text_to_sql_obj.convert_text_to_sql_func(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

    async def load_text_to_sql_model(self, payload: modelParams):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await text_to_sql_obj.model_initialize(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

# Create an instance of the class to run the FastAPI application
my_app = invokeTextToSQLService()

# The FastAPI app instance
app = my_app.app
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"],
                   allow_headers=["*"], )

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8100)