

class intentClassificationFunc(object):
    def __init__(self):
        self.model = None

    async def startup_load_model_func(self, config):
        try:
            model_name = config['intent_classification']['model_name']
            # get model from config and load the model
            self.model = model_name
        except Exception as exep:
            print(exep)

    async def intent_classifier_model_func(self, payload):
        try:
            self.model = payload.model_name
        except Exception as exep:
            print(exep)

    async def intent_classifier_func(self, payload):
        classfied_intent = ""
        try:
            imput_prompt = payload.prompt_template.format(payload.system_prompt, payload.ddl, payload.user_prompt)
            response = self.model.invoke(imput_prompt)
            classfied_intent = response.content.strip()

        except Exception as exep:
            print(exep)
        return classfied_intent