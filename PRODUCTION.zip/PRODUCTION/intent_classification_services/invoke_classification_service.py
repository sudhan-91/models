import sys
import json
import uvicorn
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
config = json.load(open("../configs/global_config.json"))


from intent_classification_func import intentClassificationFunc

app = FastAPI()
intent_classifier_obj = intentClassificationFunc()

class IntentClassifyRequest(BaseModel):
    user_id: str
    system_prompt: str
    user_prompt: str
    prompt_template: str
    ddl : str


class modelParams(BaseModel):
    model_name: str

# Create a FastAPI class-based structure
class invokeIntentClassificationService:
    def __init__(self):
        # Initialize the FastAPI app
        self.app = FastAPI()
        # Register routes
        self._register_routes()
        self.app.add_event_handler("startup", self.startup_load_model)

    def _register_routes(self):
        """Method to register the routes"""
        self.app.add_api_route("/qm_bot/intent_classifier", self.intent_classifier, methods=["POST"])
        self.app.add_api_route("/qm_bot/intent_classifier_model", self.load_intent_classifier_model, methods=["POST"])

    async def intent_classifier(self, payload: IntentClassifyRequest):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await intent_classifier_obj.intent_classifier_func(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

    async def load_intent_classifier_model(self, payload: modelParams):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await intent_classifier_obj.intent_classifier_model_func(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

    async def startup_load_model(self):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await intent_classifier_obj.startup_load_model_func(config)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

# Create an instance of the class to run the FastAPI application
my_app = invokeIntentClassificationService()

# The FastAPI app instance
app = my_app.app
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"],
                   allow_headers=["*"], )

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8101)