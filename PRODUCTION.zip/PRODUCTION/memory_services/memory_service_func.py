

class memoryServiceFunc(object):

    def memory_model_initialize(self, payload):
        try:

            self.model = payload.model

        except Exception as exep:
            print(exep)

    async def memory_operation_func(self, payload):
        memory_details = ""
        try:
            imput_prompt = payload.prompt_template.format(payload.system_prompt, payload.user_prompt)
            response = self.model.invoke(imput_prompt)
            memory_details = response.content.strip()

        except Exception as exep:
            print(exep)
        return memory_details