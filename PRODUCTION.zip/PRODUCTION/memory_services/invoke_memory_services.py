import sys
import json
import uvicorn
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
config = json.load(open("../configs/global_config.json"))


from memory_service_func import memoryServiceFunc

app = FastAPI()
memory_service_obj = memoryServiceFunc()

class textSql(BaseModel):
    user_id: str
    system_prompt: str
    user_prompt: str
    prompt_template: str


class modelParams(BaseModel):
    model_name: str

# Create a FastAPI class-based structure
class invokeMemoryService:
    def __init__(self):
        # Initialize the FastAPI app
        self.app = FastAPI()
        # Register routes
        self._register_routes()
        self.app.add_event_handler("startup", self.load_memory_model)

    def _register_routes(self):
        """Method to register the routes"""
        self.app.add_api_route("/qm_bot/text_to_sql", self.memory_operation, methods=["POST"])
        self.app.add_api_route("/qm_bot/load_memory_model", self.load_memory_model, methods=["POST"])

    async def memory_operation(self, payload: textSql):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await memory_service_obj.memory_operation_func(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

    async def load_memory_model(self, payload: modelParams):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            response = await memory_service_obj.memory_model_initialize(payload)
        except Exception:
            error = f'Error in tracking_page {sys.exc_info()}'
            print(error)
        return response

# Create an instance of the class to run the FastAPI application
my_app = invokeMemoryService()

# The FastAPI app instance
app = my_app.app
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"],
                   allow_headers=["*"], )

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8103)