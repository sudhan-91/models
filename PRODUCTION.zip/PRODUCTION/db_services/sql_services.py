import asyncio
from fastapi import HTTPException
from typing import Dict, Any, AsyncGenerator


class sqlServices:
    """Postgres query service using LoadPrerequisite instance with context management."""

    def __init__(self, pre_req):
        self.pre_req = pre_req
        self.retry_interval = 2
        self.max_retry_time = 6

    # ---------------- Context Manager for connection + cursor ----------------
    async def get_cursor(self):
        """Async context manager for acquiring connection and cursor safely."""
        if not self.pre_req.pool:
            await self.pre_req.reconnect_pool()

        async with self.pre_req.pool.acquire() as conn:
            async with conn.cursor() as cur:
                yield cur

    # ----------------- Public Query Methods -----------------
    async def dive_select_query_func(self, query: str):
        """Return first row of query as dictionary {column: value}."""
        try:
            async for cur in self.get_cursor():
                await cur.execute(query)
                result = await cur.fetchone()
                if result:
                    columns = [desc[0] for desc in cur.description]
                    return dict(zip(columns, result))
                return {}
        except Exception as e:
            await self.pre_req.reconnect_pool()
            raise HTTPException(status_code=500, detail=f"Error in select_pg_details: {e}")
