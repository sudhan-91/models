import traceback
import json
from typing import Any, Dict, List, Optional, AsyncGenerator


class MongoServices:
    """MongoDB service using LoadPrerequisite instance with async context management."""

    def __init__(self, pre_req):
        self.pre_req = pre_req

    # ---------------- Context Manager for Collection ----------------
    async def get_collection(self, collection_name: str):
        """
        Async context manager for acquiring a MongoDB collection safely.
        """
        if not self.pre_req.mongo_database_obj:
            raise RuntimeError("MongoDB not initialized. Call initialize_prerequisite first.")

        collection = self.pre_req.mongo_database_obj.get_collection(collection_name)
        try:
            yield collection
        finally:
            pass  # No explicit close needed; Mongo client managed by LoadPrerequisite

    # ----------------- Public Mongo Operations -----------------
    async def fetch_collection_func(self, payload):
        """
        Fetch first document from collection based on query.
        """
        result: Dict[str, Any] = {}
        try:
            async for coll in self.get_collection(payload.collection_name):
                cursor = coll.find(payload.query or {})
                docs = await cursor.to_list(length=1)
                if docs:
                    result = docs[0]
                    result.pop("_id", None)  # Remove _id if exists
        except Exception:
            print(f"Error in fetch_collection_func: {traceback.format_exc()}")
        return result

    async def mongo_check_table_exist_func(self, payload):
        """
        Check if collection contains documents matching query.
        """
        exists = False
        try:
            async for coll in self.get_collection(payload.collection_name):
                count = await coll.count_documents(payload.query or {})
                exists = count > 0
        except Exception:
            print(f"Error in mongo_check_table_exist_func: {traceback.format_exc()}")
        return exists

    async def check_key_exists_func(self, payload):
        """
        Check if any document contains the specified key.
        """
        exists = False
        try:
            async for coll in self.get_collection(payload.collection_name):
                cursor = coll.find({payload.key: {"$exists": True}})
                docs = await cursor.to_list(length=1)
                exists = len(docs) > 0
        except Exception:
            print(f"Error in check_key_exists_func: {traceback.format_exc()}")
        return exists

    async def insert_func(self, payload):
        """Insert a single document."""
        try:
            async for coll in self.get_collection(payload.collection_name):
                await coll.insert_one(payload.insert_data)
        except Exception:
            return f"Error in insert_func: {traceback.format_exc()}"
        return None

    async def update_func(self, payload):
        """Update a single document matching query."""
        try:
            async for coll in self.get_collection(payload.collection_name):
                await coll.update_one(payload.query, {"$set": payload.new_values})
        except Exception:
            return f"Error in update_func: {traceback.format_exc()}"
        return None

    async def update_single_func(self, payload):
        """Update or insert a single document (upsert)."""
        try:
            async for coll in self.get_collection(payload.collection_name):
                await coll.update_one(payload.query, {"$set": payload.new_values}, upsert=True)
        except Exception:
            return f"Error in update_single_func: {traceback.format_exc()}"
        return None

    async def update_many_func(self, payload):
        """Update multiple documents matching query."""
        try:
            async for coll in self.get_collection(payload.collection_name):
                await coll.update_many(payload.query, {"$set": payload.new_values})
        except Exception:
            return f"Error in update_many_func: {traceback.format_exc()}"
        return None

    async def select_execute_query_func(self, payload):
        """Run a MongoDB aggregation pipeline."""
        result: Dict[str, Any] = {}
        try:
            async for coll in self.get_collection(payload.collection_name):
                query = json.loads(payload.query)
                cursor = coll.aggregate(query)
                docs = await cursor.to_list(length=None)
                if docs:
                    result = docs[0]
        except Exception:
            print(f"Error in select_execute_query_func: {traceback.format_exc()}")
        return result

    async def fetch_unique_values(self, payload):
        """Fetch distinct values of a key in the collection."""
        values: List[Any] = []
        try:
            async for coll in self.get_collection(payload.collection_name):
                values = await coll.distinct(payload.key)
        except Exception:
            print(f"Error in fetch_unique_values: {traceback.format_exc()}")
        return values
