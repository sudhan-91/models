

class outputFormatFunc(object):

    def load_output_format_model_func(self, payload):
        try:

            self.model = payload.model

        except Exception as exep:
            print(exep)

    async def convert_output_format_func(self, payload):
        output_response = ""
        try:
            imput_prompt = payload.prompt_template.format(payload.system_prompt, payload.user_prompt)
            response = self.model.invoke(imput_prompt)
            output_response = response.content.strip()

        except Exception as exep:
            print(exep)
        return output_response