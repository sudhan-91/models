"""
database.py
===========
SQLAlchemy ORM Models & Database Connection Layer
--------------------------------------------------
Defines all database models for the Production Management data pipeline
and provides a unified connection factory for both:

  • DIVE    – PostgreSQL data-warehouse (source, read-only)
  • MSSQL   – SQL Server metadata store  (destination, read-write)

Usage
-----
    from database import (
        get_dive_session, get_mssql_session,
        ProductionDocumentMetadata, Base
    )

    # Read from DIVE
    with get_dive_session() as session:
        rows = session.query(DiveWTDocument).limit(10).all()

    # Write to MSSQL
    with get_mssql_session() as session:
        session.merge(ProductionDocumentMetadata(**data))
        session.commit()
"""

import os
import logging
from contextlib import contextmanager
from datetime import datetime
from typing import Optional, Generator

from sqlalchemy import (
    create_engine,
    Column, Integer, String, Text, BigInteger,
    DateTime, Boolean, Numeric, event,
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Declarative base (shared by all models)
# ---------------------------------------------------------------------------

Base = declarative_base()

# ---------------------------------------------------------------------------
# Connection configuration  –  driven by environment variables
# ---------------------------------------------------------------------------

# ── DIVE (PostgreSQL) ────────────────────────────────────────────────────────
_DIVE_URL = (
    "postgresql+psycopg2://"
    "{user}:{password}@{host}:{port}/{dbname}"
).format(
    user=     os.getenv("DIVE_USER",     "SINqmagent"),
    password= os.getenv("DIVE_PASSWORD", ""),
    host=     os.getenv("DIVE_HOST",     "dive-prod.infineon.com"),
    port=     os.getenv("DIVE_PORT",     "9996"),
    dbname=   os.getenv("DIVE_DB",       "vdb_std"),
)

# ── MSSQL (SQL Server via pyodbc) ────────────────────────────────────────────
_MSSQL_DRIVER  = os.getenv("MSSQL_DRIVER",   "ODBC Driver 17 for SQL Server")
_MSSQL_SERVER  = os.getenv("MSSQL_SERVER",   "your-mssql-server.database.windows.net")
_MSSQL_DB      = os.getenv("MSSQL_DATABASE", "production_management")
_MSSQL_USER    = os.getenv("MSSQL_USER",     "")
_MSSQL_PASS    = os.getenv("MSSQL_PASSWORD", "")

_MSSQL_URL = (
    "mssql+pyodbc://{user}:{password}@{server}/{database}"
    "?driver={driver}&Encrypt=yes&TrustServerCertificate=no"
    "&Connection+Timeout=30"
).format(
    user=     _MSSQL_USER,
    password= _MSSQL_PASS,
    server=   _MSSQL_SERVER,
    database= _MSSQL_DB,
    driver=   _MSSQL_DRIVER.replace(" ", "+"),
)

# ---------------------------------------------------------------------------
# Engine factory
# ---------------------------------------------------------------------------

_engines: dict = {}


def _get_engine(name: str, url: str, echo: bool = False):
    """
    Return (and cache) a SQLAlchemy engine for the given connection name.
    Uses a QueuePool with sane defaults for a long-running ETL process.
    """
    if name not in _engines:
        try:
            engine = create_engine(
                url,
                poolclass=QueuePool,
                pool_size=5,
                max_overflow=10,
                pool_timeout=30,
                pool_pre_ping=True,          # test connections before use
                echo=echo,
                connect_args={"connect_timeout": 30} if "postgresql" in url else {},
            )
            log.info("Created SQLAlchemy engine for '%s'", name)
            _engines[name] = engine
        except SQLAlchemyError as exc:
            log.error("Failed to create engine for '%s': %s", name, exc)
            raise
    return _engines[name]


def get_dive_engine(echo: bool = False):
    """Return the DIVE PostgreSQL engine."""
    return _get_engine("dive", _DIVE_URL, echo=echo)


def get_mssql_engine(echo: bool = False):
    """Return the MSSQL SQL Server engine."""
    return _get_engine("mssql", _MSSQL_URL, echo=echo)


# ---------------------------------------------------------------------------
# Session factories
# ---------------------------------------------------------------------------

@contextmanager
def get_dive_session(echo: bool = False) -> Generator[Session, None, None]:
    """
    Context manager that yields a read-only SQLAlchemy session for DIVE.

    Example:
        with get_dive_session() as session:
            rows = session.query(DiveWTDocument).all()
    """
    engine = get_dive_engine(echo=echo)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session = SessionLocal()
    try:
        yield session
    except SQLAlchemyError as exc:
        session.rollback()
        log.error("DIVE session error: %s", exc)
        raise
    except Exception as exc:
        session.rollback()
        log.error("Unexpected error in DIVE session: %s", exc)
        raise
    finally:
        session.close()


@contextmanager
def get_mssql_session(echo: bool = False) -> Generator[Session, None, None]:
    """
    Context manager that yields a read-write SQLAlchemy session for MSSQL.

    Example:
        with get_mssql_session() as session:
            session.merge(ProductionDocumentMetadata(**data))
            session.commit()
    """
    engine = get_mssql_engine(echo=echo)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session = SessionLocal()
    try:
        yield session
    except SQLAlchemyError as exc:
        session.rollback()
        log.error("MSSQL session error: %s", exc)
        raise
    except Exception as exc:
        session.rollback()
        log.error("Unexpected error in MSSQL session: %s", exc)
        raise
    finally:
        session.close()


def ensure_mssql_schema() -> None:
    """
    Create all MSSQL tables defined in this module if they do not exist.
    Safe to call on every pipeline startup (CREATE IF NOT EXISTS behaviour).
    """
    try:
        engine = get_mssql_engine()
        Base.metadata.create_all(bind=engine, checkfirst=True)
        log.info("MSSQL schema verified / created for all mapped tables.")
    except SQLAlchemyError as exc:
        log.error("Failed to create MSSQL schema: %s", exc)
        raise
    except Exception as exc:
        log.error("Unexpected error creating MSSQL schema: %s", exc)
        raise


# ===========================================================================
# DIVE (PostgreSQL) – read-only reflection models
# These map to the existing PLM data-warehouse views.
# We use __table_args__ autoload=False and declare only the columns we need
# so the pipeline is not broken by view schema changes on unmapped columns.
# ===========================================================================

class DiveWTContext(Base):
    """
    Maps to:
      vdb_bl_rd_product_lifecycle_management.bl_rdplm_windchill_biz_dim_wt_context

    Used as the filter table in the metadata JOIN query (context_name IN …).
    """
    __tablename__  = "bl_rdplm_windchill_biz_dim_wt_context"
    __table_args__ = {
        "schema": "vdb_bl_rd_product_lifecycle_management",
        "extend_existing": True,
    }

    id           = Column(Numeric, primary_key=True)
    context_name = Column(String(255), nullable=True)
    context_type = Column(String(255), nullable=True)


class DiveWTDocument(Base):
    """
    Maps to:
      vdb_bl_rd_product_lifecycle_management.bl_rdplm_windchill_biz_dim_wt_document

    This is the primary source of PLM document metadata.
    Only the columns confirmed as populated in the notebook exploration are
    declared here; the full view has ~110 columns.
    """
    __tablename__  = "bl_rdplm_windchill_biz_dim_wt_document"
    __table_args__ = {
        "schema": "vdb_bl_rd_product_lifecycle_management",
        "extend_existing": True,
    }

    # ── Identity ─────────────────────────────────────────────────────────────
    id                      = Column(Numeric,      primary_key=True)
    context_id              = Column(Numeric,      nullable=True,  index=True)

    # ── Document reference ────────────────────────────────────────────────────
    doc_number              = Column(String(100),  nullable=True,  index=True)
    version_label           = Column(String(20),   nullable=True)
    latest_released_version = Column(String(20),   nullable=True)

    # ── Classification / type ─────────────────────────────────────────────────
    type                    = Column(String(100),  nullable=True,  index=True)
    doc_sub_type            = Column(String(100),  nullable=True)
    doc_type                = Column(String(100),  nullable=True)

    # ── Names & descriptions ──────────────────────────────────────────────────
    name                    = Column(String(500),  nullable=True)
    title                   = Column(String(500),  nullable=True)
    description             = Column(Text,         nullable=True)

    # ── Lifecycle ─────────────────────────────────────────────────────────────
    state                   = Column(String(50),   nullable=True,  index=True)
    lifecycle               = Column(String(100),  nullable=True)

    # ── Ownership & classification ────────────────────────────────────────────
    creator_display_name    = Column(String(200),  nullable=True)
    classification          = Column(String(100),  nullable=True)
    doc_is_binding          = Column(String(50),   nullable=True)
    doc_language            = Column(String(50),   nullable=True)

    # ── Organisation attributes ───────────────────────────────────────────────
    function                = Column(String(100),  nullable=True)
    organization_unit       = Column(String(200),  nullable=True)
    production_area         = Column(String(200),  nullable=True)
    context_name            = Column(String(200),  nullable=True)

    # ── File information ──────────────────────────────────────────────────────
    filename                = Column(String(500),  nullable=True)
    file_format             = Column(String(100),  nullable=True)
    file_size               = Column(Numeric,      nullable=True)

    # ── Timestamps ────────────────────────────────────────────────────────────
    created_on              = Column(DateTime,     nullable=True)
    updated_on              = Column(DateTime,     nullable=True)

    # ── Flags ─────────────────────────────────────────────────────────────────
    deleted_flag            = Column(Integer,      nullable=True, default=0)


# ===========================================================================
# MSSQL (SQL Server) – read-write destination models
# ===========================================================================

class ProductionDocumentMetadata(Base):
    """
    Destination table: dbo.production_document_metadata

    One row per PLM document revision.  Written (upserted via session.merge)
    by invoke_production_data_prep.py after each document is processed.

    Mirrors the structure discussed in the pipeline spec:
      document_id, Number, Version, Name, Owner, … created_on, updated_on
    """
    __tablename__  = "production_document_metadata"
    __table_args__ = {"schema": "dbo"}

    # ── Primary Key ───────────────────────────────────────────────────────────
    id                  = Column(Integer,      primary_key=True, autoincrement=True, index=True)

    # ── PLM document identity ─────────────────────────────────────────────────
    document_id         = Column(String(50),   nullable=False, unique=True, index=True)
    number              = Column(String(100),  nullable=True,  index=True)
    version             = Column(String(20),   nullable=True)

    # ── Document metadata ─────────────────────────────────────────────────────
    name                = Column(String(500),  nullable=True)
    doc_title           = Column(String(500),  nullable=True)
    owner               = Column(String(200),  nullable=True)

    # ── Classification ────────────────────────────────────────────────────────
    type                = Column(String(100),  nullable=True)
    doc_sub_type        = Column(String(100),  nullable=True)
    state               = Column(String(50),   nullable=True,  index=True)
    lifecycle_template  = Column(String(100),  nullable=True)
    classification      = Column(String(100),  nullable=True)
    binding_type        = Column(String(50),   nullable=True)
    language            = Column(String(50),   nullable=True)
    doc_type_label      = Column(String(100),  nullable=True)

    # ── Organisation ──────────────────────────────────────────────────────────
    org_context         = Column(String(200),  nullable=True,  index=True)
    function_area       = Column(String(100),  nullable=True)
    organization_unit   = Column(String(200),  nullable=True)
    production_area     = Column(String(200),  nullable=True)

    # ── File information ──────────────────────────────────────────────────────
    filename            = Column(String(500),  nullable=True)
    file_format         = Column(String(100),  nullable=True)
    file_size_bytes     = Column(BigInteger,   nullable=True)

    # ── Timestamps ────────────────────────────────────────────────────────────
    created_on          = Column(DateTime,     nullable=True)
    updated_on          = Column(DateTime,     nullable=True)
    indexed_at          = Column(DateTime,     nullable=True, default=datetime.utcnow)

    # ── Pipeline tracking ─────────────────────────────────────────────────────
    deleted_flag        = Column(Boolean,      nullable=True, default=False)
    pipeline_run_id     = Column(String(50),   nullable=True)

    def __repr__(self) -> str:
        return (
            f"<ProductionDocumentMetadata "
            f"document_id={self.document_id!r} "
            f"number={self.number!r} "
            f"state={self.state!r}>"
        )


class ProductionDocumentChunk(Base):
    """
    Staging table: dbo.production_document_chunk

    One row per text chunk extracted from a PLM document.
    Serves as a durable staging area before Elasticsearch indexing,
    and allows re-indexing without re-downloading/re-parsing documents.

    The 'content' field stores the chunk text plus S3 image reference links
    (appended to chunk_seq = 0 as  [IMAGES]\\ns3://…).
    """
    __tablename__  = "production_document_chunk"
    __table_args__ = {"schema": "dbo"}

    # ── Primary Key ───────────────────────────────────────────────────────────
    id              = Column(Integer,     primary_key=True, autoincrement=True, index=True)

    # ── Document reference ────────────────────────────────────────────────────
    document_id     = Column(String(50),  nullable=False, index=True)
    number          = Column(String(100), nullable=True)
    filename        = Column(String(500), nullable=True)
    filepath        = Column(String(500), nullable=True)   # PLM reference path
    filetype        = Column(String(20),  nullable=True)

    # ── Chunk ─────────────────────────────────────────────────────────────────
    chunk_seq       = Column(Integer,     nullable=False)
    content         = Column(Text,        nullable=True)   # text + optional S3 image refs

    # ── Pipeline tracking ─────────────────────────────────────────────────────
    indexed_at      = Column(DateTime,    nullable=True, default=datetime.utcnow)
    pipeline_run_id = Column(String(50),  nullable=True)
    es_indexed      = Column(Boolean,     nullable=True, default=False)   # set True after ES ingest

    def __repr__(self) -> str:
        return (
            f"<ProductionDocumentChunk "
            f"document_id={self.document_id!r} "
            f"chunk_seq={self.chunk_seq}>"
        )


class ProductionDocumentImage(Base):
    """
    Tracking table: dbo.production_document_image

    One row per image extracted from a PLM document and uploaded to S3.
    Provides an audit trail linking document → image → S3 URI.
    """
    __tablename__  = "production_document_image"
    __table_args__ = {"schema": "dbo"}

    # ── Primary Key ───────────────────────────────────────────────────────────
    id              = Column(Integer,     primary_key=True, autoincrement=True, index=True)

    # ── Document reference ────────────────────────────────────────────────────
    document_id     = Column(String(50),  nullable=False, index=True)
    number          = Column(String(100), nullable=True)

    # ── Image identity ────────────────────────────────────────────────────────
    image_id        = Column(String(32),  nullable=False)  # sha256[:16] hex
    s3_uri          = Column(String(500), nullable=True)   # s3://<bucket>/production_document/images/<doc_id>/<img_id>.jpg
    s3_key          = Column(String(500), nullable=True)

    # ── Pipeline tracking ─────────────────────────────────────────────────────
    uploaded_at     = Column(DateTime,    nullable=True, default=datetime.utcnow)
    pipeline_run_id = Column(String(50),  nullable=True)

    def __repr__(self) -> str:
        return (
            f"<ProductionDocumentImage "
            f"document_id={self.document_id!r} "
            f"image_id={self.image_id!r}>"
        )
