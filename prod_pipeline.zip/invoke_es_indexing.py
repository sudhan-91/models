"""
invoke_es_indexing.py
=====================
Elasticsearch (ELK) Indexing Pipeline for PLM Production Documents
--------------------------------------------------------------------
Reads the JSON manifest produced by invoke_production_data_prep.py and
writes two Elasticsearch indices:

  • production_document_metadata  – one doc per PLM document (thin, fast-filter)
  • production_document_content   – one doc per text chunk with dense_vector
                                    embedding field ready for KNN/semantic search

Usage
-----
    python invoke_es_indexing.py
    python invoke_es_indexing.py --manifest staging/abc123_manifest.json
    python invoke_es_indexing.py --reindex     # destructive full re-index
    python invoke_es_indexing.py --dry-run     # validate without writing
"""

import os
import sys
import json
import logging
import argparse
import datetime
from pathlib import Path
from typing import Optional, Generator

import urllib3
from elasticsearch import Elasticsearch, helpers
from elasticsearch.exceptions import (
    ConnectionError as ESConnectionError,
    TransportError,
    NotFoundError,
)
from sentence_transformers import SentenceTransformer

# ── local ORM layer (used to mark chunks as es_indexed=True) ────────────────
from database import get_mssql_session, ProductionDocumentChunk
from sqlalchemy.exc import SQLAlchemyError

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ES_CONFIG = {
    "hosts":          os.getenv("ES_HOSTS", "https://your-elk-host:9200").split(","),
    "username":       os.getenv("ES_USER",  "elastic"),
    "password":       os.getenv("ES_PASSWORD", ""),
    "ca_certs":       os.getenv("ES_CA_CERTS", ""),
    "verify_certs":   os.getenv("ES_VERIFY_CERTS", "false").lower() == "true",
    "metadata_index": os.getenv("ES_META_INDEX",    "production_document_metadata"),
    "content_index":  os.getenv("ES_CONTENT_INDEX", "production_document_content"),
}

EMBEDDING_CONFIG = {
    "model_name": os.getenv("EMBEDDING_MODEL",      "all-MiniLM-L6-v2"),
    "batch_size": int(os.getenv("EMBEDDING_BATCH_SIZE", "64")),
    "vector_dim": int(os.getenv("EMBEDDING_DIM",        "384")),
}

PIPELINE_CONFIG = {
    "staging_dir": Path("./staging"),
    "bulk_batch":  int(os.getenv("ES_BULK_BATCH", "200")),
}

# ---------------------------------------------------------------------------
# Index mappings
# ---------------------------------------------------------------------------

METADATA_MAPPING = {
    "mappings": {
        "properties": {
            "document_id":  {"type": "keyword"},
            "number":       {"type": "keyword"},
            "filename":     {"type": "keyword"},
            "filepath":     {"type": "keyword"},
            "filetype":     {"type": "keyword"},
            "name":         {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 512}}},
            "title":        {"type": "text", "fields": {"keyword": {"type": "keyword", "ignore_above": 512}}},
            "state":        {"type": "keyword"},
            "version":      {"type": "keyword"},
            "owner":        {"type": "keyword"},
            "org_context":  {"type": "keyword"},
            "function":     {"type": "keyword"},
            "org_unit":     {"type": "keyword"},
            "s3_images":    {"type": "keyword"},
            "created_on":   {"type": "date"},
            "updated_on":   {"type": "date"},
            "indexed_at":   {"type": "date"},
            "run_id":       {"type": "keyword"},
        }
    },
    "settings": {
        "number_of_shards":   1,
        "number_of_replicas": 1,
        "refresh_interval":   "30s",
    },
}

CONTENT_MAPPING = {
    "mappings": {
        "properties": {
            "document_id":  {"type": "keyword"},
            "number":       {"type": "keyword"},
            "filename":     {"type": "keyword"},
            "filepath":     {"type": "keyword"},
            "filetype":     {"type": "keyword"},
            "chunk_seq":    {"type": "integer"},
            "content": {
                "type":     "text",
                "analyzer": "english",
                "fields":   {"raw": {"type": "keyword", "ignore_above": 2048}},
            },
            "embedding": {
                "type":       "dense_vector",
                "dims":       EMBEDDING_CONFIG["vector_dim"],
                "index":      True,
                "similarity": "cosine",
            },
            "name":        {"type": "text"},
            "title":       {"type": "text"},
            "state":       {"type": "keyword"},
            "version":     {"type": "keyword"},
            "owner":       {"type": "keyword"},
            "org_context": {"type": "keyword"},
            "function":    {"type": "keyword"},
            "org_unit":    {"type": "keyword"},
            "s3_images":   {"type": "keyword"},
            "created_on":  {"type": "date"},
            "updated_on":  {"type": "date"},
            "indexed_at":  {"type": "date"},
            "run_id":      {"type": "keyword"},
        }
    },
    "settings": {
        "number_of_shards":   2,
        "number_of_replicas": 1,
        "refresh_interval":   "30s",
    },
}


# ===========================================================================
# ES client helpers
# ===========================================================================

def build_es_client() -> Optional[Elasticsearch]:
    """
    Construct and return an authenticated Elasticsearch client.
    Returns None if the cluster cannot be reached.
    """
    try:
        kwargs = dict(
            hosts=ES_CONFIG["hosts"],
            basic_auth=(ES_CONFIG["username"], ES_CONFIG["password"]),
            verify_certs=ES_CONFIG["verify_certs"],
        )
        if ES_CONFIG["ca_certs"]:
            kwargs["ca_certs"] = ES_CONFIG["ca_certs"]

        client = Elasticsearch(**kwargs)
        if not client.ping():
            log.error("Elasticsearch ping failed – cluster unreachable at %s", ES_CONFIG["hosts"])
            return None
        log.info("Connected to Elasticsearch: %s", ES_CONFIG["hosts"])
        return client

    except ESConnectionError as exc:
        log.error("ES connection error: %s", exc)
        return None
    except Exception as exc:
        log.error("Unexpected error building ES client: %s", exc)
        return None


def ensure_index(
    es: Elasticsearch,
    index_name: str,
    mapping: dict,
    force_recreate: bool = False,
) -> bool:
    """
    Create the named ES index with the given mapping if it does not exist.
    If force_recreate=True, delete first (destructive – use with caution).
    Returns True on success, False on error.
    """
    try:
        if force_recreate:
            try:
                if es.indices.exists(index=index_name):
                    log.warning("force_recreate=True → deleting '%s'", index_name)
                    es.indices.delete(index=index_name)
            except NotFoundError:
                pass  # index didn't exist – fine
            except TransportError as exc:
                log.error("ES transport error deleting index '%s': %s", index_name, exc)
                return False

        if not es.indices.exists(index=index_name):
            es.indices.create(index=index_name, body=mapping)
            log.info("Created index: %s", index_name)
        else:
            log.info("Index already exists: %s (no changes)", index_name)
        return True

    except TransportError as exc:
        log.error("ES transport error ensuring index '%s': %s", index_name, exc)
        return False
    except Exception as exc:
        log.error("Unexpected error ensuring index '%s': %s", index_name, exc)
        return False


# ===========================================================================
# Embedding model
# ===========================================================================

def load_embedding_model(model_name: str) -> Optional[SentenceTransformer]:
    """
    Load and return a SentenceTransformer model.
    Returns None on error so callers can abort cleanly.
    """
    try:
        log.info("Loading embedding model: %s …", model_name)
        model = SentenceTransformer(model_name)
        log.info("Embedding model loaded.  Vector dim = %d", EMBEDDING_CONFIG["vector_dim"])
        return model
    except Exception as exc:
        log.error("Failed to load embedding model '%s': %s", model_name, exc)
        return None


# ===========================================================================
# Manifest helpers
# ===========================================================================

def find_latest_manifest(staging_dir: Path) -> Optional[Path]:
    """
    Return the most recently modified manifest JSON file in staging_dir.
    Returns None if none found or on error.
    """
    try:
        candidates = sorted(
            staging_dir.glob("*_manifest.json"),
            key=lambda p: p.stat().st_mtime,
        )
        return candidates[-1] if candidates else None
    except Exception as exc:
        log.error("Error scanning staging dir %s: %s", staging_dir, exc)
        return None


def load_manifest(manifest_path: Path) -> list[dict]:
    """
    Read and basic-validate the manifest JSON file.
    Returns empty list on error.
    """
    try:
        log.info("Loading manifest: %s", manifest_path)
        with manifest_path.open(encoding="utf-8") as fh:
            records = json.load(fh)
        if not isinstance(records, list):
            log.error("Manifest must be a JSON array, got %s", type(records))
            return []
        log.info("Manifest contains %d document records.", len(records))
        return records
    except (OSError, json.JSONDecodeError) as exc:
        log.error("Failed to load manifest %s: %s", manifest_path, exc)
        return []
    except Exception as exc:
        log.error("Unexpected error loading manifest %s: %s", manifest_path, exc)
        return []


# ===========================================================================
# Document generators for bulk indexing
# ===========================================================================

def generate_metadata_docs(records: list[dict]) -> Generator[dict, None, None]:
    """
    Yield one ES bulk-action dict per PLM document (no embedding).
    Skips individual records that cannot be serialised.
    """
    now = datetime.datetime.utcnow().isoformat()
    for rec in records:
        try:
            yield {
                "_index": ES_CONFIG["metadata_index"],
                "_id":    rec["document_id"],
                "_source": {
                    "document_id": rec["document_id"],
                    "number":      rec.get("number"),
                    "filename":    rec.get("filename"),
                    "filepath":    rec.get("filepath"),
                    "filetype":    rec.get("filetype"),
                    "name":        rec.get("name"),
                    "title":       rec.get("title"),
                    "state":       rec.get("state"),
                    "version":     rec.get("version"),
                    "owner":       rec.get("owner"),
                    "org_context": rec.get("org_context"),
                    "function":    rec.get("function"),
                    "org_unit":    rec.get("org_unit"),
                    "s3_images":   rec.get("s3_images", []),
                    "created_on":  rec.get("created_on"),
                    "updated_on":  rec.get("updated_on"),
                    "indexed_at":  now,
                    "run_id":      rec.get("run_id"),
                },
            }
        except Exception as exc:
            log.warning("Skipping metadata doc for %s: %s", rec.get("document_id"), exc)


def generate_content_docs(
    records: list[dict],
    model: SentenceTransformer,
    batch_size: int = 64,
) -> Generator[dict, None, None]:
    """
    Yield one ES bulk-action dict per text chunk, with dense_vector embedding.
    Embeddings are computed in batches for throughput.
    Skips chunks that fail serialisation or embedding.
    """
    now = datetime.datetime.utcnow().isoformat()

    # Flatten all (record, seq, text) triples
    flat_chunks: list[tuple[dict, int, str]] = []
    for rec in records:
        try:
            for chunk in rec.get("chunks", []):
                flat_chunks.append((rec, chunk["chunk_seq"], chunk["content"]))
        except Exception as flat_exc:
            log.warning("Could not flatten chunks for %s: %s", rec.get("document_id"), flat_exc)

    log.info("Total chunks to embed + index: %d", len(flat_chunks))

    for batch_start in range(0, len(flat_chunks), batch_size):
        batch = flat_chunks[batch_start: batch_start + batch_size]

        try:
            texts = [item[2] for item in batch]
            embeddings = model.encode(
                texts,
                batch_size=batch_size,
                show_progress_bar=False,
                normalize_embeddings=True,
            )
        except Exception as embed_exc:
            log.error("Embedding batch starting at %d failed: %s – skipping batch",
                      batch_start, embed_exc)
            continue

        for (rec, seq, content), embedding in zip(batch, embeddings):
            try:
                doc_id       = rec["document_id"]
                chunk_doc_id = f"{doc_id}_chunk_{seq:05d}"
                yield {
                    "_index": ES_CONFIG["content_index"],
                    "_id":    chunk_doc_id,
                    "_source": {
                        "document_id": doc_id,
                        "number":      rec.get("number"),
                        "filename":    rec.get("filename"),
                        "filepath":    rec.get("filepath"),
                        "filetype":    rec.get("filetype"),
                        "chunk_seq":   seq,
                        "content":     content,
                        "embedding":   embedding.tolist(),
                        "name":        rec.get("name"),
                        "title":       rec.get("title"),
                        "state":       rec.get("state"),
                        "version":     rec.get("version"),
                        "owner":       rec.get("owner"),
                        "org_context": rec.get("org_context"),
                        "function":    rec.get("function"),
                        "org_unit":    rec.get("org_unit"),
                        "s3_images":   rec.get("s3_images", []),
                        "created_on":  rec.get("created_on"),
                        "updated_on":  rec.get("updated_on"),
                        "indexed_at":  now,
                        "run_id":      rec.get("run_id"),
                    },
                }
            except Exception as doc_exc:
                log.warning("Skipping content chunk %s seq=%d: %s",
                            rec.get("document_id"), seq, doc_exc)

        processed = min(batch_start + batch_size, len(flat_chunks))
        if (batch_start // batch_size + 1) % 10 == 0:
            log.info("  Embedded %d / %d chunks …", processed, len(flat_chunks))


# ===========================================================================
# Bulk indexer
# ===========================================================================

def bulk_index(
    es: Elasticsearch,
    actions: Generator,
    index_label: str,
    dry_run: bool = False,
) -> tuple[int, int]:
    """
    Stream bulk-index actions to Elasticsearch.
    Returns (success_count, error_count).
    Handles dry-run mode (count only, no writes).
    """
    if dry_run:
        try:
            count = sum(1 for _ in actions)
            log.info("[DRY-RUN] Would index %d documents into '%s'", count, index_label)
            return count, 0
        except Exception as exc:
            log.error("[DRY-RUN] Error counting actions for '%s': %s", index_label, exc)
            return 0, 0

    success, errors = 0, 0
    try:
        for ok, info in helpers.streaming_bulk(
            es,
            actions,
            chunk_size=PIPELINE_CONFIG["bulk_batch"],
            raise_on_error=False,
        ):
            if ok:
                success += 1
            else:
                errors += 1
                try:
                    log.warning("Bulk index error: %s", info)
                except Exception:
                    log.warning("Bulk index error (could not format info)")

    except TransportError as exc:
        log.error("ES transport error during bulk indexing of '%s': %s", index_label, exc)
    except Exception as exc:
        log.error("Unexpected error during bulk indexing of '%s': %s", index_label, exc)

    log.info("Indexed '%s': %d success, %d errors", index_label, success, errors)
    return success, errors


# ===========================================================================
# MSSQL post-index flag update
# ===========================================================================

def mark_chunks_indexed(doc_ids: list[str]) -> None:
    """
    Set es_indexed=True on all ProductionDocumentChunk rows for the given
    document_ids.  Silently logs and continues on any error.
    """
    if not doc_ids:
        return
    try:
        with get_mssql_session() as session:
            try:
                session.query(ProductionDocumentChunk).filter(
                    ProductionDocumentChunk.document_id.in_(doc_ids)
                ).update({"es_indexed": True}, synchronize_session=False)
                session.commit()
                log.info("Marked es_indexed=True for %d document(s).", len(doc_ids))
            except Exception as update_exc:
                session.rollback()
                log.warning("Could not mark chunks as indexed: %s", update_exc)
    except SQLAlchemyError as exc:
        log.error("SQLAlchemy error in mark_chunks_indexed: %s", exc)
    except Exception as exc:
        log.error("Unexpected error in mark_chunks_indexed: %s", exc)


# ===========================================================================
# Main
# ===========================================================================

def run_indexing(
    manifest_path: Optional[Path] = None,
    force_reindex: bool = False,
    dry_run: bool = False,
) -> None:
    """
    Orchestrate the full ES indexing pass:
      1. Discover / load manifest
      2. Connect to Elasticsearch
      3. Ensure indices exist (correct mappings)
      4. Load embedding model
      5. Bulk-index metadata documents
      6. Bulk-index content (chunk + embedding) documents
      7. Mark chunks as indexed in MSSQL
    """
    # ── 1. Manifest ──────────────────────────────────────────────────────────
    try:
        if manifest_path is None:
            manifest_path = find_latest_manifest(PIPELINE_CONFIG["staging_dir"])
        if manifest_path is None or not manifest_path.exists():
            log.error("No manifest found in %s.  Run invoke_production_data_prep.py first.",
                      PIPELINE_CONFIG["staging_dir"])
            sys.exit(1)
    except Exception as exc:
        log.error("Error resolving manifest path: %s", exc)
        sys.exit(1)

    records = load_manifest(manifest_path)
    if not records:
        log.warning("Manifest is empty – nothing to index.")
        return

    # ── 2. Elasticsearch client ───────────────────────────────────────────────
    es = build_es_client()
    if es is None:
        log.error("Cannot proceed – Elasticsearch is unreachable.")
        sys.exit(1)

    # ── 3. Index setup ────────────────────────────────────────────────────────
    meta_ok    = ensure_index(es, ES_CONFIG["metadata_index"], METADATA_MAPPING, force_recreate=force_reindex)
    content_ok = ensure_index(es, ES_CONFIG["content_index"],  CONTENT_MAPPING,  force_recreate=force_reindex)
    if not meta_ok or not content_ok:
        log.error("Index setup failed – aborting.")
        sys.exit(1)

    # ── 4. Embedding model ───────────────────────────────────────────────────
    model = load_embedding_model(EMBEDDING_CONFIG["model_name"])
    if model is None:
        log.error("Cannot proceed – embedding model failed to load.")
        sys.exit(1)

    # ── 5. Metadata index ────────────────────────────────────────────────────
    log.info("Indexing metadata documents …")
    meta_success, meta_errors = bulk_index(
        es, generate_metadata_docs(records),
        ES_CONFIG["metadata_index"], dry_run=dry_run,
    )

    # ── 6. Content / embedding index ─────────────────────────────────────────
    log.info("Generating embeddings and indexing content chunks …")
    content_success, content_errors = bulk_index(
        es,
        generate_content_docs(records, model, EMBEDDING_CONFIG["batch_size"]),
        ES_CONFIG["content_index"], dry_run=dry_run,
    )

    # ── 7. Update MSSQL es_indexed flag ──────────────────────────────────────
    if not dry_run and content_success > 0:
        doc_ids = [r["document_id"] for r in records if "document_id" in r]
        mark_chunks_indexed(doc_ids)

    # ── Summary ───────────────────────────────────────────────────────────────
    log.info("=" * 60)
    log.info("ES Indexing complete.")
    log.info("  Metadata docs :  %d indexed, %d errors", meta_success,    meta_errors)
    log.info("  Content chunks:  %d indexed, %d errors", content_success, content_errors)
    if meta_errors + content_errors > 0:
        log.warning("Some records had errors – review the logs above.")
    log.info("=" * 60)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    try:
        parser = argparse.ArgumentParser(
            description="Index PLM Production documents into Elasticsearch."
        )
        parser.add_argument(
            "--manifest", type=Path, default=None,
            help="Path to a specific manifest JSON file.",
        )
        parser.add_argument(
            "--reindex", action="store_true",
            help="Delete and recreate both ES indices before loading (DESTRUCTIVE).",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Validate + embed without writing to Elasticsearch.",
        )
        return parser.parse_args()
    except Exception as exc:
        log.error("Argument parsing error: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    args = parse_args()
    run_indexing(
        manifest_path=args.manifest,
        force_reindex=args.reindex,
        dry_run=args.dry_run,
    )
