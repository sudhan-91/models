"""
invoke_production_data_prep.py
==============================
Production Management Data Preparation Pipeline
------------------------------------------------
Orchestrates the full ETL pipeline for PLM Production documents:
  1. Fetch document metadata from DIVE (PostgreSQL) via the PLM data warehouse view
  2. Authenticate to PLM Publishing (Windchill) via OAuth2 ROPC flow
  3. Download the primary content file for each document via the PLM OData API
  4. Parse/extract text content from .docx / .doc / .pdf files
  5. Extract images from each document and upload them to S3
  6. Chunk the extracted text and write enriched records to MSSQL (via ORM)
  7. Emit a manifest of processed documents for downstream ES indexing

Storage layout
--------------
S3  : s3://<BUCKET>/production_document/images/<document_id>/<image_id>
MSSQL: dbo.production_document_metadata   (one row per document)
       dbo.production_document_chunk       (one row per text chunk)
       dbo.production_document_image       (one row per uploaded image)
Staging JSON manifest written to ./staging/<run_id>_manifest.json
"""

import os
import io
import json
import uuid
import base64
import logging
import hashlib
import datetime
from pathlib import Path
from typing import Optional

import boto3
import requests
import pandas as pd
from PIL import Image
from docx import Document as DocxDocument
import fitz  # PyMuPDF
import urllib3
from sqlalchemy.exc import SQLAlchemyError

# ── Local ORM layer ──────────────────────────────────────────────────────────
from database import (
    get_dive_session,
    get_mssql_session,
    ensure_mssql_schema,
    DiveWTDocument,
    DiveWTContext,
    ProductionDocumentMetadata,
    ProductionDocumentChunk,
    ProductionDocumentImage,
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration  –  override via environment variables in production
# ---------------------------------------------------------------------------

PLM_AUTH = {
    "token_url":     os.getenv("PLM_TOKEN_URL",    "https://ilogin.infineon.com/as/token.oauth2"),
    "client_id":     os.getenv("PLM_CLIENT_ID",    "PLM ROPC"),
    "client_secret": os.getenv("PLM_CLIENT_SECRET",""),
    "username":      os.getenv("PLM_USER",         "SINqmagent"),
    "password":      os.getenv("PLM_PASSWORD",     ""),
    "scope":         "profile",
}

PLM_API = {
    "base_url": os.getenv("PLM_API_BASE", "https://gravitee-gw-plm.intra.infineon.com/plm/dms/oauth/servlet/odata/v7"),
    "api_key":  os.getenv("PLM_API_KEY",  ""),
}

S3_CONFIG = {
    "bucket":       os.getenv("S3_BUCKET",         "your-s3-bucket"),
    "region":       os.getenv("AWS_DEFAULT_REGION", "ap-southeast-1"),
    "image_prefix": "production_document/images",
}

PIPELINE_CONFIG = {
    "target_contexts": [
        "cDtC_BE",
        "eQM_BE_QM_QMS_MT",
        "cDtC_BE_FMEA_CP_ProcessFlow",
        "cDtC_Bonding_Plan_Melaka",
    ],
    "document_type":       "Production: Procedure",
    "staging_dir":         Path("./staging"),
    "download_dir":        Path("./downloads"),
    "chunk_size":          500,
    "chunk_overlap":       50,
    "supported_formats":   {".docx", ".doc", ".pdf"},
    "max_image_dimension": 1024,
}

PIPELINE_CONFIG["staging_dir"].mkdir(parents=True, exist_ok=True)
PIPELINE_CONFIG["download_dir"].mkdir(parents=True, exist_ok=True)

_token_cache: dict = {}


# ===========================================================================
# 1. DIVE  –  fetch document metadata via SQLAlchemy ORM
# ===========================================================================

def fetch_plm_metadata() -> pd.DataFrame:
    """
    Query the DIVE PostgreSQL data-warehouse using the ORM to retrieve all
    Production: Procedure documents in the configured contexts.
    Returns a Pandas DataFrame; returns empty DataFrame on any error.
    """
    try:
        with get_dive_session() as session:
            log.info("Querying DIVE for PLM document metadata …")
            rows = (
                session.query(DiveWTDocument)
                .join(DiveWTContext, DiveWTDocument.context_id == DiveWTContext.id)
                .filter(
                    DiveWTContext.context_name.in_(PIPELINE_CONFIG["target_contexts"]),
                    DiveWTDocument.type == PIPELINE_CONFIG["document_type"],
                )
                .all()
            )
            records = []
            for row in rows:
                try:
                    records.append({
                        "id":                      str(row.id),
                        "doc_number":              row.doc_number,
                        "version_label":           row.version_label,
                        "latest_released_version": row.latest_released_version,
                        "name":                    row.name,
                        "title":                   row.title,
                        "type":                    row.type,
                        "doc_sub_type":            row.doc_sub_type,
                        "doc_type":                row.doc_type,
                        "state":                   row.state,
                        "lifecycle":               row.lifecycle,
                        "creator_display_name":    row.creator_display_name,
                        "classification":          row.classification,
                        "doc_is_binding":          row.doc_is_binding,
                        "doc_language":            row.doc_language,
                        "function":                row.function,
                        "organization_unit":       row.organization_unit,
                        "production_area":         row.production_area,
                        "context_name":            row.context_name,
                        "filename":                row.filename,
                        "file_format":             row.file_format,
                        "file_size":               str(row.file_size) if row.file_size else None,
                        "created_on":              row.created_on,
                        "updated_on":              row.updated_on,
                        "deleted_flag":            row.deleted_flag or 0,
                    })
                except Exception as row_exc:
                    log.warning("Skipping malformed DIVE row: %s", row_exc)

            df = pd.DataFrame(records)
            log.info("Fetched %d document rows from DIVE.", len(df))
            return df

    except SQLAlchemyError as exc:
        log.error("SQLAlchemy error fetching DIVE metadata: %s", exc)
        return pd.DataFrame()
    except Exception as exc:
        log.error("Unexpected error fetching DIVE metadata: %s", exc)
        return pd.DataFrame()


# ===========================================================================
# 2. PLM OAuth2  –  acquire / refresh access token
# ===========================================================================

def get_plm_access_token(force_refresh: bool = False) -> str:
    """
    Obtain a Bearer token via ROPC OAuth2.  Cached in-process.
    Raises RuntimeError on failure so callers can abort cleanly.
    """
    try:
        if not force_refresh and _token_cache.get("access_token"):
            return _token_cache["access_token"]

        raw = f"{PLM_AUTH['client_id']}:{PLM_AUTH['client_secret']}"
        b64 = base64.b64encode(raw.encode()).decode()
        headers = {
            "Authorization": f"Basic {b64}",
            "Content-Type":  "application/x-www-form-urlencoded",
        }
        payload = {
            "grant_type": "password",
            "username":   PLM_AUTH["username"],
            "password":   PLM_AUTH["password"],
            "scope":      PLM_AUTH["scope"],
        }
        log.info("Acquiring PLM OAuth2 access token …")
        resp = requests.post(PLM_AUTH["token_url"], headers=headers, data=payload,
                             timeout=30, verify=False)
        resp.raise_for_status()
        token = resp.json()["access_token"]
        _token_cache["access_token"] = token
        log.info("PLM access token acquired.")
        return token

    except requests.HTTPError as exc:
        log.error("HTTP error acquiring PLM token: %s", exc)
        raise RuntimeError(f"PLM token HTTP error: {exc}") from exc
    except requests.RequestException as exc:
        log.error("Request error acquiring PLM token: %s", exc)
        raise RuntimeError(f"PLM token request error: {exc}") from exc
    except Exception as exc:
        log.error("Unexpected error acquiring PLM token: %s", exc)
        raise RuntimeError(f"PLM token unexpected error: {exc}") from exc


def plm_headers() -> dict:
    """
    Build Gravitee API request headers.
    Returns a minimal dict (no Authorization) if token cannot be obtained.
    """
    try:
        token = get_plm_access_token()
        return {
            "Content-Type":       "application/json",
            "X-Gravitee-Api-Key": PLM_API["api_key"],
            "Authorization":      f"Bearer {token}",
            "accept":             "*/*",
        }
    except Exception as exc:
        log.error("Failed to build PLM headers: %s", exc)
        return {"Content-Type": "application/json", "X-Gravitee-Api-Key": PLM_API["api_key"]}


# ===========================================================================
# 3. PLM OData API  –  content metadata + file download
# ===========================================================================

def get_primary_content_meta(wt_document_id: str) -> Optional[dict]:
    """
    Retrieve PrimaryContent metadata for a Windchill document OID.
    Returns JSON dict or None on any error.
    """
    try:
        if not wt_document_id.startswith("OR:"):
            wt_document_id = f"OR:wt.doc.WTDocument:{wt_document_id}"
        url = f"{PLM_API['base_url']}/DocMgmt/Documents('{wt_document_id}')/PrimaryContent"
        resp = requests.get(url, headers=plm_headers(), timeout=30, verify=False)

        if resp.status_code == 401:
            log.warning("PLM token expired – refreshing …")
            try:
                get_plm_access_token(force_refresh=True)
            except Exception as refresh_exc:
                log.error("Token refresh failed: %s", refresh_exc)
                return None
            resp = requests.get(url, headers=plm_headers(), timeout=30, verify=False)

        resp.raise_for_status()
        return resp.json()

    except requests.HTTPError as exc:
        log.error("HTTP error fetching PrimaryContent for %s: %s", wt_document_id, exc)
        return None
    except requests.RequestException as exc:
        log.error("Request error fetching PrimaryContent for %s: %s", wt_document_id, exc)
        return None
    except Exception as exc:
        log.error("Unexpected error fetching PrimaryContent for %s: %s", wt_document_id, exc)
        return None


def download_document(download_url: str, dest_path: Path) -> bool:
    """
    Stream-download a document binary to dest_path.
    Returns True on success, False on any error.
    """
    try:
        resp = requests.get(download_url, headers=plm_headers(),
                            stream=True, timeout=120, verify=False)
        resp.raise_for_status()
        with dest_path.open("wb") as fh:
            for chunk in resp.iter_content(chunk_size=65536):
                fh.write(chunk)
        log.debug("Downloaded → %s", dest_path)
        return True

    except requests.HTTPError as exc:
        log.error("HTTP error downloading %s: %s", download_url, exc)
        return False
    except requests.RequestException as exc:
        log.error("Request error downloading %s: %s", download_url, exc)
        return False
    except OSError as exc:
        log.error("File I/O error writing %s: %s", dest_path, exc)
        return False
    except Exception as exc:
        log.error("Unexpected error downloading %s: %s", download_url, exc)
        return False


# ===========================================================================
# 4. Text extraction
# ===========================================================================

def extract_text_docx(file_path: Path) -> str:
    """Extract paragraph and table text from a .docx file. Returns '' on error."""
    try:
        doc = DocxDocument(str(file_path))
        parts = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        parts.append(cell.text.strip())
        return "\n".join(parts)
    except Exception as exc:
        log.error("Failed to extract text from docx %s: %s", file_path, exc)
        return ""


def extract_text_pdf(file_path: Path) -> str:
    """Extract full text from a PDF via PyMuPDF. Returns '' on error."""
    try:
        doc = fitz.open(str(file_path))
        return "\n".join(page.get_text("text") for page in doc)
    except fitz.FileDataError as exc:
        log.error("PDF file data error %s: %s", file_path, exc)
        return ""
    except Exception as exc:
        log.error("Failed to extract text from PDF %s: %s", file_path, exc)
        return ""


def extract_text(file_path: Path) -> str:
    """Dispatch text extraction by extension. Returns '' on error or unknown format."""
    try:
        suffix = file_path.suffix.lower()
        if suffix in {".docx", ".doc"}:
            return extract_text_docx(file_path)
        if suffix == ".pdf":
            return extract_text_pdf(file_path)
        log.warning("Unsupported format for text extraction: %s", suffix)
        return ""
    except Exception as exc:
        log.error("Unexpected error in extract_text for %s: %s", file_path, exc)
        return ""


# ===========================================================================
# 5. Image extraction
# ===========================================================================

def extract_images_docx(file_path: Path) -> list[tuple[str, bytes]]:
    """Extract inline images from a .docx. Returns [] on error."""
    try:
        doc = DocxDocument(str(file_path))
        images = []
        for rel in doc.part.rels.values():
            try:
                if "image" in rel.reltype:
                    data = rel.target_part.blob
                    images.append((hashlib.sha256(data).hexdigest()[:16], data))
            except Exception as rel_exc:
                log.warning("Could not extract image relation from %s: %s", file_path, rel_exc)
        return images
    except Exception as exc:
        log.error("Failed to extract images from docx %s: %s", file_path, exc)
        return []


def extract_images_pdf(file_path: Path) -> list[tuple[str, bytes]]:
    """Extract raster images from a PDF via PyMuPDF. Returns [] on error."""
    try:
        doc = fitz.open(str(file_path))
        images = []
        for page in doc:
            try:
                for img_info in page.get_images(full=True):
                    try:
                        base_img = doc.extract_image(img_info[0])
                        data = base_img["image"]
                        images.append((hashlib.sha256(data).hexdigest()[:16], data))
                    except Exception as img_exc:
                        log.warning("Could not extract image xref=%s: %s", img_info[0], img_exc)
            except Exception as page_exc:
                log.warning("Could not list images on PDF page in %s: %s", file_path, page_exc)
        return images
    except Exception as exc:
        log.error("Failed to extract images from PDF %s: %s", file_path, exc)
        return []


def extract_images(file_path: Path) -> list[tuple[str, bytes]]:
    """Dispatch image extraction by extension. Returns [] on error or unknown format."""
    try:
        suffix = file_path.suffix.lower()
        if suffix in {".docx", ".doc"}:
            return extract_images_docx(file_path)
        if suffix == ".pdf":
            return extract_images_pdf(file_path)
        return []
    except Exception as exc:
        log.error("Unexpected error in extract_images for %s: %s", file_path, exc)
        return []


# ===========================================================================
# 6. S3 upload
# ===========================================================================

def get_s3_client():
    """Return a boto3 S3 client. Raises on misconfiguration."""
    try:
        return boto3.client("s3", region_name=S3_CONFIG["region"])
    except Exception as exc:
        log.error("Failed to create S3 client: %s", exc)
        raise


def resize_image(img_bytes: bytes, max_dim: int = 1024) -> bytes:
    """Resize image to max_dim. Returns original bytes if Pillow fails."""
    try:
        img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        img.thumbnail((max_dim, max_dim), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=85)
        return buf.getvalue()
    except Exception as exc:
        log.warning("Image resize failed (using original): %s", exc)
        return img_bytes


def upload_images_to_s3(
    document_id: str,
    images: list[tuple[str, bytes]],
    s3_client,
) -> list[str]:
    """
    Resize and upload images to s3://<bucket>/production_document/images/<doc_id>/<img_id>.jpg
    Returns list of successfully uploaded S3 URIs.
    """
    s3_uris = []
    try:
        for img_id, img_bytes in images:
            try:
                img_bytes = resize_image(img_bytes, PIPELINE_CONFIG["max_image_dimension"])
                key = f"{S3_CONFIG['image_prefix']}/{document_id}/{img_id}.jpg"
                s3_client.put_object(
                    Bucket=S3_CONFIG["bucket"],
                    Key=key,
                    Body=img_bytes,
                    ContentType="image/jpeg",
                )
                uri = f"s3://{S3_CONFIG['bucket']}/{key}"
                s3_uris.append(uri)
                log.debug("Uploaded → %s", uri)
            except Exception as img_exc:
                log.warning("Skipping image %s for doc %s: %s", img_id, document_id, img_exc)
    except Exception as exc:
        log.error("Unexpected error uploading images for doc %s: %s", document_id, exc)
    return s3_uris


# ===========================================================================
# 7. Text chunking
# ===========================================================================

def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> list[tuple[int, str]]:
    """
    Split text into overlapping word-based chunks.
    Returns list of (chunk_seq, chunk_text); returns [] on error.
    """
    try:
        words = text.split()
        if not words:
            return []
        chunks, start, seq = [], 0, 0
        while start < len(words):
            end = min(start + chunk_size, len(words))
            chunks.append((seq, " ".join(words[start:end])))
            seq += 1
            if end == len(words):
                break
            start += chunk_size - overlap
        return chunks
    except Exception as exc:
        log.error("Unexpected error in chunk_text: %s", exc)
        return []


# ===========================================================================
# 8. MSSQL writes via SQLAlchemy ORM
# ===========================================================================

def upsert_document_metadata(doc_row: dict, run_id: str) -> bool:
    """
    Upsert one ProductionDocumentMetadata row via session.merge().
    Returns True on success, False on error.
    """
    try:
        def _si(v) -> Optional[int]:
            try:
                return int(v)
            except (TypeError, ValueError):
                return None

        record = ProductionDocumentMetadata(
            document_id       = str(doc_row.get("id", "")),
            number            = doc_row.get("doc_number"),
            version           = doc_row.get("version_label"),
            name              = doc_row.get("name"),
            doc_title         = doc_row.get("title"),
            owner             = doc_row.get("creator_display_name"),
            type              = doc_row.get("type"),
            doc_sub_type      = doc_row.get("doc_sub_type"),
            state             = doc_row.get("state"),
            lifecycle_template= doc_row.get("lifecycle"),
            classification    = doc_row.get("classification"),
            binding_type      = doc_row.get("doc_is_binding"),
            language          = doc_row.get("doc_language"),
            doc_type_label    = doc_row.get("doc_type"),
            org_context       = doc_row.get("context_name"),
            function_area     = doc_row.get("function"),
            organization_unit = doc_row.get("organization_unit"),
            production_area   = doc_row.get("production_area"),
            filename          = doc_row.get("filename"),
            file_format       = doc_row.get("file_format"),
            file_size_bytes   = _si(doc_row.get("file_size")),
            created_on        = doc_row.get("created_on"),
            updated_on        = doc_row.get("updated_on"),
            deleted_flag      = bool(doc_row.get("deleted_flag", False)),
            pipeline_run_id   = run_id,
            indexed_at        = datetime.datetime.utcnow(),
        )
        with get_mssql_session() as session:
            session.merge(record)
            session.commit()
        return True

    except SQLAlchemyError as exc:
        log.error("SQLAlchemy error upserting metadata for doc %s: %s", doc_row.get("id"), exc)
        return False
    except Exception as exc:
        log.error("Unexpected error upserting metadata for doc %s: %s", doc_row.get("id"), exc)
        return False


def save_document_chunks(
    doc_id: str, doc_number: str, filename: str, filetype: str,
    chunks: list[tuple[int, str]], run_id: str,
) -> bool:
    """
    Persist all text chunks for one document to dbo.production_document_chunk.
    Deletes old chunks first to make re-runs idempotent.
    Returns True on success, False on error.
    """
    try:
        filepath = f"/production/{doc_number}/{filename}"
        with get_mssql_session() as session:
            try:
                session.query(ProductionDocumentChunk).filter_by(
                    document_id=doc_id
                ).delete(synchronize_session=False)
            except Exception as del_exc:
                log.warning("Could not delete stale chunks for doc %s: %s", doc_id, del_exc)

            for seq, content_text in chunks:
                try:
                    session.add(ProductionDocumentChunk(
                        document_id     = doc_id,
                        number          = doc_number,
                        filename        = filename,
                        filepath        = filepath,
                        filetype        = filetype,
                        chunk_seq       = seq,
                        content         = content_text,
                        pipeline_run_id = run_id,
                        indexed_at      = datetime.datetime.utcnow(),
                        es_indexed      = False,
                    ))
                except Exception as chunk_exc:
                    log.warning("Skipping chunk seq=%d for doc %s: %s", seq, doc_id, chunk_exc)
            session.commit()
        return True

    except SQLAlchemyError as exc:
        log.error("SQLAlchemy error saving chunks for doc %s: %s", doc_id, exc)
        return False
    except Exception as exc:
        log.error("Unexpected error saving chunks for doc %s: %s", doc_id, exc)
        return False


def save_image_records(
    doc_id: str, doc_number: str, s3_uris: list[str], run_id: str,
) -> bool:
    """
    Persist uploaded image URIs to dbo.production_document_image.
    Returns True on success, False on error.
    """
    try:
        with get_mssql_session() as session:
            for uri in s3_uris:
                try:
                    key    = uri.replace(f"s3://{S3_CONFIG['bucket']}/", "")
                    img_id = Path(uri).stem
                    session.add(ProductionDocumentImage(
                        document_id     = doc_id,
                        number          = doc_number,
                        image_id        = img_id,
                        s3_uri          = uri,
                        s3_key          = key,
                        pipeline_run_id = run_id,
                        uploaded_at     = datetime.datetime.utcnow(),
                    ))
                except Exception as uri_exc:
                    log.warning("Skipping image record for URI %s: %s", uri, uri_exc)
            session.commit()
        return True

    except SQLAlchemyError as exc:
        log.error("SQLAlchemy error saving image records for doc %s: %s", doc_id, exc)
        return False
    except Exception as exc:
        log.error("Unexpected error saving image records for doc %s: %s", doc_id, exc)
        return False


# ===========================================================================
# 9. Manifest
# ===========================================================================

def write_manifest(manifest: list[dict], run_id: str) -> Optional[Path]:
    """
    Write staging manifest JSON to ./staging/<run_id>_manifest.json.
    Returns the Path on success, None on error.
    """
    try:
        out_path = PIPELINE_CONFIG["staging_dir"] / f"{run_id}_manifest.json"
        with out_path.open("w", encoding="utf-8") as fh:
            json.dump(manifest, fh, ensure_ascii=False, indent=2, default=str)
        log.info("Manifest written → %s  (%d records)", out_path, len(manifest))
        return out_path
    except OSError as exc:
        log.error("File I/O error writing manifest: %s", exc)
        return None
    except Exception as exc:
        log.error("Unexpected error writing manifest: %s", exc)
        return None


# ===========================================================================
# 10. Per-document orchestration
# ===========================================================================

def process_document(doc_row: dict, run_id: str, s3_client) -> Optional[dict]:
    """
    Full per-document pipeline:
      fetch PLM content meta → download file → extract text/images
      → upload images to S3 → chunk text → write all records to MSSQL
      → return manifest record.
    Returns a manifest dict on success, None if skipped or failed.
    """
    doc_id   = str(doc_row.get("id", ""))
    doc_num  = doc_row.get("doc_number", "")
    filename = doc_row.get("filename", "") or ""

    log.info("Processing  id=%-15s  number=%-15s  file=%s", doc_id, doc_num, filename)

    try:
        # Fetch PLM content metadata
        content_meta = get_primary_content_meta(doc_id)
        if not content_meta:
            log.warning("Skipping %s – no PrimaryContent metadata.", doc_id)
            return None

        file_name    = content_meta.get("FileName", filename)
        mime_type    = content_meta.get("MimeType", "")
        file_size    = content_meta.get("FileSize", 0)
        download_url = (content_meta.get("Content") or {}).get("URL")

        if not download_url:
            log.warning("Skipping %s – no download URL.", doc_id)
            return None

        file_ext = Path(file_name).suffix.lower()
        if file_ext not in PIPELINE_CONFIG["supported_formats"]:
            log.info("Skipping %s – unsupported format '%s'.", doc_id, file_ext)
            return None

        # Download
        local_path = PIPELINE_CONFIG["download_dir"] / f"{doc_id}{file_ext}"
        if not download_document(download_url, local_path):
            return None

        # Extract text
        full_text = extract_text(local_path)
        if not full_text.strip():
            log.warning("No text extracted from %s.", local_path)

        # Extract & upload images
        raw_images = extract_images(local_path)
        s3_uris    = upload_images_to_s3(doc_id, raw_images, s3_client)
        if s3_uris:
            log.info("  Uploaded %d image(s) for doc %s", len(s3_uris), doc_id)
            save_image_records(doc_id, doc_num, s3_uris, run_id)

        # Chunk text
        raw_chunks = chunk_text(
            full_text,
            chunk_size=PIPELINE_CONFIG["chunk_size"],
            overlap=PIPELINE_CONFIG["chunk_overlap"],
        )
        content_items = []
        for seq, text_val in raw_chunks:
            enriched = text_val
            if seq == 0 and s3_uris:
                enriched += "\n\n[IMAGES]\n" + "\n".join(s3_uris)
            content_items.append({"chunk_seq": seq, "content": enriched})

        # Persist to MSSQL
        enriched_row = {**doc_row, "filename": file_name, "file_size": file_size}
        upsert_document_metadata(enriched_row, run_id)
        save_document_chunks(
            doc_id, doc_num, file_name, file_ext.lstrip("."),
            [(i["chunk_seq"], i["content"]) for i in content_items],
            run_id,
        )

        # Build manifest record
        manifest_record = {
            "document_id": doc_id,
            "number":      doc_num,
            "filename":    file_name,
            "filepath":    f"/production/{doc_num}/{file_name}",
            "filetype":    file_ext.lstrip("."),
            "mime_type":   mime_type,
            "name":        doc_row.get("name", ""),
            "title":       doc_row.get("title", ""),
            "state":       doc_row.get("state", ""),
            "version":     doc_row.get("version_label", ""),
            "owner":       doc_row.get("creator_display_name", ""),
            "org_context": doc_row.get("context_name", ""),
            "function":    doc_row.get("function", ""),
            "org_unit":    doc_row.get("organization_unit", ""),
            "created_on":  str(doc_row.get("created_on", "")),
            "updated_on":  str(doc_row.get("updated_on", "")),
            "s3_images":   s3_uris,
            "chunks":      content_items,
            "indexed_at":  datetime.datetime.utcnow().isoformat(),
            "run_id":      run_id,
        }

        # Clean up local download
        try:
            local_path.unlink(missing_ok=True)
        except Exception as unlink_exc:
            log.warning("Could not delete temp file %s: %s", local_path, unlink_exc)

        return manifest_record

    except Exception as exc:
        log.error("Unhandled error processing document %s (%s): %s", doc_id, doc_num, exc)
        return None


# ===========================================================================
# 11. Main pipeline
# ===========================================================================

def run_pipeline() -> None:
    """Entry-point for the production data preparation pipeline."""
    run_id = uuid.uuid4().hex[:12]
    log.info("=" * 60)
    log.info("Production Data Prep Pipeline  run_id=%s", run_id)
    log.info("=" * 60)

    try:
        ensure_mssql_schema()
    except Exception as exc:
        log.error("Cannot proceed – MSSQL schema setup failed: %s", exc)
        return

    df = fetch_plm_metadata()
    if df.empty:
        log.warning("No documents returned from DIVE – pipeline exiting.")
        return

    try:
        get_plm_access_token()
    except RuntimeError as exc:
        log.error("Cannot proceed – PLM authentication failed: %s", exc)
        return

    try:
        s3_client = get_s3_client()
    except Exception as exc:
        log.error("Cannot proceed – S3 client creation failed: %s", exc)
        return

    manifest: list[dict] = []
    total, success, skipped = len(df), 0, 0

    for idx, row in df.iterrows():
        try:
            result = process_document(row.to_dict(), run_id, s3_client)
            if result:
                manifest.append(result)
                success += 1
            else:
                skipped += 1
        except Exception as row_exc:
            log.error("Fatal error on row %d: %s", idx, row_exc)
            skipped += 1

        if (idx + 1) % 50 == 0:
            log.info("Progress: %d / %d …", idx + 1, total)

    manifest_path = write_manifest(manifest, run_id)

    log.info("=" * 60)
    log.info("Pipeline complete.  Total=%d  Success=%d  Skipped=%d", total, success, skipped)
    if manifest_path:
        log.info("Manifest → %s", manifest_path)
    log.info("=" * 60)


if __name__ == "__main__":
    run_pipeline()
