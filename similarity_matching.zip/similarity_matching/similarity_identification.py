import traceback
import pandas as pd
import numpy as np
import heapq
from sklearn.metrics.pairwise import cosine_similarity
from data_preprocess import DataPreprocessing
pre_process = DataPreprocessing()
from scipy.stats import pearsonr
import faiss
class SimilarityIdentification(object):
    def identify_cosine_similarity(self, input_data, master_org_data, config_params):
        try:
            # df = pd.read_json(input_data)
            if config_params['vector_conversion'] == 'label_encoding':
                preprocessed, error = pre_process.label_encoder_vector_conversion(input_data, "inference")
                master_data = pd.read_csv(f'label_encoding/encoded_data.csv')
                input_data_values = preprocessed.values
                master_data_values = master_data.values
                similarity = cosine_similarity(input_data_values, master_data_values)
                nd_list = similarity.tolist()[0]
                indices_with_value = heapq.nlargest(5, enumerate(nd_list), key=lambda x: x[1])
                indices = [index for index, value in indices_with_value]
                selected_rows = master_org_data.iloc[indices]
                print(similarity)
        except Exception as exep:
            error = f'Error in identify_cosine_similarity {traceback.print_exc()}'

    def identify_faiss_relation(self, input_data, master_org_data, config_params):
        try:
            # df = pd.read_json(input_data)
            if config_params['vector_conversion'] == 'label_encoding':
                preprocessed, error = pre_process.label_encoder_vector_conversion(input_data, "inference")
                master_data = pd.read_csv(f'label_encoding/encoded_data.csv')
                input_data_values = preprocessed.values
                master_data_values = master_data.values
                index = faiss.IndexFlatL2(input_data_values.shape[1])
                index.add(master_data_values)
                n_neighbors = 5
                distances, indices = index.search(input_data_values, n_neighbors)
                nd_list = indices.tolist()[0]
                selected_rows = master_org_data.iloc[nd_list]
                print(f"Indices of the {n_neighbors} closest rows: {indices}")
                print(f"Distances of the {n_neighbors} closest rows: {distances}")

        except Exception as exep:
            error = f'Error in identify_cosine_similarity {traceback.print_exc()}'



'''
"identify_similarity" : "cosine"
"identify_similarity" : "faiss"
'''
config_params = {
    "vector_conversion" : "label_encoding",
    "identify_similarity" : "cosine"
}
master_data = pd.read_csv("input_data/input_data.csv")
df = master_data.head(1)
similarity_identification = SimilarityIdentification()
if config_params['identify_similarity'] == "cosine":
    similarity_identification.identify_cosine_similarity(df, master_data, config_params)

if config_params['identify_similarity'] == "faiss":
    similarity_identification.identify_faiss_relation(df, master_data, config_params)