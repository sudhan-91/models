import os
import traceback

import pandas as pd
from data_preprocess import DataPreprocessing
pre_process = DataPreprocessing()
class EmbeddingDataPrep(object):


    def trigger_preprocess(self, input_file, config_params):
        # Conversion of word to vector
        try:
            df = pd.read_csv(input_file)
            for conversion in config_params['vector_conversion']:
                if conversion == 'label_encoding':
                    preprocessed, error = pre_process.label_encoder_vector_conversion(df, "training")
                    os.makedirs('label_encoding', exist_ok=True)
                    preprocessed.to_csv(f"label_encoding/encoded_data.csv", index = False)
                elif conversion == 'bert':
                    preprocessed, error = pre_process.bert_conversion(df, "training")
                    os.makedirs('bert_embedding', exist_ok=True)
                    preprocessed.to_csv(f"bert_embedding/encoded_data.csv", index = False)
                elif conversion == 'fasttext':
                    preprocessed, error = pre_process.fasttext_conversion(df, "training")
                    os.makedirs('fasttext', exist_ok=True)
                    preprocessed.to_csv(f"fasttext/encoded_data.csv", index = False)
                elif conversion == 'word2vec':
                    preprocessed, error = pre_process.word2vec_conversion(df, "training")
                    os.makedirs('word2vec', exist_ok=True)
                    preprocessed.to_csv(f"word2vec/encoded_data.csv", index = False)

        except Exception as exep:
            print(traceback.print_exc())

'''
# vector_conversion
1. label encodings
2. bert
3. fasttext
4. word2vec
'''
input_file = "input_data/input_data.csv"

config_params = {
    "vector_conversion" : ["word2vec", "fasttext", "bert","label_encoding"]
}
emb_data_prep = EmbeddingDataPrep()
emb_data_prep.trigger_preprocess(input_file, config_params)


