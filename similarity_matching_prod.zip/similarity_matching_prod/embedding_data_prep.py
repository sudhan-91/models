import os
import traceback

import pandas as pd
from data_preprocess import DataPreprocessing
pre_process = DataPreprocessing()
class EmbeddingDataPrep(object):


    def trigger_preprocess(self, input_file, config_params):
        # Conversion of word to vector
        try:
            input_df = pd.read_csv(input_file)
            df = input_df[['DIVISION_SHORT_DESCR', 'SUB_DIVISION_SHORT_DESCR', 'BUSINESS_SEGMENT',
             'HFGR', 'HFGR_SHORT_DESCR', 'FGR', 'FGR_DESC', 'MPI_TYPE',
             'PRODUCT_FAMILY', 'APPLICATION', 'TECHNOLOGY', 'PROCESSCLASS',
             'PROCESSGROUP', 'SALES_NAME', 'MSAI_SP_SAP_MATNR', 'MBNO_FP_SAP_MATNR',
             'DC_BNR_MAX', 'BASIC_TYPE_BE', 'MPK_PACKAGE_PLATFORM',
             'PACKAGE_FAMILY_PROCESSED', 'DC_V_SNR_SERIAL_NO', 'PACKAGENAME',
             'QA_MILESTONE', 'QUALITY_REQ_CATEGORY', 'M8_RELEASE_DATE',
             'M9_RELEASE_DATE', 'MSAI_FUNCTIONAL_SAFETY', 'MSAI_PRODUCT_STATUS_INFO',
             'BE_PVG_VALID_TO', 'BASIC_TYPE_DB', 'TOTAL_CHIPS_PROCESSED',
             'MULTICHIP_PROCESSED', 'BASIC_TYPE_BREAKDOWN_PROCESSED', 'FAB_LOC',
             'ASSEMBLY', 'TEST', 'MAIN_FAMILY', 'ENDTHICKNESS_PRAS_MIN',
             'PRWF_RASTER_X', 'PRWF_RASTER_Y', 'MBFS_FRONTEND_QTY', 'PRWF_CHIP_SIZE',
             'MANUFACTURING_ROUTE']]
            for conversion in config_params['vector_conversion']:
                print(conversion)
                if conversion == 'label_encoding':
                    preprocessed, error = pre_process.label_encoder_vector_conversion(df, "training")
                    os.makedirs('label_encoding', exist_ok=True)
                    preprocessed.to_csv(f"label_encoding/encoded_data.csv", index = False)
                elif conversion == 'bert':
                    preprocessed, error = pre_process.bert_conversion(df, "training")
                    os.makedirs('bert_embedding', exist_ok=True)
                    preprocessed.to_csv(f"bert_embedding/encoded_data.csv", index = False)
                elif conversion == 'fasttext':
                    os.makedirs('fasttext', exist_ok=True)
                    preprocessed, error = pre_process.fasttext_conversion(df, "training")
                    preprocessed.to_csv(f"fasttext/encoded_data.csv", index = False)
                elif conversion == 'word2vec':
                    os.makedirs('word2vec', exist_ok=True)
                    preprocessed, error = pre_process.word2vec_conversion(df, "training")
                    preprocessed.to_csv(f"word2vec/encoded_data.csv", index = False)

        except Exception as exep:
            print(traceback.print_exc())

'''
# vector_conversion
1. label encodings
2. bert
3. fasttext
4. word2vec
'''
input_file = "input_data/master_data.csv"
# emb_approaches = ["fasttext", "bert", "label_encoding", "word2vec"]
emb_approaches = ["fasttext"]
config_params = {
    "vector_conversion" : emb_approaches
}
emb_data_prep = EmbeddingDataPrep()
emb_data_prep.trigger_preprocess(input_file, config_params)


