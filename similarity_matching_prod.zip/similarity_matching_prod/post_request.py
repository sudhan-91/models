import requests
import pandas as pd

master_data = pd.read_csv("input_data/input_data.csv")
df = master_data.head(1)
df_string = df.to_csv(index=False)
# Prepare the payload with the pipeline serialized as a string
payload = {
       "input_data" : df_string
    }
# Send POST request
response = requests.post("http://0.0.0.0:8010/product/recommendation", json=payload)
# Path to your output text file
print(response.json())