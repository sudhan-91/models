"""
config.py — Central configuration for the NERMAL RAG pipeline.
All environment-specific values are read from environment variables.
"""

import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class OracleConfig:
    user: str           = os.environ.get("ORACLE_USER", "dwh_read_qmagent")
    password: str       = os.environ.get("ORACLE_PASSWORD", "")
    dsn: str            = os.environ.get("ORACLE_DSN", "dwhrbg.rbg.infineon.com")
    port: int           = int(os.environ.get("ORACLE_PORT", "1521"))
    service_name: str   = os.environ.get("ORACLE_SERVICE", "dwh")
    lib_dir: str        = os.environ.get("ORACLE_LIB_DIR", r"C:\oracle\instantclient_21_9")
    pool_min: int       = 1
    pool_max: int       = 5
    pool_increment: int = 1


@dataclass(frozen=True)
class TableConfig:
    nermal: str          = "LOC_RBL.DWH_NERMAL"
    teamcenter: str      = "LOC_RBL.DWH_TEAMCENTER"
    teamcenter_bu: str   = "LOC_RBL.DWH_TEAMCENTER_BU"
    # Table that maps OBJECT_ID → file path — update with real table name
    file_paths: str      = os.environ.get("FILE_PATH_TABLE", "LOC_RBL.DWH_TC_DOCUMENTS")
    file_path_col: str   = os.environ.get("FILE_PATH_COL", "FILE_PATH")
    file_version_col: str = os.environ.get("FILE_VERSION_COL", "VERSION")
    file_date_col: str   = os.environ.get("FILE_DATE_COL", "MODIFIED_DATE")


@dataclass(frozen=True)
class ElasticsearchConfig:
    url: str            = os.environ.get("ES_URL", "http://localhost:9200")
    index: str          = os.environ.get("ES_INDEX", "nermal_rag")
    username: str       = os.environ.get("ES_USER", "")
    password: str       = os.environ.get("ES_PASSWORD", "")
    ca_certs: str       = os.environ.get("ES_CA_CERTS", "")
    request_timeout: int = 30
    bulk_batch_size: int = 200        # docs flushed to ES at once
    num_candidates: int  = 100        # knn num_candidates multiplier


@dataclass(frozen=True)
class EmbeddingConfig:
    model_name: str     = os.environ.get(
        "EMBEDDING_MODEL", "sentence-transformers/all-mpnet-base-v2"
    )
    dimensions: int     = 768
    batch_size: int     = 32
    device: str         = os.environ.get("EMBEDDING_DEVICE", "cpu")  # "cuda" if GPU


@dataclass(frozen=True)
class ChunkingConfig:
    chunk_size: int     = 512
    chunk_overlap: int  = 50
    separators: tuple   = ("\n\n", "\n", ". ", " ", "")


@dataclass(frozen=True)
class PipelineConfig:
    oracle: OracleConfig             = field(default_factory=OracleConfig)
    tables: TableConfig              = field(default_factory=TableConfig)
    elasticsearch: ElasticsearchConfig = field(default_factory=ElasticsearchConfig)
    embedding: EmbeddingConfig       = field(default_factory=EmbeddingConfig)
    chunking: ChunkingConfig         = field(default_factory=ChunkingConfig)
    log_dir: str                     = os.environ.get("LOG_DIR", "logs")
    log_level: str                   = os.environ.get("LOG_LEVEL", "INFO")
    supported_extensions: tuple      = (".pptx", ".ppt", ".xlsx", ".xls",
                                        ".pdf", ".docx", ".doc")


# Singleton instance — import this everywhere
cfg = PipelineConfig()
