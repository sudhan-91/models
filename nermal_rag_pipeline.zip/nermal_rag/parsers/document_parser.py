"""
parsers/document_parser.py — Parse PPT, Excel, PDF, and Word documents into plain text.

Each parser:
  - Returns a single clean string (empty string on failure — never raises).
  - Adds slide / sheet / page markers to help chunking stay coherent.
  - Logs warnings on failure without crashing the pipeline.
"""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation as PptxPresentation
import openpyxl
from pypdf import PdfReader
import docx as python_docx

from logger import get_logger
from config import cfg

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# PPT / PPTX
# ─────────────────────────────────────────────────────────────

def parse_pptx(path: str) -> str:
    """
    Extract text from all slides of a PPTX file.
    Slide titles are emitted first so chunked text retains context.
    """
    try:
        prs = PptxPresentation(path)
        slides_text: list[str] = []

        for i, slide in enumerate(prs.slides, start=1):
            parts: list[str] = []

            # Title first (if the slide layout has one)
            title_shape = slide.shapes.title
            if title_shape and title_shape.has_text_frame:
                title = title_shape.text_frame.text.strip()
                if title:
                    parts.append(title)

            # All other text frames
            for shape in slide.shapes:
                if shape is title_shape:
                    continue
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        line = para.text.strip()
                        if line:
                            parts.append(line)
                # Tables inside slides
                if shape.has_table:
                    for row in shape.table.rows:
                        row_vals = [
                            cell.text.strip()
                            for cell in row.cells
                            if cell.text.strip()
                        ]
                        if row_vals:
                            parts.append(" | ".join(row_vals))

            if parts:
                slides_text.append(f"[Slide {i}]\n" + "\n".join(parts))

        return "\n\n".join(slides_text)

    except Exception as exc:
        log.warning("PPTX parse failed | path=%s | error=%s", path, exc)
        return ""


# ─────────────────────────────────────────────────────────────
# Excel / XLSX
# ─────────────────────────────────────────────────────────────

def parse_xlsx(path: str) -> str:
    """
    Extract text from every sheet of an Excel file.
    Empty cells are skipped; rows are pipe-joined.
    """
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        sheets_text: list[str] = []

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_text: list[str] = []

            for row in ws.iter_rows(values_only=True):
                cells = [
                    str(cell).strip()
                    for cell in row
                    if cell is not None and str(cell).strip()
                ]
                if cells:
                    rows_text.append(" | ".join(cells))

            if rows_text:
                sheets_text.append(
                    f"[Sheet: {sheet_name}]\n" + "\n".join(rows_text)
                )

        wb.close()
        return "\n\n".join(sheets_text)

    except Exception as exc:
        log.warning("Excel parse failed | path=%s | error=%s", path, exc)
        return ""


# ─────────────────────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────────────────────

def parse_pdf(path: str) -> str:
    """
    Extract text from every page of a PDF.
    Pages that yield no text (scanned images) are skipped with a warning.
    """
    try:
        reader = PdfReader(path)
        pages_text: list[str] = []
        empty_pages = 0

        for i, page in enumerate(reader.pages, start=1):
            text = (page.extract_text() or "").strip()
            if text:
                pages_text.append(f"[Page {i}]\n{text}")
            else:
                empty_pages += 1

        if empty_pages:
            log.debug(
                "PDF has %d image-only pages (no text extracted) | path=%s",
                empty_pages, path,
            )

        return "\n\n".join(pages_text)

    except Exception as exc:
        log.warning("PDF parse failed | path=%s | error=%s", path, exc)
        return ""


# ─────────────────────────────────────────────────────────────
# Word / DOCX
# ─────────────────────────────────────────────────────────────

def parse_docx(path: str) -> str:
    """
    Extract paragraphs and tables from a Word document.
    Paragraphs and table rows are emitted in document order.
    """
    try:
        doc = python_docx.Document(path)
        parts: list[str] = []

        # Iterate over body elements in document order
        for block in doc.element.body:
            tag = block.tag.split("}")[-1]   # strip namespace

            if tag == "p":                   # paragraph
                text = block.text_content().strip() if hasattr(block, "text_content") \
                       else "".join(t.text or "" for t in block.iter()).strip()
                if text:
                    parts.append(text)

            elif tag == "tbl":               # table
                # Walk <w:tr> → <w:tc> → text
                for tr in block.findall(
                    ".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tr"
                ):
                    cells = []
                    for tc in tr.findall(
                        ".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tc"
                    ):
                        cell_text = "".join(
                            node.text or ""
                            for node in tc.iter()
                            if node.text
                        ).strip()
                        if cell_text:
                            cells.append(cell_text)
                    if cells:
                        parts.append(" | ".join(cells))

        return "\n".join(parts)

    except Exception as exc:
        log.warning("DOCX parse failed | path=%s | error=%s", path, exc)
        return ""


# ─────────────────────────────────────────────────────────────
# Router
# ─────────────────────────────────────────────────────────────

_PARSERS = {
    ".pptx": parse_pptx,
    ".ppt":  parse_pptx,   # python-pptx reads .ppt too in most cases
    ".xlsx": parse_xlsx,
    ".xls":  parse_xlsx,
    ".pdf":  parse_pdf,
    ".docx": parse_docx,
    ".doc":  parse_docx,
}


def parse_document(file_path: str) -> str:
    """
    Dispatch to the correct parser based on file extension.

    Returns:
        Extracted plain text (empty string if unsupported or parse failed).
    """
    ext = Path(file_path).suffix.lower()
    parser = _PARSERS.get(ext)

    if parser is None:
        log.warning("Unsupported file type '%s' | path=%s", ext, file_path)
        return ""

    return parser(file_path)
