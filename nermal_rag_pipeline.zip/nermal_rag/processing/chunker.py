"""
processing/chunker.py — Split extracted document text into overlapping chunks.

Uses LangChain's RecursiveCharacterTextSplitter as the backend.
A metadata prefix (NER_ID, title, doc type) is prepended to the raw text
before chunking so every chunk carries enough context for retrieval.
"""

from __future__ import annotations

import pandas as pd
from langchain.text_splitter import RecursiveCharacterTextSplitter

from config import ChunkingConfig, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


def build_splitter(chunking_cfg: ChunkingConfig) -> RecursiveCharacterTextSplitter:
    """Instantiate the text splitter from config."""
    return RecursiveCharacterTextSplitter(
        chunk_size=chunking_cfg.chunk_size,
        chunk_overlap=chunking_cfg.chunk_overlap,
        separators=list(chunking_cfg.separators),
        length_function=len,
    )


def build_metadata_prefix(row: pd.Series) -> str:
    """
    Create a short metadata preamble that is prepended to every document.
    This ensures every chunk inherits enough project context to be
    retrieved correctly even without the full document in scope.
    """
    parts = [
        f"NER_ID: {row.get('NER_ID', '')}",
        f"Title: {row.get('TITLE', '')}",
        f"Package: {row.get('PACKAGE_FAMILY', '')} / {row.get('PACKAGE_NAME', '')}",
        f"Facility: {row.get('FACILITY', '')}",
        f"Milestone: {row.get('MILESTONE', '')}",
        f"Doc type: {row.get('IMPLEMENTATION_DOCU_IN', '')}",
        f"Phase: {row.get('PROJECT_PHASE', '')}",
        f"Motivation: {row.get('MOTIVATION', '')}",
    ]
    return "\n".join(p for p in parts if p.split(": ", 1)[-1].strip()) + "\n\n"


def chunk_document(
    raw_text: str,
    row: pd.Series,
    splitter: RecursiveCharacterTextSplitter,
) -> list[str]:
    """
    Prepend metadata prefix to raw_text, then split into chunks.

    Args:
        raw_text:  Text extracted from the document.
        row:       DataFrame row with project metadata.
        splitter:  Configured RecursiveCharacterTextSplitter instance.

    Returns:
        List of text chunks (empty list if input is blank).
    """
    if not raw_text or not raw_text.strip():
        return []

    prefix    = build_metadata_prefix(row)
    full_text = prefix + raw_text
    chunks    = splitter.split_text(full_text)

    log.debug(
        "Chunked | NER_ID=%s | file=%s | chunks=%d",
        row.get("NER_ID", "?"),
        row.get("FILE_PATH", "?"),
        len(chunks),
    )
    return chunks
