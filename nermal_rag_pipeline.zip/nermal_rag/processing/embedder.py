"""
processing/embedder.py — Load the embedding model and encode text chunks.

SentenceTransformer is loaded once and reused across all batches.
Encoding is batched to avoid OOM on large document sets.
"""

from __future__ import annotations

import numpy as np
from sentence_transformers import SentenceTransformer

from config import EmbeddingConfig, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


def load_model(embedding_cfg: EmbeddingConfig) -> SentenceTransformer:
    """Download (first run) and load the SentenceTransformer model."""
    log.info(
        "Loading embedding model: %s (device=%s)",
        embedding_cfg.model_name,
        embedding_cfg.device,
    )
    model = SentenceTransformer(
        embedding_cfg.model_name,
        device=embedding_cfg.device,
    )
    log.info(
        "Embedding model loaded | dims=%d", embedding_cfg.dimensions
    )
    return model


def embed_chunks(
    chunks: list[str],
    model: SentenceTransformer,
    batch_size: int,
) -> list[list[float]]:
    """
    Encode a list of text chunks into dense vectors.

    Args:
        chunks:     Text chunks to encode.
        model:      Loaded SentenceTransformer.
        batch_size: Number of chunks encoded per forward pass.

    Returns:
        List of float vectors, one per chunk.
    """
    if not chunks:
        return []

    embeddings: np.ndarray = model.encode(
        chunks,
        batch_size=batch_size,
        show_progress_bar=False,
        convert_to_numpy=True,
        normalize_embeddings=True,   # cosine similarity ≡ dot product when normalised
    )
    return embeddings.tolist()
