# NERMAL RAG Pipeline

End-to-end data processing pipeline that reads project documents from Oracle,
parses them, embeds the text, and stores everything in Elasticsearch for RAG.

---

## Project structure

```
nermal_rag/
│
├── config.py                   ← All configuration (reads from env vars)
├── logger.py                   ← Centralised rotating-file + stdout logger
├── pipeline.py                 ← Main orchestrator — run this
│
├── db/
│   └── oracle_client.py        ← Oracle connection pool + 4-table JOIN query
│
├── parsers/
│   └── document_parser.py      ← PPT · Excel · PDF · Word parsers
│
├── processing/
│   ├── chunker.py              ← RecursiveCharacterTextSplitter + metadata prefix
│   └── embedder.py             ← SentenceTransformer model loader + batch encode
│
├── storage/
│   └── elasticsearch_client.py ← Index creation · document builder · bulk index
│
├── rag/
│   └── search.py               ← Vector search · hybrid search · context builder
│
├── logs/                       ← Rotating log files (auto-created)
├── requirements.txt
└── .env.example                ← Copy to .env and fill in credentials
```

---

## Data sources (Oracle)

| Table | Role | Key field |
|---|---|---|
| `LOC_RBL.DWH_NERMAL` | Project metadata | `PROCNR` → `NER_ID` |
| `LOC_RBL.DWH_TEAMCENTER` | Change workflow + file refs | `OBJECT_ID`, `CHANGE_ID` |
| `LOC_RBL.DWH_TEAMCENTER_BU` | Workflow details, comments | `CHANGE_ID` |
| `LOC_RBL.DWH_TC_DOCUMENTS` | File path lookup *(update name)* | `OBJECT_ID` → `FILE_PATH` |

Join key: `DWH_NERMAL.PROCNR = SUBSTR(DWH_TEAMCENTER.CHANGE_ID, 1, 21)`

**Before running**, update `FILE_PATH_TABLE`, `FILE_PATH_COL`, `FILE_VERSION_COL`,
and `FILE_DATE_COL` in `.env` to match your actual file-path table schema.

---

## Setup

```bash
# 1. Clone and enter the project
cd nermal_rag

# 2. Create a virtual environment
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate     # Linux / macOS

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure credentials
copy .env.example .env          # Windows
# cp .env.example .env          # Linux / macOS
# Edit .env and fill in all values

# 5. Make sure Elasticsearch is running
# Default: http://localhost:9200

# 6. Run the pipeline
python pipeline.py
```

---

## Configuration

All settings live in `config.py` and are read from environment variables.
The `.env` file (loaded by `python-dotenv` if you call `load_dotenv()` at the
top of `pipeline.py`) is the recommended way to supply values locally.

| Variable | Default | Description |
|---|---|---|
| `ORACLE_USER` | `dwh_read_qmagent` | Oracle username |
| `ORACLE_PASSWORD` | *(required)* | Oracle password |
| `ORACLE_DSN` | `dwhrbg.rbg.infineon.com` | Oracle host |
| `FILE_PATH_TABLE` | `LOC_RBL.DWH_TC_DOCUMENTS` | Table with file paths |
| `ES_URL` | `http://localhost:9200` | Elasticsearch URL |
| `ES_INDEX` | `nermal_rag` | Index name |
| `EMBEDDING_MODEL` | `all-mpnet-base-v2` | SentenceTransformer model |
| `EMBEDDING_DEVICE` | `cpu` | `cpu` or `cuda` |

---

## PPT / latest-version logic

For each `NER_ID`, only the **latest PPT/PPTX** file is kept (sorted by
`FILE_VERSION DESC`, then `FILE_DATE DESC`). All other file types (PDF, Excel,
Word) are included as-is without version filtering.

---

## RAG query example

```python
from dotenv import load_dotenv
load_dotenv()

from config import cfg
from processing.embedder import load_model
from storage.elasticsearch_client import build_client
from rag.search import hybrid_search, build_context

model  = load_model(cfg.embedding)
client = build_client(cfg.elasticsearch)

results = hybrid_search(
    query   = "bond wire changes in Econo package",
    model   = model,
    client  = client,
    es_cfg  = cfg.elasticsearch,
    top_k   = 5,
    filters = {"facility": "Warstein", "lifecyclestate": "Released"},
)

context = build_context(results)
print(context)
```

---

## Elasticsearch index fields

| Field | Type | Purpose |
|---|---|---|
| `embedding` | `dense_vector (768d)` | knn similarity search |
| `chunk_text` | `text` | BM25 full-text search |
| `ner_id` | `keyword` | filter by project ID |
| `facility` | `keyword` | filter by plant |
| `milestone` | `keyword` | filter by CM phase |
| `lifecyclestate` | `keyword` | filter by status |
| `implementation_docu` | `keyword` | filter by doc type |
| `package_family` | `keyword` | filter by package |
