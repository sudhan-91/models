"""
db/oracle_client.py — Oracle connection pool and data extraction queries.

Responsibilities:
  - Initialise the Oracle instant-client and session pool.
  - Provide the 4-table JOIN query and return a clean DataFrame.
  - Perform post-query filtering (latest PPT per NER_ID).
"""

from __future__ import annotations

import cx_Oracle
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config import OracleConfig, TableConfig, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Connection
# ─────────────────────────────────────────────────────────────

def init_oracle_client(lib_dir: str) -> None:
    """Initialise the Oracle instant-client (call once at startup)."""
    try:
        cx_Oracle.init_oracle_client(lib_dir=lib_dir)
        log.info("Oracle instant-client initialised from: %s", lib_dir)
    except cx_Oracle.ProgrammingError:
        # Already initialised — safe to ignore
        log.debug("Oracle instant-client was already initialised.")


def build_engine(oracle_cfg: OracleConfig) -> Engine:
    """Create a SQLAlchemy engine with an Oracle session pool."""
    init_oracle_client(oracle_cfg.lib_dir)
    dsn = cx_Oracle.makedsn(
        oracle_cfg.dsn,
        oracle_cfg.port,
        service_name=oracle_cfg.service_name,
    )
    connection_url = (
        f"oracle+cx_oracle://{oracle_cfg.user}:{oracle_cfg.password}@"
    )
    engine = create_engine(
        connection_url,
        connect_args={"dsn": dsn},
        pool_size=oracle_cfg.pool_max,
        pool_pre_ping=True,
        echo=False,
    )
    log.info("Oracle engine created (dsn=%s)", oracle_cfg.dsn)
    return engine


# ─────────────────────────────────────────────────────────────
# Extraction query
# ─────────────────────────────────────────────────────────────

def _build_query(tables: TableConfig) -> str:
    """
    Build the 4-table JOIN query.

    Join logic:
      NERMAL ─ TEAMCENTER   on PROCNR = SUBSTR(CHANGE_ID, 1, 21)
      TEAMCENTER ─ TC_BU    on first segment of CHANGE_ID (before first comma)
      TEAMCENTER ─ file_paths on OBJECT_ID
    """
    return f"""
        SELECT DISTINCT
            REGEXP_SUBSTR(n.PROCNR,
                'NER_[[:digit:]]{{4}}/[[:digit:]]{{2}}_[[:digit:]]{{5}}_[[:alpha:]]{{2,4}}'
            )                                       AS NER_ID,
            n.TITLE                                 AS TITLE,
            n.MOTIVATION                            AS MOTIVATION,
            n.CURRENT_PROCEDURE                     AS CURRENT_PROCEDURE,
            n.NEWPROCEDURE                          AS NEW_PROCEDURE,
            n.PROJECT_TYPE                          AS NER_PROJECT_TYPE,
            n.REMARK                                AS REMARK,
            n.PROJECT_PHASE                         AS PROJECT_PHASE,
            n.LIFECYCLESTATE                        AS LIFECYCLESTATE,
            n.PACKAGE_FAMILY                        AS PACKAGE_FAMILY,
            n.PACKAGE_NAME                          AS PACKAGE_NAME,
            n.PK_LOCATION                           AS PK_LOCATION,
            n.FACILITY                              AS FACILITY,
            n.CHANGE_CLASS                          AS NER_CHANGE_CLASS,
            t.CHANGE_ID                             AS CHANGE_ID,
            t.OBJECT_ID                             AS OBJECT_ID,
            t.IMPLEMENTATION_DOCU_IN                AS IMPLEMENTATION_DOCU_IN,
            t.MILESTONE                             AS MILESTONE,
            t.ACTUAL_RELEASE_DATE                   AS ACTUAL_RELEASE_DATE,
            t.WF_TIMESTAMP_IN                       AS WF_TIMESTAMP_IN,
            t.PROJECT_STATE                         AS TC_PROJECT_STATE,
            t.TRIGGERED_BY                          AS TRIGGERED_BY,
            t.LIFECYCLESTATE                        AS TC_LIFECYCLESTATE,
            bu.WORKDESC                             AS WORKDESC,
            bu.WFCOMMENTS                           AS WFCOMMENTS,
            bu.COSTSAVINGS                          AS COSTSAVINGS,
            fp.{tables.file_path_col}               AS FILE_PATH,
            fp.{tables.file_version_col}            AS FILE_VERSION,
            fp.{tables.file_date_col}               AS FILE_DATE
        FROM {tables.nermal} n
        LEFT JOIN {tables.teamcenter} t
            ON n.PROCNR = SUBSTR(t.CHANGE_ID, 1, 21)
            AND t.TC_MODULE = 'Nermal'
        LEFT JOIN {tables.teamcenter_bu} bu
            ON SUBSTR(t.CHANGE_ID, 1, INSTR(t.CHANGE_ID, ',') - 1) =
               SUBSTR(bu.CHANGE_ID, 1, INSTR(bu.CHANGE_ID, ',') - 1)
        LEFT JOIN {tables.file_paths} fp
            ON t.OBJECT_ID = fp.{tables.file_path_col}
        WHERE n.LIFECYCLESTATE IN ('Released', 'Approved')
          AND fp.{tables.file_path_col} IS NOT NULL
    """


# ─────────────────────────────────────────────────────────────
# Public extraction function
# ─────────────────────────────────────────────────────────────

def extract_data(engine: Engine, tables: TableConfig) -> pd.DataFrame:
    """
    Run the 4-table JOIN and return a DataFrame ready for document processing.

    Post-query steps:
      1. Drop rows with no FILE_PATH.
      2. For PPT/PPTX: keep only the latest version per NER_ID.
      3. Deduplicate remaining rows on (NER_ID, FILE_PATH).

    Returns:
        DataFrame with one row per (NER_ID, document-file).
    """
    query = _build_query(tables)
    log.info("Running Oracle extraction query…")

    with engine.connect() as conn:
        df = pd.read_sql(text(query), conn)

    log.info("Raw rows returned: %d", len(df))

    df = df.dropna(subset=["FILE_PATH"])
    df["FILE_EXT"] = df["FILE_PATH"].str.lower().str.extract(r"(\.[a-z0-9]+)$")

    # ── Latest PPT / PPTX per NER_ID ──────────────────────────
    ppt_mask  = df["FILE_EXT"].isin([".pptx", ".ppt"])
    df_ppt    = df[ppt_mask].copy()
    df_other  = df[~ppt_mask].copy()

    if not df_ppt.empty:
        df_ppt["FILE_VERSION"] = pd.to_numeric(df_ppt["FILE_VERSION"], errors="coerce")
        df_ppt["FILE_DATE"]    = pd.to_datetime(df_ppt["FILE_DATE"], errors="coerce")
        df_ppt = (
            df_ppt
            .sort_values(["NER_ID", "FILE_VERSION", "FILE_DATE"],
                         ascending=[True, False, False])
            .drop_duplicates(subset=["NER_ID"], keep="first")
        )
        log.info("PPT rows after latest-version filter: %d", len(df_ppt))

    df = (
        pd.concat([df_ppt, df_other], ignore_index=True)
        .drop_duplicates(subset=["NER_ID", "FILE_PATH"])
        .reset_index(drop=True)
    )

    log.info("Final rows after dedup: %d", len(df))
    return df
