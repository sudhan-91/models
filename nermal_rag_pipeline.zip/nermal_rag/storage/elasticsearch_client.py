"""
storage/elasticsearch_client.py — Elasticsearch index management and bulk indexing.

Responsibilities:
  - Create the index with the correct dense_vector mapping (run once).
  - Build Elasticsearch documents from chunks + metadata.
  - Bulk-index documents with error reporting.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from elasticsearch import Elasticsearch, helpers

from config import ElasticsearchConfig, EmbeddingConfig, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Index mapping
# ─────────────────────────────────────────────────────────────

def _build_mapping(dims: int) -> dict:
    return {
        "mappings": {
            "properties": {
                # ── Identity ────────────────────────────────
                "ner_id":               {"type": "keyword"},
                "change_id":            {"type": "keyword"},
                "object_id":            {"type": "keyword"},
                "doc_hash":             {"type": "keyword"},
                # ── Project metadata (filterable) ────────────
                "project_type":         {"type": "keyword"},
                "package_family":       {"type": "keyword"},
                "package_name":         {"type": "keyword"},
                "facility":             {"type": "keyword"},
                "lifecyclestate":       {"type": "keyword"},
                "tc_lifecyclestate":    {"type": "keyword"},
                "milestone":            {"type": "keyword"},
                "project_phase":        {"type": "keyword"},
                "ner_change_class":     {"type": "keyword"},
                "tc_project_state":     {"type": "keyword"},
                "implementation_docu":  {"type": "keyword"},
                "triggered_by":         {"type": "keyword"},
                "actual_release_date":  {"type": "keyword"},
                # ── Rich text (full-text searchable) ────────
                "title":                {"type": "text", "analyzer": "english"},
                "motivation":           {"type": "text", "analyzer": "english"},
                "current_procedure":    {"type": "text", "analyzer": "english"},
                "new_procedure":        {"type": "text", "analyzer": "english"},
                "remark":               {"type": "text", "analyzer": "english"},
                "workdesc":             {"type": "text", "analyzer": "english"},
                "wfcomments":           {"type": "text", "analyzer": "english"},
                "chunk_text":           {"type": "text", "analyzer": "english"},
                # ── File info ───────────────────────────────
                "file_path":            {"type": "keyword"},
                "file_extension":       {"type": "keyword"},
                "file_version":         {"type": "keyword"},
                # ── Chunk position ──────────────────────────
                "chunk_index":          {"type": "integer"},
                "total_chunks":         {"type": "integer"},
                # ── Housekeeping ────────────────────────────
                "indexed_at":           {"type": "date"},
                # ── Vector ──────────────────────────────────
                "embedding": {
                    "type":       "dense_vector",
                    "dims":       dims,
                    "index":      True,
                    "similarity": "cosine",
                },
            }
        },
        "settings": {
            "number_of_shards":   2,
            "number_of_replicas": 1,
            "analysis": {
                "analyzer": {
                    "english": {
                        "type":      "standard",
                        "stopwords": "_english_",
                    }
                }
            },
        },
    }


# ─────────────────────────────────────────────────────────────
# Client factory
# ─────────────────────────────────────────────────────────────

def build_client(es_cfg: ElasticsearchConfig) -> Elasticsearch:
    """Create an authenticated Elasticsearch client."""
    kwargs: dict = {
        "request_timeout": es_cfg.request_timeout,
        "retry_on_timeout": True,
        "max_retries": 3,
    }
    if es_cfg.username and es_cfg.password:
        kwargs["basic_auth"] = (es_cfg.username, es_cfg.password)
    if es_cfg.ca_certs:
        kwargs["ca_certs"] = es_cfg.ca_certs

    client = Elasticsearch(es_cfg.url, **kwargs)
    log.info("Elasticsearch client created | url=%s", es_cfg.url)
    return client


def ensure_index(
    client: Elasticsearch,
    index: str,
    dims: int,
) -> None:
    """Create the index if it does not already exist."""
    if client.indices.exists(index=index):
        log.info("Index already exists: %s", index)
        return

    mapping = _build_mapping(dims)
    client.indices.create(index=index, body=mapping)
    log.info("Index created: %s (dims=%d)", index, dims)


# ─────────────────────────────────────────────────────────────
# Document builder
# ─────────────────────────────────────────────────────────────

def build_es_documents(
    row: pd.Series,
    chunks: list[str],
    embeddings: list[list[float]],
    index: str,
) -> list[dict]:
    """
    Build one Elasticsearch action dict per chunk.

    The document _id is deterministic: md5(file_path)[:12] + "_" + chunk_index
    so re-running the pipeline performs upserts, not duplicates.
    """
    file_path = str(row.get("FILE_PATH", ""))
    doc_hash  = hashlib.md5(file_path.encode()).hexdigest()[:12]
    now       = datetime.now(timezone.utc).isoformat()
    total     = len(chunks)

    docs: list[dict] = []
    for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
        doc: dict = {
            "_index": index,
            "_id":    f"{doc_hash}_{i}",
            "_source": {
                # Identity
                "ner_id":              row.get("NER_ID", ""),
                "change_id":           row.get("CHANGE_ID", ""),
                "object_id":           str(row.get("OBJECT_ID", "")),
                "doc_hash":            doc_hash,
                # Project metadata
                "project_type":        row.get("NER_PROJECT_TYPE", ""),
                "package_family":      row.get("PACKAGE_FAMILY", ""),
                "package_name":        row.get("PACKAGE_NAME", ""),
                "facility":            row.get("FACILITY", ""),
                "lifecyclestate":      row.get("LIFECYCLESTATE", ""),
                "tc_lifecyclestate":   row.get("TC_LIFECYCLESTATE", ""),
                "milestone":           row.get("MILESTONE", ""),
                "project_phase":       row.get("PROJECT_PHASE", ""),
                "ner_change_class":    row.get("NER_CHANGE_CLASS", ""),
                "tc_project_state":    row.get("TC_PROJECT_STATE", ""),
                "implementation_docu": row.get("IMPLEMENTATION_DOCU_IN", ""),
                "triggered_by":        row.get("TRIGGERED_BY", ""),
                "actual_release_date": str(row.get("ACTUAL_RELEASE_DATE", "")),
                # Rich text
                "title":               row.get("TITLE", ""),
                "motivation":          row.get("MOTIVATION", ""),
                "current_procedure":   row.get("CURRENT_PROCEDURE", ""),
                "new_procedure":       row.get("NEW_PROCEDURE", ""),
                "remark":              row.get("REMARK", ""),
                "workdesc":            row.get("WORKDESC", ""),
                "wfcomments":          row.get("WFCOMMENTS", ""),
                # Chunk
                "chunk_text":          chunk,
                "chunk_index":         i,
                "total_chunks":        total,
                # File
                "file_path":           file_path,
                "file_extension":      Path(file_path).suffix.lower(),
                "file_version":        str(row.get("FILE_VERSION", "")),
                # Housekeeping
                "indexed_at":          now,
                # Vector
                "embedding":           emb,
            },
        }
        docs.append(doc)

    return docs


# ─────────────────────────────────────────────────────────────
# Bulk indexing
# ─────────────────────────────────────────────────────────────

def bulk_index(
    client: Elasticsearch,
    documents: list[dict],
) -> tuple[int, int]:
    """
    Bulk-index a list of ES action dicts.

    Returns:
        (success_count, error_count)
    """
    if not documents:
        return 0, 0

    success, errors = helpers.bulk(
        client,
        documents,
        raise_on_error=False,
        raise_on_exception=False,
    )

    if errors:
        for err in errors[:5]:               # log first 5 errors only
            log.error("ES bulk error: %s", err)

    return success, len(errors)
