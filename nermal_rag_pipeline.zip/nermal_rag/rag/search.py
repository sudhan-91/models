"""
rag/search.py — RAG query interface for the NERMAL knowledge base.

Provides:
  - Vector (knn) search with optional keyword filters.
  - Hybrid search (knn + BM25 full-text) for better precision.
  - A simple context builder that formats retrieved chunks for an LLM prompt.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

from config import ElasticsearchConfig, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Result type
# ─────────────────────────────────────────────────────────────

@dataclass
class SearchResult:
    score:           float
    ner_id:          str
    title:           str
    facility:        str
    milestone:       str
    package_family:  str
    implementation_docu: str
    file_path:       str
    file_extension:  str
    chunk_index:     int
    total_chunks:    int
    chunk_text:      str


# ─────────────────────────────────────────────────────────────
# Vector search
# ─────────────────────────────────────────────────────────────

def vector_search(
    query: str,
    model: SentenceTransformer,
    client: Elasticsearch,
    es_cfg: ElasticsearchConfig,
    top_k: int = 10,
    filters: Optional[dict[str, str]] = None,
) -> list[SearchResult]:
    """
    Pure knn (vector) search.

    Args:
        query:   Natural language question.
        model:   Loaded SentenceTransformer (must match the indexed model).
        client:  Elasticsearch client.
        es_cfg:  Config (contains index name, num_candidates).
        top_k:   Number of results to return.
        filters: Optional keyword filters applied inside knn, e.g.
                 {"facility": "Warstein", "lifecyclestate": "Released"}.

    Returns:
        List of SearchResult ordered by relevance score descending.
    """
    query_vector = model.encode([query], normalize_embeddings=True)[0].tolist()

    knn_clause: dict = {
        "field":        "embedding",
        "query_vector": query_vector,
        "k":            top_k,
        "num_candidates": top_k * es_cfg.num_candidates,
    }

    if filters:
        knn_clause["filter"] = {
            "bool": {
                "must": [{"term": {k: v}} for k, v in filters.items()]
            }
        }

    response = client.search(
        index=es_cfg.index,
        body={
            "knn":      knn_clause,
            "_source":  {"excludes": ["embedding"]},
            "size":     top_k,
        },
    )

    return _parse_hits(response)


# ─────────────────────────────────────────────────────────────
# Hybrid search  (knn + BM25)
# ─────────────────────────────────────────────────────────────

def hybrid_search(
    query: str,
    model: SentenceTransformer,
    client: Elasticsearch,
    es_cfg: ElasticsearchConfig,
    top_k: int = 10,
    filters: Optional[dict[str, str]] = None,
    bm25_weight: float = 0.3,
    vector_weight: float = 0.7,
) -> list[SearchResult]:
    """
    Hybrid knn + BM25 search using Elasticsearch RRF (Reciprocal Rank Fusion).

    Falls back to pure vector search if the ES version does not support RRF.

    Args:
        bm25_weight:   Weight for BM25 full-text score.
        vector_weight: Weight for knn score.
        (remaining args identical to vector_search)
    """
    query_vector = model.encode([query], normalize_embeddings=True)[0].tolist()

    filter_clause = None
    if filters:
        filter_clause = {
            "bool": {
                "must": [{"term": {k: v}} for k, v in filters.items()]
            }
        }

    # Try RRF (Elasticsearch 8.8+)
    try:
        rrf_body: dict = {
            "retriever": {
                "rrf": {
                    "retrievers": [
                        {
                            "standard": {
                                "query": {
                                    "multi_match": {
                                        "query":  query,
                                        "fields": [
                                            "chunk_text^2",
                                            "title^3",
                                            "motivation",
                                            "current_procedure",
                                            "new_procedure",
                                        ],
                                    }
                                },
                                **({"filter": filter_clause} if filter_clause else {}),
                            }
                        },
                        {
                            "knn": {
                                "field":          "embedding",
                                "query_vector":   query_vector,
                                "k":              top_k,
                                "num_candidates": top_k * es_cfg.num_candidates,
                                **({"filter": filter_clause} if filter_clause else {}),
                            }
                        },
                    ],
                    "rank_window_size": top_k * 2,
                    "rank_constant":    60,
                }
            },
            "_source": {"excludes": ["embedding"]},
            "size":    top_k,
        }
        response = client.search(index=es_cfg.index, body=rrf_body)
        return _parse_hits(response)

    except Exception as exc:
        log.warning(
            "RRF not supported (ES < 8.8?), falling back to pure vector search. Error: %s",
            exc,
        )
        return vector_search(
            query, model, client, es_cfg, top_k=top_k, filters=filters
        )


# ─────────────────────────────────────────────────────────────
# Context builder for LLM prompting
# ─────────────────────────────────────────────────────────────

def build_context(results: list[SearchResult], max_chars: int = 8000) -> str:
    """
    Format retrieved chunks into a context string for an LLM prompt.

    Chunks are ordered by score (already sorted) and truncated to max_chars.

    Returns:
        A formatted multi-chunk context block.
    """
    parts: list[str] = []
    total = 0

    for i, r in enumerate(results, start=1):
        header = (
            f"--- Source {i} | NER_ID: {r.ner_id} | {r.title} "
            f"| {r.facility} | {r.milestone} | {r.implementation_docu} ---"
        )
        body   = r.chunk_text.strip()
        block  = f"{header}\n{body}"

        if total + len(block) > max_chars:
            break

        parts.append(block)
        total += len(block)

    return "\n\n".join(parts)


# ─────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────

def _parse_hits(response: dict) -> list[SearchResult]:
    results: list[SearchResult] = []
    for hit in response.get("hits", {}).get("hits", []):
        src = hit["_source"]
        results.append(
            SearchResult(
                score=               hit.get("_score") or 0.0,
                ner_id=              src.get("ner_id", ""),
                title=               src.get("title", ""),
                facility=            src.get("facility", ""),
                milestone=           src.get("milestone", ""),
                package_family=      src.get("package_family", ""),
                implementation_docu= src.get("implementation_docu", ""),
                file_path=           src.get("file_path", ""),
                file_extension=      src.get("file_extension", ""),
                chunk_index=         src.get("chunk_index", 0),
                total_chunks=        src.get("total_chunks", 0),
                chunk_text=          src.get("chunk_text", ""),
            )
        )
    return results
