"""
storage/elasticsearch_client.py — Stage 5: Elasticsearch Indexing.

Index mapping supports:
  - BM25 full-text search on the `text` field
  - kNN approximate nearest-neighbour search on `embedding` (HNSW, dims=1536)
  - Metadata keyword filters: source, slide_sheet, date, file_type, sheet_name
  - Nested-array table_headers and footer_key stored as keyword arrays
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from elasticsearch import Elasticsearch, helpers

from config import Config, cfg
from processing.chunker import Chunk
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Index mapping
# ─────────────────────────────────────────────────────────────

def _build_mapping(dims: int) -> dict:
    return {
        "mappings": {
            "properties": {
                # ── Full-text search ─────────────────────────
                "text":          {"type": "text", "analyzer": "english"},
                # ── Keyword filters ──────────────────────────
                "source":        {"type": "keyword"},
                "filename":      {"type": "keyword"},
                "file_type":     {"type": "keyword"},   # pptx | xlsx
                "slide_sheet":   {"type": "keyword"},   # slide title or sheet name
                "date":          {"type": "date"},
                "source_dir":    {"type": "keyword"},
                # ── PPTX-specific ────────────────────────────
                "slide_number":  {"type": "integer"},
                "total_slides":  {"type": "integer"},
                # ── XLSX-specific ────────────────────────────
                "sheet_name":    {"type": "keyword"},
                "table_index":   {"type": "integer"},
                "row_start":     {"type": "integer"},
                "row_end":       {"type": "integer"},
                # Nested-array format — stored as flat keyword arrays
                "table_headers": {"type": "keyword"},   # ["Col A", "Col B", ...]
                "footer_key":    {"type": "keyword"},   # ["footer label"]
                # ── Chunk info ───────────────────────────────
                "chunk_id":      {"type": "keyword"},
                "chunk_index":   {"type": "integer"},
                "total_chunks":  {"type": "integer"},
                # ── Housekeeping ─────────────────────────────
                "indexed_at":    {"type": "date"},
                # ── Vector ───────────────────────────────────
                "embedding": {
                    "type":           "dense_vector",
                    "dims":           dims,
                    "index":          True,
                    "similarity":     "cosine",
                    "index_options":  {
                        "type":            "hnsw",
                        "m":               16,
                        "ef_construction": 100,
                    },
                },
            }
        },
        "settings": {
            "number_of_shards":   2,
            "number_of_replicas": 1,
            "analysis": {
                "analyzer": {
                    "english": {
                        "type":      "standard",
                        "stopwords": "_english_",
                    }
                }
            },
        },
    }


# ─────────────────────────────────────────────────────────────
# Client
# ─────────────────────────────────────────────────────────────

def build_client(config: Config) -> Elasticsearch:
    kwargs: dict = {
        "request_timeout": config.es_request_timeout,
        "retry_on_timeout": True,
        "max_retries": 3,
    }
    if config.es_username and config.es_password:
        kwargs["basic_auth"] = (config.es_username, config.es_password)
    if config.es_ca_certs:
        kwargs["ca_certs"] = config.es_ca_certs

    client = Elasticsearch(config.es_url, **kwargs)
    log.info("Elasticsearch client ready | url=%s", config.es_url)
    return client


def ensure_index(client: Elasticsearch, config: Config) -> None:
    if client.indices.exists(index=config.es_index):
        log.info("Index exists: %s", config.es_index)
        return
    client.indices.create(
        index=config.es_index,
        body=_build_mapping(config.embedding_dims),
    )
    log.info("Index created: %s (dims=%d)", config.es_index, config.embedding_dims)


# ─────────────────────────────────────────────────────────────
# Document builder
# ─────────────────────────────────────────────────────────────

def _chunk_to_doc(chunk: Chunk, index: str) -> dict:
    """
    Convert a Chunk into an Elasticsearch bulk action dict.

    table_headers are flattened from [["Col A"], ["Col B"]] → ["Col A", "Col B"]
    for keyword storage. The full nested structure is preserved in chunk_text.
    """
    now = datetime.now(timezone.utc).isoformat()

    # Flatten nested-array headers for keyword storage
    flat_headers = [h[0] if h else "" for h in (chunk.table_headers or [])]

    source: dict = {
        "text":         chunk.chunk_text,
        "source":       chunk.source,
        "filename":     chunk.filename,
        "file_type":    chunk.file_type,
        "chunk_id":     chunk.chunk_id,
        "chunk_index":  chunk.chunk_index,
        "total_chunks": chunk.total_chunks,
        "source_dir":   chunk.source_dir,
        "indexed_at":   now,
        "embedding":    getattr(chunk, "embedding", None),
    }

    if chunk.last_modified:
        try:
            source["date"] = datetime.fromisoformat(chunk.last_modified).isoformat()
        except ValueError:
            source["date"] = now

    if chunk.file_type == "pptx":
        source.update({
            "slide_number": chunk.slide_number,
            "slide_sheet":  chunk.slide_title or f"Slide {chunk.slide_number}",
        })
    elif chunk.file_type == "xlsx":
        source.update({
            "sheet_name":    chunk.sheet_name,
            "slide_sheet":   chunk.sheet_name,
            "table_index":   chunk.table_index,
            "row_start":     chunk.row_start,
            "row_end":       chunk.row_end,
            "table_headers": flat_headers,
            "footer_key":    chunk.footer_key or [],
        })

    return {
        "_index": index,
        "_id":    chunk.chunk_id,
        "_source": source,
    }


# ─────────────────────────────────────────────────────────────
# Bulk indexing
# ─────────────────────────────────────────────────────────────

def bulk_index(
    client: Elasticsearch,
    chunks: list[Chunk],
    config: Config,
) -> tuple[int, int]:
    """
    Bulk-index a list of embedded Chunks.
    Returns (success_count, error_count).
    """
    if not chunks:
        return 0, 0

    docs = [_chunk_to_doc(c, config.es_index) for c in chunks]
    success, errors = helpers.bulk(
        client, docs,
        raise_on_error=False,
        raise_on_exception=False,
        chunk_size=config.es_bulk_batch_size,
    )

    if errors:
        for err in errors[:5]:
            log.error("ES bulk error: %s", err)

    return success, len(errors)
