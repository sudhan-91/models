"""
pipeline.py — Main ingestion orchestrator (Stages 1–5).

Wires together every module in order:
  Stage 1 — File ingestion   (ingestion/file_watcher.py)
  Stage 2 — Parsing          (parsers/pptx_parser.py, parsers/xlsx_parser.py)
  Stage 3 — Chunking         (processing/chunker.py)
  Stage 4 — Embedding        (processing/embedder.py)
  Stage 5 — ES indexing      (storage/elasticsearch_client.py)

Run:
    python pipeline.py              # incremental (skips unchanged files)
    python pipeline.py --full       # reprocess all files
"""

from __future__ import annotations

import sys
import time
import argparse

from dotenv import load_dotenv
load_dotenv()

from config import cfg
from logger import get_logger
from ingestion.file_watcher import scan_files
from parsers.pptx_parser import parse_pptx
from parsers.xlsx_parser import parse_xlsx
from processing.chunker import chunk_slides, chunk_table
from processing.embedder import embed_chunks
from storage.elasticsearch_client import build_client, ensure_index, bulk_index

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


class Stats:
    def __init__(self) -> None:
        self.files_scanned:  int = 0
        self.files_parsed:   int = 0
        self.files_failed:   int = 0
        self.total_chunks:   int = 0
        self.es_success:     int = 0
        self.es_errors:      int = 0
        self.failed: list[str]   = []

    def report(self) -> str:
        return (
            "\n"
            "═══════════════════════════════════════════\n"
            " PPT & XLS → ELK RAG Pipeline — Statistics \n"
            "═══════════════════════════════════════════\n"
            f"  Files scanned       : {self.files_scanned:>8,}\n"
            f"  Files parsed        : {self.files_parsed:>8,}\n"
            f"  Files failed        : {self.files_failed:>8,}\n"
            f"  Total chunks created: {self.total_chunks:>8,}\n"
            f"  ES docs indexed     : {self.es_success:>8,}\n"
            f"  ES index errors     : {self.es_errors:>8,}\n"
            "═══════════════════════════════════════════"
        )


def run(incremental: bool = True) -> Stats:
    stats   = Stats()
    t_start = time.perf_counter()

    log.info("════════════════════════════════════════")
    log.info(" PPT & XLS → ELK RAG Pipeline — START  ")
    log.info("════════════════════════════════════════")

    # ── Stage 2 setup: Elasticsearch ──────────────────────────
    log.info("[Setup] Connecting to Elasticsearch…")
    es_client = build_client(cfg)
    ensure_index(es_client, cfg)

    # ── Stage 1: File ingestion ────────────────────────────────
    log.info("[Stage 1] Scanning: %s", cfg.watch_dir)
    bulk_buffer: list = []

    for file_record in scan_files(cfg, incremental=incremental):
        stats.files_scanned += 1
        chunks = []

        try:
            # ── Stage 2: Parsing ─────────────────────────────
            if file_record.extension == ".pptx":
                slides = parse_pptx(file_record, cfg)
                if not slides:
                    continue
                # ── Stage 3: Chunking ─────────────────────────
                chunks = chunk_slides(slides, cfg)

            elif file_record.extension == ".xlsx":
                tables = parse_xlsx(file_record, cfg)
                if not tables:
                    continue
                # ── Stage 3: Chunking (per table) ─────────────
                for table in tables:
                    chunks.extend(chunk_table(table, cfg))

        except Exception as exc:
            log.error("Parse/chunk failed: %s | %s", file_record.filename, exc,
                      exc_info=True)
            stats.files_failed += 1
            stats.failed.append(file_record.file_path)
            continue

        if not chunks:
            log.warning("No chunks produced from: %s", file_record.filename)
            continue

        stats.files_parsed  += 1
        stats.total_chunks  += len(chunks)

        # ── Stage 4: Embedding ────────────────────────────────
        chunks = embed_chunks(chunks, cfg)

        # ── Stage 5: Buffer for bulk index ────────────────────
        bulk_buffer.extend(chunks)

        if len(bulk_buffer) >= cfg.es_bulk_batch_size:
            ok, err = bulk_index(es_client, bulk_buffer, cfg)
            stats.es_success += ok
            stats.es_errors  += err
            log.info("Flushed %d docs | ok=%d err=%d", len(bulk_buffer), ok, err)
            bulk_buffer = []

    # Final flush
    if bulk_buffer:
        ok, err = bulk_index(es_client, bulk_buffer, cfg)
        stats.es_success += ok
        stats.es_errors  += err
        log.info("Final flush: %d docs (ok=%d err=%d)", len(bulk_buffer), ok, err)

    elapsed = time.perf_counter() - t_start
    log.info("Pipeline complete in %.1f seconds", elapsed)
    log.info(stats.report())

    if stats.failed:
        log.warning("Failed files:")
        for f in stats.failed[:20]:
            log.warning("  %s", f)

    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PPT & XLS → ELK RAG ingestion pipeline")
    parser.add_argument(
        "--full", action="store_true",
        help="Reprocess all files (ignore incremental manifest)",
    )
    args = parser.parse_args()
    result = run(incremental=not args.full)
    sys.exit(0 if result.es_errors == 0 else 1)
