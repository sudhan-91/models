"""
api/app.py — FastAPI REST endpoint for the RAG query interface.

Endpoints:
  POST /query   — submit a natural language question, get a grounded answer
  GET  /health  — liveness check

Run:
    uvicorn api.app:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from config import cfg
from storage.elasticsearch_client import build_client
from rag.retriever import hybrid_search
from rag.generator import generate_answer
from logger import get_logger

log  = get_logger(__name__, cfg.log_dir, cfg.log_level)
app  = FastAPI(title="PPT & XLS RAG API", version="1.0.0")
_es  = None   # lazy-initialised on first request


def _get_es():
    global _es
    if _es is None:
        _es = build_client(cfg)
    return _es


# ─────────────────────────────────────────────────────────────
# Request / Response schemas
# ─────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    query:      str
    top_k:      Optional[int]   = None       # overrides config.context_top_n
    filters:    Optional[dict]  = None       # e.g. {"file_type": "pptx"}
    date_from:  Optional[str]   = None       # ISO date
    date_to:    Optional[str]   = None


class SourceRef(BaseModel):
    filename:   str
    slide_sheet: str
    chunk_id:   str


class QueryResponse(BaseModel):
    answer:     str
    sources:    list[SourceRef]
    chunks_used: int


# ─────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/query", response_model=QueryResponse)
def query(request: QueryRequest):
    if not request.query.strip():
        raise HTTPException(status_code=400, detail="Query must not be empty.")

    # Override top_n if caller specified
    local_cfg = cfg
    if request.top_k:
        import copy
        local_cfg = copy.copy(cfg)
        local_cfg.context_top_n = request.top_k

    try:
        chunks = hybrid_search(
            query=     request.query,
            client=    _get_es(),
            config=    local_cfg,
            filters=   request.filters,
            date_from= request.date_from,
            date_to=   request.date_to,
        )

        result = generate_answer(
            query=  request.query,
            chunks= chunks,
            config= local_cfg,
        )

    except Exception as exc:
        log.error("Query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc))

    return QueryResponse(
        answer=      result["answer"],
        sources=     [SourceRef(**s) for s in result["sources"]],
        chunks_used= len(chunks),
    )
