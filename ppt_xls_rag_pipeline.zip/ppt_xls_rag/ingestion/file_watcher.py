"""
ingestion/file_watcher.py — Stage 1: File Ingestion.

Scans a watch directory (local filesystem or network share) for new or
updated .pptx / .xlsx files and yields FileRecord objects to the pipeline.

Supports:
  - Local filesystem / network share (UNC path)
  - Skip patterns (e.g. Office temp files starting with ~$)
  - Change detection via mtime — only yields files modified since last run
  - State persistence in a JSON manifest so reruns are incremental
"""

from __future__ import annotations

import fnmatch
import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterator

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)

MANIFEST_PATH = ".ingest_manifest.json"


@dataclass
class FileRecord:
    """Metadata captured at ingestion time for a single file."""
    file_path:    str
    filename:     str
    extension:    str        # .pptx or .xlsx
    file_size:    int        # bytes
    last_modified: str       # ISO 8601
    source_dir:   str
    content_hash: str = ""   # filled by embedder cache


# ─────────────────────────────────────────────────────────────
# Manifest (tracks last-seen mtime per file path)
# ─────────────────────────────────────────────────────────────

def _load_manifest(manifest_path: str) -> dict[str, float]:
    if Path(manifest_path).exists():
        with open(manifest_path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_manifest(manifest: dict[str, float], manifest_path: str) -> None:
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)


# ─────────────────────────────────────────────────────────────
# Skip-pattern helpers
# ─────────────────────────────────────────────────────────────

def _should_skip(filename: str, skip_patterns: str) -> bool:
    patterns = [p.strip() for p in skip_patterns.split(",") if p.strip()]
    return any(fnmatch.fnmatch(filename, pat) for pat in patterns)


# ─────────────────────────────────────────────────────────────
# Public scanner
# ─────────────────────────────────────────────────────────────

def scan_files(
    config: Config,
    manifest_path: str = MANIFEST_PATH,
    incremental: bool = True,
) -> Iterator[FileRecord]:
    """
    Walk watch_dir and yield a FileRecord for every supported file that is
    new or modified since the last run (when incremental=True).

    Args:
        config:        Pipeline config.
        manifest_path: Path to the JSON manifest file.
        incremental:   If False, yields all files regardless of prior runs.

    Yields:
        FileRecord for each file to process.
    """
    watch_path = Path(config.watch_dir)
    if not watch_path.exists():
        log.error("Watch directory does not exist: %s", watch_path)
        return

    manifest = _load_manifest(manifest_path) if incremental else {}
    updated_manifest = dict(manifest)
    yielded = 0

    for file_path in sorted(watch_path.rglob("*")):
        if not file_path.is_file():
            continue
        if file_path.suffix.lower() not in config.supported_extensions:
            continue
        if _should_skip(file_path.name, config.skip_patterns):
            log.debug("Skipping (pattern match): %s", file_path.name)
            continue

        mtime = file_path.stat().st_mtime
        str_path = str(file_path)

        if incremental and manifest.get(str_path) == mtime:
            log.debug("Unchanged, skipping: %s", file_path.name)
            continue

        stat = file_path.stat()
        record = FileRecord(
            file_path=    str_path,
            filename=     file_path.name,
            extension=    file_path.suffix.lower(),
            file_size=    stat.st_size,
            last_modified=datetime.fromtimestamp(stat.st_mtime).isoformat(),
            source_dir=   str(file_path.parent),
        )

        log.info("Ingesting: %s (%.1f KB)", file_path.name, stat.st_size / 1024)
        updated_manifest[str_path] = mtime
        yielded += 1
        yield record

    _save_manifest(updated_manifest, manifest_path)
    log.info("Scan complete — %d file(s) to process", yielded)
