"""
parsers/xlsx_parser.py — Stage 2: XLSX Parsing.

Extracts structured table content from Excel files.

Key behaviours (addressing known issues):
  1. JSON format — table_headers and footer_key use the nested-array format:
       { "table_headers": [["Col A"], ["Col B"]], "footer_key": ["label"] }
  2. Multi-table detection — a sheet may contain multiple logical tables
     separated by blank rows or bold-header rows.  Each is parsed independently.
  3. Column segmentation — headers are detected per-table, per-sheet (not globally).
  4. Duplicate table suppression — tables with identical header fingerprints
     and content hashes within the same file are skipped.
  5. Split-table prevention — a gap of < MIN_GAP_ROWS blank rows between
     tables is treated as the same table (continuation after a spacer row).
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Optional

import openpyxl
from openpyxl.cell import Cell
from openpyxl.styles import Font

from config import Config, cfg
from ingestion.file_watcher import FileRecord
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)

# A row is considered a "section header" if it has >= this many bold cells
BOLD_HEADER_BOLD_THRESHOLD = 2
# Minimum consecutive blank rows to consider a table boundary
MIN_GAP_ROWS = 2


@dataclass
class TableRecord:
    """
    Parsed content for one logical table within an Excel sheet.

    JSON output follows the expected nested-array format:
      table_headers: [["Col A"], ["Col B"], ...]
      footer_key:    ["footer label"]
    """
    source:       str
    filename:     str
    sheet_name:   str
    table_index:  int          # 0-based index within the sheet
    table_headers: list[list[str]]   # [["Header 1"], ["Header 2"], ...]
    rows:         list[dict]         # list of {header: value} dicts
    footer_key:   list[str]          # ["footer label"] or []
    row_start:    int                # 1-based row number in the sheet
    row_end:      int
    full_text:    str                # flattened text for chunking
    content_hash: str                # SHA-256 of full_text (for dedup)
    metadata:     dict

    def to_json_format(self) -> dict:
        """Return the expected nested-array JSON structure."""
        return {
            "table_headers": self.table_headers,
            "footer_key":    self.footer_key,
            "rows":          self.rows,
        }


# ─────────────────────────────────────────────────────────────
# Row-level helpers
# ─────────────────────────────────────────────────────────────

def _cell_value(cell: Cell) -> str:
    """Return a clean string value for a cell."""
    v = cell.value
    if v is None:
        return ""
    return str(v).strip()


def _is_bold(cell: Cell) -> bool:
    """Return True if the cell has bold formatting."""
    try:
        return bool(cell.font and cell.font.bold)
    except Exception:
        return False


def _row_values(row: tuple[Cell, ...]) -> list[str]:
    return [_cell_value(c) for c in row]


def _is_blank_row(row: tuple[Cell, ...]) -> bool:
    return all(_cell_value(c) == "" for c in row)


def _is_bold_header_row(row: tuple[Cell, ...]) -> bool:
    """True if >= BOLD_HEADER_BOLD_THRESHOLD cells in the row are bold and non-empty."""
    bold_count = sum(
        1 for c in row
        if _cell_value(c) and _is_bold(c)
    )
    return bold_count >= BOLD_HEADER_BOLD_THRESHOLD


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def _header_fingerprint(headers: list[list[str]]) -> str:
    flat = "|".join(h[0] if h else "" for h in headers)
    return hashlib.md5(flat.encode()).hexdigest()[:8]


# ─────────────────────────────────────────────────────────────
# Table boundary detection
# ─────────────────────────────────────────────────────────────

def _find_table_regions(
    rows: list[tuple[Cell, ...]],
) -> list[tuple[int, int]]:
    """
    Scan a list of sheet rows and return (start_idx, end_idx) pairs
    for each logical table region (0-based indices into `rows`).

    A new table region starts when:
      - A blank gap of >= MIN_GAP_ROWS rows is encountered, OR
      - A bold-header row follows non-blank content rows.
    """
    regions: list[tuple[int, int]] = []
    n = len(rows)
    i = 0

    while i < n:
        # Skip leading blank rows
        while i < n and _is_blank_row(rows[i]):
            i += 1
        if i >= n:
            break

        region_start = i

        while i < n:
            # Count consecutive blank rows
            blank_run = 0
            j = i
            while j < n and _is_blank_row(rows[j]):
                blank_run += 1
                j += 1

            if blank_run >= MIN_GAP_ROWS:
                # Hard boundary — end current table
                break

            if blank_run > 0:
                # Short gap — treat as spacer inside same table, skip it
                i = j
                continue

            # Non-blank row
            # Bold header after content signals a new table section
            if (
                i > region_start
                and _is_bold_header_row(rows[i])
                and not _is_blank_row(rows[i - 1])
            ):
                break

            i += 1

        if i > region_start:
            regions.append((region_start, i - 1))

    return regions


# ─────────────────────────────────────────────────────────────
# Single-table parser
# ─────────────────────────────────────────────────────────────

def _parse_table_region(
    region_rows: list[tuple[Cell, ...]],
    source: str,
    filename: str,
    sheet_name: str,
    table_index: int,
    row_offset: int,       # 1-based row number of region_rows[0] in the sheet
    record_metadata: dict,
    config: Config,
) -> Optional[TableRecord]:
    """
    Parse a single contiguous table region into a TableRecord.

    Row 0 of region_rows is treated as the header row.
    The last non-empty row that has no matching header data is treated as footer.
    """
    if not region_rows:
        return None

    # Strip leading/trailing blank rows from the region
    start = 0
    while start < len(region_rows) and _is_blank_row(region_rows[start]):
        start += 1
    end = len(region_rows) - 1
    while end >= start and _is_blank_row(region_rows[end]):
        end -= 1

    region_rows = region_rows[start: end + 1]
    if not region_rows:
        return None

    # ── Header row ────────────────────────────────────────────
    raw_headers = _row_values(region_rows[0])
    # Filter out completely empty header cells but preserve position
    # Expected format: [["Col A"], ["Col B"], ...]
    table_headers: list[list[str]] = [
        [h] if h else [""]
        for h in raw_headers
    ]

    # Strip trailing empty headers
    while table_headers and table_headers[-1] == [""]:
        table_headers.pop()

    if not any(h[0] for h in table_headers):
        log.debug("Skipping table region with no header text in %s/%s",
                  filename, sheet_name)
        return None

    header_labels = [h[0] for h in table_headers]
    n_cols = len(header_labels)

    # ── Data rows ─────────────────────────────────────────────
    data_rows   = region_rows[1:]
    footer_key: list[str] = []

    # Detect footer: last non-blank row where all values are in the first cell
    # and no subsequent data rows exist
    if data_rows:
        last_row_vals = _row_values(data_rows[-1])
        non_empty = [v for v in last_row_vals if v]
        if len(non_empty) == 1 and last_row_vals[0]:
            footer_key = [last_row_vals[0]]
            data_rows = data_rows[:-1]

    parsed_rows: list[dict] = []
    for row in data_rows:
        if _is_blank_row(row):
            continue
        vals = _row_values(row)
        row_dict: dict = {}
        for col_idx, header in enumerate(header_labels):
            val = vals[col_idx].strip() if col_idx < len(vals) else ""
            if header or val:
                row_dict[header or f"col_{col_idx}"] = val
        if any(v for v in row_dict.values()):
            parsed_rows.append(row_dict)

    if not parsed_rows:
        return None

    # ── Full text (for chunking + hashing) ────────────────────
    header_line = " | ".join(header_labels)
    row_lines   = [
        " | ".join(str(r.get(h, "")) for h in header_labels)
        for r in parsed_rows
    ]
    full_text = f"[Headers] {header_line}\n" + "\n".join(row_lines)
    if footer_key:
        full_text += f"\n[Footer] {footer_key[0]}"

    if len(full_text.strip()) < config.min_text_length:
        return None

    return TableRecord(
        source=        source,
        filename=      filename,
        sheet_name=    sheet_name,
        table_index=   table_index,
        table_headers= table_headers,
        rows=          parsed_rows,
        footer_key=    footer_key,
        row_start=     row_offset + start + 1,
        row_end=       row_offset + start + len(region_rows),
        full_text=     full_text,
        content_hash=  _content_hash(full_text),
        metadata=      record_metadata,
    )


# ─────────────────────────────────────────────────────────────
# Sheet parser
# ─────────────────────────────────────────────────────────────

def _parse_sheet(
    ws,
    source: str,
    filename: str,
    config: Config,
    record_metadata: dict,
) -> list[TableRecord]:
    """Parse all logical tables within a single worksheet."""
    all_rows = list(ws.iter_rows())
    if not all_rows:
        return []

    regions = _find_table_regions(all_rows)
    log.debug(
        "Sheet '%s' in %s — detected %d table region(s)",
        ws.title, filename, len(regions),
    )

    seen_hashes: set[str] = set()
    seen_fingerprints: set[str] = set()
    tables: list[TableRecord] = []

    for t_idx, (r_start, r_end) in enumerate(regions):
        region_rows = all_rows[r_start: r_end + 1]

        table = _parse_table_region(
            region_rows=   region_rows,
            source=        source,
            filename=      filename,
            sheet_name=    ws.title,
            table_index=   t_idx,
            row_offset=    r_start,
            record_metadata=record_metadata,
            config=        config,
        )

        if table is None:
            continue

        # ── Duplicate suppression ──────────────────────────────
        fingerprint = _header_fingerprint(table.table_headers)
        if table.content_hash in seen_hashes:
            log.debug(
                "Skipping duplicate table (same content) at rows %d-%d in %s/%s",
                table.row_start, table.row_end, filename, ws.title,
            )
            continue
        if fingerprint in seen_fingerprints and len(table.rows) < 3:
            # Same headers + tiny table = likely a split fragment, skip
            log.debug(
                "Skipping likely split fragment (same headers, <3 rows) "
                "at rows %d-%d in %s/%s",
                table.row_start, table.row_end, filename, ws.title,
            )
            continue

        seen_hashes.add(table.content_hash)
        seen_fingerprints.add(fingerprint)
        tables.append(table)

    return tables


# ─────────────────────────────────────────────────────────────
# Public parser
# ─────────────────────────────────────────────────────────────

def parse_xlsx(record: FileRecord, config: Config) -> list[TableRecord]:
    """
    Parse an XLSX file into a list of TableRecord objects.

    Each logical table in each sheet becomes one TableRecord.
    Duplicates (same content hash) and split fragments are suppressed.

    Returns:
        List of TableRecord (may be empty if file has no text content).
    """
    try:
        wb = openpyxl.load_workbook(record.file_path, read_only=False, data_only=True)
    except Exception as exc:
        log.error("Failed to open XLSX: %s | error: %s", record.file_path, exc)
        return []

    log.info("Parsing XLSX: %s (%d sheets)", record.filename, len(wb.sheetnames))

    record_metadata = {
        "file_size":     record.file_size,
        "last_modified": record.last_modified,
        "source_dir":    record.source_dir,
    }

    all_tables: list[TableRecord] = []
    global_hashes: set[str] = set()

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        tables = _parse_sheet(
            ws=              ws,
            source=          record.file_path,
            filename=        record.filename,
            config=          config,
            record_metadata= record_metadata,
        )

        # Cross-sheet duplicate suppression
        for t in tables:
            if t.content_hash in global_hashes:
                log.debug(
                    "Skipping cross-sheet duplicate table in sheet '%s' of %s",
                    sheet_name, record.filename,
                )
                continue
            global_hashes.add(t.content_hash)
            all_tables.append(t)

    wb.close()
    log.info(
        "XLSX parsed: %s → %d table(s) across %d sheet(s)",
        record.filename, len(all_tables), len(wb.sheetnames),
    )
    return all_tables
