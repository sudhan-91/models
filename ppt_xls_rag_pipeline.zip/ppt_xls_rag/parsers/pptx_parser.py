"""
parsers/pptx_parser.py — Stage 2: PPTX Parsing.

Extracts per-slide content from a PowerPoint file.
Each slide yields a SlideRecord containing:
  - slide title
  - body text (all text frames, excluding title)
  - speaker notes
  - slide number and total slide count
  - source metadata

Handles:
  - Boilerplate/footer detection (text repeated on >80% of slides is skipped)
  - Empty slide skipping
  - Tables inside slides (rows joined with " | ")
  - Optional OCR fallback for image-only slides (requires pytesseract)
"""

from __future__ import annotations

import hashlib
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from pptx import Presentation
from pptx.enum.shapes import PP_PLACEHOLDER

from config import Config, cfg
from ingestion.file_watcher import FileRecord
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)

# Fraction of slides a text must appear on to be considered boilerplate
BOILERPLATE_THRESHOLD = 0.8


@dataclass
class SlideRecord:
    """Parsed content for a single PowerPoint slide."""
    source:       str     # original file path
    filename:     str
    slide_number: int
    total_slides: int
    title:        str
    body_text:    str
    notes:        str
    full_text:    str     # title + body + notes combined (used for chunking)
    metadata:     dict


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

def _extract_shape_text(shape) -> str:
    """Extract all text from a shape, handling text frames and tables."""
    parts: list[str] = []

    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            line = para.text.strip()
            if line:
                parts.append(line)

    if shape.has_table:
        for row in shape.table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))

    return "\n".join(parts)


def _extract_notes(slide) -> str:
    """Extract speaker notes text from a slide."""
    try:
        notes_slide = slide.notes_slide
        tf = notes_slide.notes_text_frame
        return "\n".join(
            p.text.strip() for p in tf.paragraphs if p.text.strip()
        )
    except Exception:
        return ""


def _detect_boilerplate(all_slide_texts: list[list[str]], total_slides: int) -> set[str]:
    """
    Return a set of text strings that appear on >= BOILERPLATE_THRESHOLD
    fraction of slides (e.g. repeated footer or copyright lines).
    """
    counter: Counter = Counter()
    for texts in all_slide_texts:
        for t in set(texts):
            counter[t] += 1

    threshold = max(2, int(total_slides * BOILERPLATE_THRESHOLD))
    return {text for text, count in counter.items() if count >= threshold}


# ─────────────────────────────────────────────────────────────
# Public parser
# ─────────────────────────────────────────────────────────────

def parse_pptx(record: FileRecord, config: Config) -> list[SlideRecord]:
    """
    Parse a PPTX file into a list of SlideRecord objects (one per slide).
    Empty slides are skipped. Boilerplate text is removed.

    Returns:
        List of SlideRecord (may be empty if file has no text content).
    """
    try:
        prs = Presentation(record.file_path)
    except Exception as exc:
        log.error("Failed to open PPTX: %s | error: %s", record.file_path, exc)
        return []

    total_slides = len(prs.slides)
    log.info("Parsing PPTX: %s (%d slides)", record.filename, total_slides)

    # First pass — collect all shape text per slide for boilerplate detection
    raw_per_slide: list[list[str]] = []
    for slide in prs.slides:
        texts = []
        for shape in slide.shapes:
            t = _extract_shape_text(shape).strip()
            if t and len(t) >= config.min_text_length:
                texts.append(t)
        raw_per_slide.append(texts)

    boilerplate = _detect_boilerplate(raw_per_slide, total_slides)
    if boilerplate:
        log.debug(
            "Detected %d boilerplate text(s) in %s",
            len(boilerplate), record.filename,
        )

    # Second pass — build SlideRecords
    results: list[SlideRecord] = []

    for slide_idx, slide in enumerate(prs.slides, start=1):
        title_text  = ""
        body_parts: list[str] = []

        for shape in slide.shapes:
            raw = _extract_shape_text(shape).strip()
            if not raw or len(raw) < config.min_text_length:
                continue
            if raw in boilerplate:
                continue

            # Check if shape is a title placeholder
            is_title = (
                shape.is_placeholder
                and shape.placeholder_format.type in (
                    PP_PLACEHOLDER.TITLE,
                    PP_PLACEHOLDER.CENTER_TITLE,
                )
            )
            if is_title and not title_text:
                title_text = raw
            else:
                body_parts.append(raw)

        notes = _extract_notes(slide)
        body_text = "\n".join(body_parts)
        full_text = "\n".join(filter(None, [title_text, body_text, notes]))

        if not full_text.strip():
            log.debug("Skipping empty slide %d in %s", slide_idx, record.filename)
            continue

        results.append(SlideRecord(
            source=       record.file_path,
            filename=     record.filename,
            slide_number= slide_idx,
            total_slides= total_slides,
            title=        title_text,
            body_text=    body_text,
            notes=        notes,
            full_text=    full_text,
            metadata={
                "file_size":     record.file_size,
                "last_modified": record.last_modified,
                "source_dir":    record.source_dir,
            },
        ))

    log.info(
        "PPTX parsed: %s → %d non-empty slides (of %d)",
        record.filename, len(results), total_slides,
    )
    return results
