"""
rag/generator.py — Stage 6: LLM Answer Generation.

Builds a grounded prompt from retrieved chunks and calls the LLM.
Source citations (filename + slide/sheet) are included in every answer.
Supports OpenAI GPT-4 and Anthropic Claude via their Python SDKs.
"""

from __future__ import annotations

from config import Config, cfg
from rag.retriever import RetrievedChunk
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Context builder
# ─────────────────────────────────────────────────────────────

def build_context(chunks: list[RetrievedChunk], max_chars: int = 12_000) -> str:
    """
    Format retrieved chunks into a context block for the LLM prompt.
    Includes source citation on each chunk. Truncates at max_chars.
    """
    parts: list[str] = []
    total = 0

    for i, chunk in enumerate(chunks, start=1):
        if chunk.file_type == "pptx":
            citation = (
                f"[{i}] {chunk.filename} | Slide {chunk.slide_number}"
                + (f" — {chunk.slide_sheet}" if chunk.slide_sheet else "")
            )
        else:
            citation = (
                f"[{i}] {chunk.filename} | Sheet: {chunk.sheet_name}"
                f" | Table {chunk.table_index + 1}"
                f" | Rows {chunk.row_start}–{chunk.row_end}"
            )

        block = f"{citation}\n{chunk.chunk_text.strip()}"
        if total + len(block) > max_chars:
            break

        parts.append(block)
        total += len(block)

    return "\n\n---\n\n".join(parts)


def build_prompt(query: str, context: str) -> str:
    return f"""You are a precise assistant. Answer the question using ONLY the provided context.
If the answer is not in the context, say "I don't have enough information to answer this."
Always cite the source [number] for each fact you state.

CONTEXT:
{context}

QUESTION: {query}

ANSWER:"""


# ─────────────────────────────────────────────────────────────
# LLM providers
# ─────────────────────────────────────────────────────────────

def _call_openai(prompt: str, config: Config) -> str:
    from openai import OpenAI
    client = OpenAI(api_key=config.openai_api_key)
    response = client.chat.completions.create(
        model=       config.llm_model,
        messages=    [{"role": "user", "content": prompt}],
        max_tokens=  config.llm_max_tokens,
        temperature= config.llm_temperature,
    )
    return response.choices[0].message.content.strip()


def _call_anthropic(prompt: str, config: Config) -> str:
    try:
        import anthropic
    except ImportError:
        raise ImportError("Install anthropic: pip install anthropic")

    import os
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
    message = client.messages.create(
        model=      config.llm_model,
        max_tokens= config.llm_max_tokens,
        messages=   [{"role": "user", "content": prompt}],
    )
    return message.content[0].text.strip()


# ─────────────────────────────────────────────────────────────
# Public interface
# ─────────────────────────────────────────────────────────────

def generate_answer(
    query: str,
    chunks: list[RetrievedChunk],
    config: Config,
) -> dict:
    """
    Generate a grounded LLM answer from retrieved chunks.

    Returns:
        {
          "answer":   str,
          "sources":  list of {filename, slide_sheet, chunk_id},
          "context":  str   (the context block sent to the LLM)
        }
    """
    if not chunks:
        return {
            "answer":  "No relevant information found in the knowledge base.",
            "sources": [],
            "context": "",
        }

    context = build_context(chunks)
    prompt  = build_prompt(query, context)

    provider = config.llm_provider.lower()
    log.info("Generating answer via %s (%s)…", provider, config.llm_model)

    if provider == "openai":
        answer = _call_openai(prompt, config)
    elif provider in ("anthropic", "claude"):
        answer = _call_anthropic(prompt, config)
    else:
        raise ValueError(f"Unknown LLM provider: {provider!r}")

    sources = [
        {
            "filename":    c.filename,
            "slide_sheet": c.slide_sheet,
            "chunk_id":    c.chunk_id,
        }
        for c in chunks
    ]

    return {"answer": answer, "sources": sources, "context": context}
