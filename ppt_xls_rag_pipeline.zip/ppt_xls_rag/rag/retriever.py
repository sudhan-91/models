"""
rag/retriever.py — Stage 6: Hybrid Retrieval (BM25 + kNN + RRF).

Implements the retrieval strategy from the architecture document:
  1. Embed the user query with the same model used at index time.
  2. Run BM25 keyword search against the `text` field.
  3. Run kNN approximate nearest-neighbour search against `embedding`.
  4. Merge both result lists using Reciprocal Rank Fusion (RRF) —
     natively supported by Elasticsearch 8.8+.
  5. Apply a minimum score threshold to filter low-relevance chunks.
  6. Return the top N chunks for the LLM context window.

Optional metadata filters (e.g. file_type, filename, date range) can
be passed to scope retrieval before BM25 + kNN runs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from elasticsearch import Elasticsearch

from config import Config, cfg
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


@dataclass
class RetrievedChunk:
    score:         float
    chunk_id:      str
    filename:      str
    file_type:     str
    slide_sheet:   str
    chunk_text:    str
    source:        str
    # PPTX
    slide_number:  int   = 0
    # XLSX
    sheet_name:    str   = ""
    table_index:   int   = 0
    row_start:     int   = 0
    row_end:       int   = 0
    table_headers: list  = None
    footer_key:    list  = None

    def __post_init__(self):
        if self.table_headers is None:
            self.table_headers = []
        if self.footer_key is None:
            self.footer_key = []


# ─────────────────────────────────────────────────────────────
# Query embedding
# ─────────────────────────────────────────────────────────────

def _embed_query(query: str, config: Config) -> list[float]:
    provider = config.embedding_provider.lower()

    if provider == "openai":
        from openai import OpenAI
        client = OpenAI(api_key=config.openai_api_key)
        response = client.embeddings.create(
            model=config.openai_model,
            input=[query],
            dimensions=config.openai_dims,
        )
        return response.data[0].embedding

    elif provider == "local":
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(config.local_model)
        return model.encode([query], normalize_embeddings=True)[0].tolist()

    raise ValueError(f"Unknown embedding provider: {provider!r}")


# ─────────────────────────────────────────────────────────────
# Filter builder
# ─────────────────────────────────────────────────────────────

def _build_filter(
    filters: Optional[dict],
    date_from: Optional[str],
    date_to: Optional[str],
) -> Optional[dict]:
    must: list[dict] = []

    if filters:
        for k, v in filters.items():
            must.append({"term": {k: v}})

    if date_from or date_to:
        date_range: dict = {}
        if date_from:
            date_range["gte"] = date_from
        if date_to:
            date_range["lte"] = date_to
        must.append({"range": {"date": date_range}})

    if not must:
        return None
    return {"bool": {"must": must}}


# ─────────────────────────────────────────────────────────────
# Hybrid retrieval
# ─────────────────────────────────────────────────────────────

def hybrid_search(
    query: str,
    client: Elasticsearch,
    config: Config,
    filters: Optional[dict[str, str]] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
) -> list[RetrievedChunk]:
    """
    Run hybrid BM25 + kNN search with RRF re-ranking.

    Args:
        query:     Natural language question from the user.
        client:    Elasticsearch client.
        config:    Pipeline config.
        filters:   Keyword filters e.g. {"file_type": "pptx", "filename": "Q4.pptx"}
        date_from: ISO date lower bound for the `date` field.
        date_to:   ISO date upper bound for the `date` field.

    Returns:
        List of RetrievedChunk ordered by RRF score, capped at context_top_n.
    """
    log.info("Hybrid search: %r", query)

    query_vector  = _embed_query(query, config)
    filter_clause = _build_filter(filters, date_from, date_to)

    try:
        results = _rrf_search(query, query_vector, filter_clause, client, config)
    except Exception as exc:
        log.warning("RRF failed (%s), falling back to pure kNN", exc)
        results = _knn_search(query_vector, filter_clause, client, config)

    # Apply minimum score threshold
    results = [r for r in results if r.score >= config.min_score_threshold]

    log.info("Retrieved %d chunk(s) above threshold %.2f",
             len(results), config.min_score_threshold)

    return results[: config.context_top_n]


def _rrf_search(
    query: str,
    query_vector: list[float],
    filter_clause: Optional[dict],
    client: Elasticsearch,
    config: Config,
) -> list[RetrievedChunk]:
    """Elasticsearch 8.8+ native RRF via the retriever API."""
    bm25_retriever: dict = {
        "standard": {
            "query": {
                "multi_match": {
                    "query":  query,
                    "fields": ["text^2", "slide_sheet"],
                }
            }
        }
    }
    if filter_clause:
        bm25_retriever["standard"]["filter"] = filter_clause

    knn_retriever: dict = {
        "knn": {
            "field":          "embedding",
            "query_vector":   query_vector,
            "k":              config.retrieval_top_k,
            "num_candidates": config.retrieval_top_k * 10,
        }
    }
    if filter_clause:
        knn_retriever["knn"]["filter"] = filter_clause

    body = {
        "retriever": {
            "rrf": {
                "retrievers":      [bm25_retriever, knn_retriever],
                "rank_window_size": config.retrieval_rrf_window,
                "rank_constant":   config.retrieval_rrf_constant,
            }
        },
        "_source": {"excludes": ["embedding"]},
        "size":    config.retrieval_top_k,
    }

    response = client.search(index=config.es_index, body=body)
    return _parse_hits(response)


def _knn_search(
    query_vector: list[float],
    filter_clause: Optional[dict],
    client: Elasticsearch,
    config: Config,
) -> list[RetrievedChunk]:
    """Pure kNN fallback (Elasticsearch < 8.8)."""
    knn: dict = {
        "field":          "embedding",
        "query_vector":   query_vector,
        "k":              config.retrieval_top_k,
        "num_candidates": config.retrieval_top_k * 10,
    }
    if filter_clause:
        knn["filter"] = filter_clause

    response = client.search(
        index=config.es_index,
        body={"knn": knn, "_source": {"excludes": ["embedding"]},
              "size": config.retrieval_top_k},
    )
    return _parse_hits(response)


def _parse_hits(response: dict) -> list[RetrievedChunk]:
    results: list[RetrievedChunk] = []
    for hit in response.get("hits", {}).get("hits", []):
        src = hit["_source"]
        results.append(RetrievedChunk(
            score=         hit.get("_score") or 0.0,
            chunk_id=      src.get("chunk_id", ""),
            filename=      src.get("filename", ""),
            file_type=     src.get("file_type", ""),
            slide_sheet=   src.get("slide_sheet", ""),
            chunk_text=    src.get("text", ""),
            source=        src.get("source", ""),
            slide_number=  src.get("slide_number", 0),
            sheet_name=    src.get("sheet_name", ""),
            table_index=   src.get("table_index", 0),
            row_start=     src.get("row_start", 0),
            row_end=       src.get("row_end", 0),
            table_headers= src.get("table_headers", []),
            footer_key=    src.get("footer_key", []),
        ))
    return results
