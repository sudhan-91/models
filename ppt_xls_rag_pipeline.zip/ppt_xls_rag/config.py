"""
config.py — Central configuration for the PPT & XLS → ELK RAG pipeline.
All values are read from environment variables (.env loaded at import time).
Single flat Config class — import the singleton `cfg` everywhere.
"""

import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:

    # ── File Ingestion ────────────────────────────────────────
    watch_dir: str              = os.environ.get("WATCH_DIR", "./files")
    supported_extensions: tuple = (".pptx", ".xlsx")
    # Comma-separated glob patterns to skip (e.g. "~$*,tmp_*")
    skip_patterns: str          = os.environ.get("SKIP_PATTERNS", "~$*")

    # ── Parsing ───────────────────────────────────────────────
    # Text shorter than this (chars) is treated as boilerplate and skipped
    min_text_length: int        = int(os.environ.get("MIN_TEXT_LENGTH", "10"))
    # OCR fallback for image-heavy slides (requires pytesseract)
    enable_ocr: bool            = os.environ.get("ENABLE_OCR", "false").lower() == "true"

    # ── Chunking ──────────────────────────────────────────────
    # PPTX: slides per chunk (1 = one slide = one chunk)
    pptx_slides_per_chunk: int  = int(os.environ.get("PPTX_SLIDES_PER_CHUNK", "1"))
    pptx_slide_overlap: int     = int(os.environ.get("PPTX_SLIDE_OVERLAP", "1"))
    # XLSX: rows per chunk (5–15 per doc recommendation)
    xlsx_rows_per_chunk: int    = int(os.environ.get("XLSX_ROWS_PER_CHUNK", "10"))
    xlsx_row_overlap: int       = int(os.environ.get("XLSX_ROW_OVERLAP", "2"))

    # ── Embedding ─────────────────────────────────────────────
    # "openai" or "local" (BGE-M3 via sentence-transformers)
    embedding_provider: str     = os.environ.get("EMBEDDING_PROVIDER", "openai")
    openai_api_key: str         = os.environ.get("OPENAI_API_KEY", "")
    openai_model: str           = os.environ.get("OPENAI_EMBEDDING_MODEL",
                                                   "text-embedding-3-small")
    openai_dims: int            = int(os.environ.get("OPENAI_DIMS", "1536"))
    local_model: str            = os.environ.get("LOCAL_EMBEDDING_MODEL",
                                                   "BAAI/bge-m3")
    local_dims: int             = int(os.environ.get("LOCAL_DIMS", "1024"))
    embedding_batch_size: int   = int(os.environ.get("EMBEDDING_BATCH_SIZE", "100"))
    # SHA-256 hash cache path to avoid re-embedding unchanged chunks
    embedding_cache_path: str   = os.environ.get("EMBEDDING_CACHE_PATH",
                                                   ".embedding_cache.json")

    # ── Elasticsearch ─────────────────────────────────────────
    es_url: str                 = os.environ.get("ES_URL", "http://localhost:9200")
    es_index: str               = os.environ.get("ES_INDEX", "documents")
    es_username: str            = os.environ.get("ES_USER", "")
    es_password: str            = os.environ.get("ES_PASSWORD", "")
    es_ca_certs: str            = os.environ.get("ES_CA_CERTS", "")
    es_request_timeout: int     = 30
    es_bulk_batch_size: int     = 200

    # ── Retrieval ─────────────────────────────────────────────
    retrieval_top_k: int        = int(os.environ.get("RETRIEVAL_TOP_K", "20"))
    retrieval_rrf_window: int   = int(os.environ.get("RRF_WINDOW", "40"))
    retrieval_rrf_constant: int = int(os.environ.get("RRF_CONSTANT", "60"))
    # Chunks passed to LLM (top N after RRF re-ranking)
    context_top_n: int          = int(os.environ.get("CONTEXT_TOP_N", "6"))
    min_score_threshold: float  = float(os.environ.get("MIN_SCORE_THRESHOLD", "0.3"))

    # ── LLM ───────────────────────────────────────────────────
    llm_provider: str           = os.environ.get("LLM_PROVIDER", "openai")
    llm_model: str              = os.environ.get("LLM_MODEL", "gpt-4o")
    llm_max_tokens: int         = int(os.environ.get("LLM_MAX_TOKENS", "1024"))
    llm_temperature: float      = float(os.environ.get("LLM_TEMPERATURE", "0.0"))

    # ── API ───────────────────────────────────────────────────
    api_host: str               = os.environ.get("API_HOST", "0.0.0.0")
    api_port: int               = int(os.environ.get("API_PORT", "8000"))

    # ── Logging ───────────────────────────────────────────────
    log_dir: str                = os.environ.get("LOG_DIR", "logs")
    log_level: str              = os.environ.get("LOG_LEVEL", "INFO")

    @property
    def embedding_dims(self) -> int:
        return self.openai_dims if self.embedding_provider == "openai" else self.local_dims


# Singleton — import this everywhere
cfg = Config()
