"""
processing/chunker.py — Stage 3: Chunking & Enrichment.

Converts SlideRecord and TableRecord objects into Chunk objects ready
for embedding.  Metadata is prepended to every chunk text so every
vector carries enough context for accurate retrieval.

PPTX strategy : one slide per chunk (or N slides with 1-slide overlap)
XLSX strategy : N consecutive data rows per chunk (5–15 rows, 2-row overlap)
                header context is prepended to every row-chunk
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from config import Config, cfg
from parsers.pptx_parser import SlideRecord
from parsers.xlsx_parser import TableRecord
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


@dataclass
class Chunk:
    """A single unit of text ready for embedding and indexing."""
    chunk_id:       str          # deterministic ID: filename_type_identifier_chunkN
    source:         str          # file path
    filename:       str
    file_type:      str          # "pptx" or "xlsx"
    chunk_text:     str          # text sent to the embedding model
    # PPTX-specific
    slide_number:   int   = 0
    slide_title:    str   = ""
    # XLSX-specific
    sheet_name:     str   = ""
    table_index:    int   = 0
    row_start:      int   = 0
    row_end:        int   = 0
    table_headers:  list  = None   # [["Col A"], ["Col B"]]
    footer_key:     list  = None   # ["footer label"]
    # Shared
    chunk_index:    int   = 0
    total_chunks:   int   = 0
    last_modified:  str   = ""
    source_dir:     str   = ""

    def __post_init__(self):
        if self.table_headers is None:
            self.table_headers = []
        if self.footer_key is None:
            self.footer_key = []


# ─────────────────────────────────────────────────────────────
# Metadata prefix builder
# ─────────────────────────────────────────────────────────────

def _pptx_prefix(record: SlideRecord, slide_numbers: list[int]) -> str:
    slide_range = (
        str(slide_numbers[0])
        if len(slide_numbers) == 1
        else f"{slide_numbers[0]}-{slide_numbers[-1]}"
    )
    parts = [
        f"[Source: {record.filename} | Slide: {slide_range} of {record.total_slides}]",
    ]
    if record.title:
        parts.append(f"Title: {record.title}")
    return "\n".join(parts) + "\n\n"


def _xlsx_prefix(record: TableRecord, rows: list[dict]) -> str:
    header_labels = " | ".join(h[0] if h else "" for h in record.table_headers)
    parts = [
        f"[Source: {record.filename} | Sheet: {record.sheet_name}"
        f" | Table: {record.table_index + 1}"
        f" | Rows: {record.row_start}-{record.row_end}]",
        f"Columns: {header_labels}",
    ]
    if record.footer_key:
        parts.append(f"Footer: {record.footer_key[0]}")
    return "\n".join(parts) + "\n\n"


# ─────────────────────────────────────────────────────────────
# PPTX chunking
# ─────────────────────────────────────────────────────────────

def chunk_slides(slides: list[SlideRecord], config: Config) -> list[Chunk]:
    """
    Group slides into chunks of `pptx_slides_per_chunk` with
    `pptx_slide_overlap` overlap between adjacent chunks.
    """
    if not slides:
        return []

    step     = max(1, config.pptx_slides_per_chunk)
    overlap  = max(0, config.pptx_slide_overlap)
    stride   = max(1, step - overlap)
    n        = len(slides)
    chunks: list[Chunk] = []

    starts = list(range(0, n, stride))
    total  = len(starts)

    for chunk_idx, start in enumerate(starts):
        window    = slides[start: start + step]
        slide_nums = [s.slide_number for s in window]
        combined  = "\n\n".join(s.full_text for s in window if s.full_text.strip())

        if not combined.strip():
            continue

        prefix    = _pptx_prefix(window[0], slide_nums)
        chunk_text = prefix + combined

        safe_name = slides[0].filename.replace(".", "_")
        chunk_id  = f"{safe_name}_slide_{slide_nums[0]}_chunk{chunk_idx}"

        chunks.append(Chunk(
            chunk_id=     chunk_id,
            source=       window[0].source,
            filename=     window[0].filename,
            file_type=    "pptx",
            chunk_text=   chunk_text,
            slide_number= slide_nums[0],
            slide_title=  window[0].title,
            chunk_index=  chunk_idx,
            total_chunks= total,
            last_modified=window[0].metadata.get("last_modified", ""),
            source_dir=   window[0].metadata.get("source_dir", ""),
        ))

    log.debug(
        "PPTX chunked: %s → %d slides → %d chunks",
        slides[0].filename, n, len(chunks),
    )
    return chunks


# ─────────────────────────────────────────────────────────────
# XLSX chunking
# ─────────────────────────────────────────────────────────────

def chunk_table(table: TableRecord, config: Config) -> list[Chunk]:
    """
    Split a TableRecord's rows into chunks of `xlsx_rows_per_chunk`
    with `xlsx_row_overlap` overlap.  Header context is prepended to
    every chunk.
    """
    rows   = table.rows
    if not rows:
        return []

    step    = max(1, config.xlsx_rows_per_chunk)
    overlap = max(0, config.xlsx_row_overlap)
    stride  = max(1, step - overlap)
    header_labels = [h[0] if h else "" for h in table.table_headers]

    starts = list(range(0, len(rows), stride))
    total  = len(starts)
    chunks: list[Chunk] = []

    for chunk_idx, start in enumerate(starts):
        window     = rows[start: start + step]
        row_lines  = [
            " | ".join(str(r.get(h, "")) for h in header_labels)
            for r in window
        ]
        row_block  = "\n".join(row_lines)

        if not row_block.strip():
            continue

        prefix     = _xlsx_prefix(table, window)
        chunk_text = prefix + row_block

        safe_name  = table.filename.replace(".", "_")
        chunk_id   = (
            f"{safe_name}_{table.sheet_name}_t{table.table_index}"
            f"_chunk{chunk_idx}"
        )

        chunks.append(Chunk(
            chunk_id=     chunk_id,
            source=       table.source,
            filename=     table.filename,
            file_type=    "xlsx",
            chunk_text=   chunk_text,
            sheet_name=   table.sheet_name,
            table_index=  table.table_index,
            row_start=    table.row_start + start,
            row_end=      table.row_start + start + len(window) - 1,
            table_headers=table.table_headers,
            footer_key=   table.footer_key,
            chunk_index=  chunk_idx,
            total_chunks= total,
            last_modified=table.metadata.get("last_modified", ""),
            source_dir=   table.metadata.get("source_dir", ""),
        ))

    log.debug(
        "XLSX table chunked: %s/%s table_%d → %d rows → %d chunks",
        table.filename, table.sheet_name, table.table_index,
        len(rows), len(chunks),
    )
    return chunks
