"""
processing/embedder.py — Stage 4: Embedding.

Supports two providers:
  - OpenAI   text-embedding-3-small (1536 dims) — default
  - Local    BAAI/bge-m3 via sentence-transformers (1024 dims)

Features:
  - Batch processing (100 chunks per API call)
  - SHA-256 content hash cache — unchanged chunks are never re-embedded
  - Provider selected via config.embedding_provider ("openai" | "local")
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Optional

from config import Config, cfg
from processing.chunker import Chunk
from logger import get_logger

log = get_logger(__name__, cfg.log_dir, cfg.log_level)


# ─────────────────────────────────────────────────────────────
# Hash cache
# ─────────────────────────────────────────────────────────────

def _load_cache(path: str) -> dict[str, list[float]]:
    if Path(path).exists():
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_cache(cache: dict[str, list[float]], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cache, f)


def _text_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


# ─────────────────────────────────────────────────────────────
# OpenAI provider
# ─────────────────────────────────────────────────────────────

def _embed_openai(texts: list[str], config: Config) -> list[list[float]]:
    """Embed a batch of texts using the OpenAI Embeddings API."""
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError("Install openai: pip install openai")

    client = OpenAI(api_key=config.openai_api_key)
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), config.embedding_batch_size):
        batch = texts[i: i + config.embedding_batch_size]
        for attempt in range(3):
            try:
                response = client.embeddings.create(
                    model=      config.openai_model,
                    input=      batch,
                    dimensions= config.openai_dims,
                )
                all_embeddings.extend([d.embedding for d in response.data])
                break
            except Exception as exc:
                if attempt == 2:
                    raise
                wait = 2 ** attempt
                log.warning("OpenAI API error, retrying in %ds: %s", wait, exc)
                time.sleep(wait)

    return all_embeddings


# ─────────────────────────────────────────────────────────────
# Local provider (BGE-M3)
# ─────────────────────────────────────────────────────────────

_local_model_cache: dict = {}


def _embed_local(texts: list[str], config: Config) -> list[list[float]]:
    """Embed using a local sentence-transformers model (BGE-M3)."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise ImportError("Install sentence-transformers: pip install sentence-transformers")

    if config.local_model not in _local_model_cache:
        log.info("Loading local embedding model: %s", config.local_model)
        _local_model_cache[config.local_model] = SentenceTransformer(config.local_model)

    model = _local_model_cache[config.local_model]
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), config.embedding_batch_size):
        batch = texts[i: i + config.embedding_batch_size]
        vecs  = model.encode(
            batch,
            batch_size=         config.embedding_batch_size,
            normalize_embeddings=True,
            show_progress_bar=  False,
            convert_to_numpy=   True,
        )
        all_embeddings.extend(vecs.tolist())

    return all_embeddings


# ─────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────

def embed_chunks(chunks: list[Chunk], config: Config) -> list[Chunk]:
    """
    Embed all chunks, using the hash cache to skip unchanged ones.

    Embeddings are stored directly on each Chunk object as `embedding`.
    Returns the same list of chunks, now with `.embedding` populated.
    """
    if not chunks:
        return chunks

    cache = _load_cache(config.embedding_cache_path)
    to_embed_indices: list[int]  = []
    to_embed_texts:   list[str]  = []

    # Assign hash and check cache
    for i, chunk in enumerate(chunks):
        h = _text_hash(chunk.chunk_text)
        chunk.content_hash = h          # type: ignore[attr-defined]
        if h in cache:
            chunk.embedding = cache[h]  # type: ignore[attr-defined]
        else:
            to_embed_indices.append(i)
            to_embed_texts.append(chunk.chunk_text)

    log.info(
        "Embedding: %d new chunk(s), %d from cache (total %d)",
        len(to_embed_texts), len(chunks) - len(to_embed_texts), len(chunks),
    )

    if to_embed_texts:
        provider = config.embedding_provider.lower()
        if provider == "openai":
            vectors = _embed_openai(to_embed_texts, config)
        elif provider == "local":
            vectors = _embed_local(to_embed_texts, config)
        else:
            raise ValueError(f"Unknown embedding provider: {provider!r}")

        for idx, vec in zip(to_embed_indices, vectors):
            chunks[idx].embedding = vec                       # type: ignore[attr-defined]
            cache[chunks[idx].content_hash] = vec             # type: ignore[attr-defined]

        _save_cache(cache, config.embedding_cache_path)
        log.info("Embedding complete — cache updated (%d entries)", len(cache))

    return chunks
